package pe.dinersclub.wscomercios.exception;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;
import org.springframework.security.core.AuthenticationException;

@ControllerAdvice
@RestController
public class ResponseExceptionHandler extends ResponseEntityExceptionHandler {

	/*@ExceptionHandler(Exception.class)
	public final ResponseEntity<ExceptionResponse> manejarTodasExcepciones(ModeloNotFountException ex,
			WebRequest request) {
		ExceptionResponse er = new ExceptionResponse(ex.getMessage(), ex.getId_transaccion(),
				request.getDescription(false));
		return new ResponseEntity<ExceptionResponse>(er, HttpStatus.INTERNAL_SERVER_ERROR);
	}*/

	@ExceptionHandler(ModeloNotFountException.class)
	public final ResponseEntity<ExceptionResponse> manejarModeloException(ModeloNotFountException ex,
			WebRequest request) {
		ExceptionResponse er = new ExceptionResponse(ex.getMessage(), ex.getId_transaccion(),
				request.getDescription(false));

		return new ResponseEntity<ExceptionResponse>(er, HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(AuthenticationException.class)
	public final ResponseEntity<ExceptionResponse> authException(ModeloNotFountException ex,
			WebRequest request) {
		ExceptionResponse er = new ExceptionResponse(ex.getMessage(), ex.getId_transaccion(),
				request.getDescription(false));

		return new ResponseEntity<ExceptionResponse>(er, HttpStatus.UNAUTHORIZED);
	}

	@Override
	protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex,
			HttpHeaders headers, HttpStatus status, WebRequest request) {
		ExceptionResponse er = new ExceptionResponse(ex.getMessage(), null, request.getDescription(false));
		return new ResponseEntity<Object>(er, HttpStatus.BAD_REQUEST);
	}

}
