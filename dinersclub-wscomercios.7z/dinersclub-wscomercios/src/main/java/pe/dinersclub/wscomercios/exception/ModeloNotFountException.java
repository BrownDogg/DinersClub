package pe.dinersclub.wscomercios.exception;

//@ResponseStatus(HttpStatus.NOT_FOUND)
public class ModeloNotFountException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -390012685133184341L;
	private final String id_transaccion;
	
	public ModeloNotFountException(String mensaje, String id_transaccion) {
		super(mensaje);
		this.id_transaccion = id_transaccion;
	}

	public String getId_transaccion() {
		return id_transaccion;
	}
	
	
}
