package pe.dinersclub.wscomercios.domain.transaccion;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import io.swagger.annotations.ApiModel;

@ApiModel(description = "Datos de la transacción en formato de ventas")
public class VentaRequest {

	//@Size(min = 10, max = 10, message = "El codigo de comercio debe tener 10 caracteres")
	private Long codigoComercio;

	@Size(min = 3, max = 3, message = "La moneda debe tener 3 caracteres")
	private String moneda;

	private String fechaInicio;

	private String fechaFin;

	@NotNull(message = "No se indicó el número página")
	private Integer page;

	@NotNull(message = "No se indicó la cantidad de registros por página")
	private Integer xpage;

	public Long getCodigoComercio() {
		return codigoComercio;
	}

	public void setCodigoComercio(Long codigoComercio) {
		this.codigoComercio = codigoComercio;
	}

	public String getMoneda() {
		return moneda;
	}

	public void setMoneda(String moneda) {
		this.moneda = moneda;
	}

	public String getFechaInicio() {
		return fechaInicio;
	}

	public void setFechaInicio(String fechaInicio) {
		this.fechaInicio = fechaInicio;
	}

	public String getFechaFin() {
		return fechaFin;
	}

	public void setFechaFin(String fechaFin) {
		this.fechaFin = fechaFin;
	}

	public Integer getPage() {
		return page;
	}

	public void setPage(Integer page) {
		this.page = page;
	}

	public Integer getXpage() {
		return xpage;
	}

	public void setXpage(Integer xpage) {
		this.xpage = xpage;
	}

}
