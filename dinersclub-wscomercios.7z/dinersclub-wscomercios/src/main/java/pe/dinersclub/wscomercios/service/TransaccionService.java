package pe.dinersclub.wscomercios.service;

import java.util.LinkedHashMap;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import pe.dinersclub.wscomercios.domain.ConsumoResp;
import pe.dinersclub.wscomercios.domain.ConsumosRequest;
import pe.dinersclub.wscomercios.domain.EvolucionVentaRequest;
import pe.dinersclub.wscomercios.domain.EvolucionVentaResponse;
import pe.dinersclub.wscomercios.domain.transaccion.DevolucionDetalle;
import pe.dinersclub.wscomercios.domain.transaccion.DevolucionDomRequest;
import pe.dinersclub.wscomercios.domain.transaccion.DevolucionMasivaResponse;
import pe.dinersclub.wscomercios.domain.transaccion.VentaRequest;
import pe.dinersclub.wscomercios.domain.transaccion.VentaResponse;
import pe.dinersclub.wscomercios.dto.transacciones.DevolucionRespDTO;

public interface TransaccionService {

	public VentaResponse listarVentas(String idTransaccion, Long rucEmpresa,VentaRequest ventaRequest);
	public EvolucionVentaResponse listarEvolucionVentas (String idTransaccion, EvolucionVentaRequest evolucionRequest);
	public List<ConsumoResp> listarConsumos(String idTransaccion, ConsumosRequest consumoRequest);
	public LinkedHashMap<String,String> cargarDevolucionIndividual(String idTransaccion, DevolucionDetalle devolucionDetalle);
	public DevolucionMasivaResponse cargarDevolucionMasiva(String idTransaccion, Long codigoComercio, MultipartFile file);
	public List<DevolucionRespDTO> listarDevolucion(String idTransaccion, DevolucionDomRequest devolucionRequest);
	
}
