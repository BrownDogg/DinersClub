package pe.dinersclub.wscomercios.exception;

public class ExceptionResponse {

	private String codigoRespuesta;
	private String idTransaccion;
	private String detalle;

	public ExceptionResponse(String mensaje, String idTransaccion, String detalles) {
		this.codigoRespuesta = mensaje;
		this.idTransaccion = idTransaccion;
		this.detalle = detalles;
	}

	public String getCodigoRespuesta() {
		return codigoRespuesta;
	}

	public void setCodigo_respuesta(String codigoRespuesta) {
		this.codigoRespuesta = codigoRespuesta;
	}

	public String getIdTransaccion() {
		return idTransaccion;
	}

	public void setId_transaccion(String idTransaccion) {
		this.idTransaccion = idTransaccion;
	}

	public String getDetalle() {
		return detalle;
	}

	public void setDetalle(String detalle) {
		this.detalle = detalle;
	}

}
