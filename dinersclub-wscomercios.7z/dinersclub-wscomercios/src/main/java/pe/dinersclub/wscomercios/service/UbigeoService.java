package pe.dinersclub.wscomercios.service;

import java.util.LinkedHashMap;

public interface UbigeoService {

	public LinkedHashMap<String,String> listarDepartamentos();
	public LinkedHashMap<String,String> listarProvincias(String idDepartamento);
	public LinkedHashMap<String,String> listarDistritos(String idDepartamento, String idProvincia);
	
}
