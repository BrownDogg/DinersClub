package pe.dinersclub.wscomercios.domain;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.format.annotation.NumberFormat;

public class CadDescargaSolicitudesDinersRequest {

	@NotNull(message = "Se necesita el código de comercio.")
	@NumberFormat
	private Long codigoComercio;

	@Size(max = 10, message = "El codigo de comercio debe tener máximo 20 caracteres")
	private String codigoServicio;

	@NumberFormat
	private Long numeroTarjeta;

	private String fechaInicio;
	private String fechaFin;

	public Long getCodigoComercio() {
		return codigoComercio;
	}

	public void setCodigoComercio(Long codigoComercio) {
		this.codigoComercio = codigoComercio;
	}

	public void setNumeroTarjeta(Long numeroTarjeta) {
		this.numeroTarjeta = numeroTarjeta;
	}

	public String getCodigoServicio() {
		return codigoServicio;
	}

	public void setCodigoServicio(String codigoServicio) {
		this.codigoServicio = codigoServicio;
	}

	public String getFechaInicio() {
		return fechaInicio;
	}

	public void setFechaInicio(String fechaInicio) {
		this.fechaInicio = fechaInicio;
	}

	public String getFechaFin() {
		return fechaFin;
	}

	public void setFechaFin(String fechaFin) {
		this.fechaFin = fechaFin;
	}

	public Long getNumeroTarjeta() {
		return numeroTarjeta;
	}

}
