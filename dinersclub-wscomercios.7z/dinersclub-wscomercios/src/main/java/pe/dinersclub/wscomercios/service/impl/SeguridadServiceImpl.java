package pe.dinersclub.wscomercios.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import pe.dinersclub.wscomercios.dao.UsuarioDAO;
import pe.dinersclub.wscomercios.dto.usuario.ActualizarPasswordDTO;
import pe.dinersclub.wscomercios.dto.usuario.Usuario;
import pe.dinersclub.wscomercios.dto.usuario.UsuarioRecPassEmail;
import pe.dinersclub.wscomercios.exception.ModeloNotFountException;
import pe.dinersclub.wscomercios.log.BeanLog;
import pe.dinersclub.wscomercios.log.UtilLog;
import pe.dinersclub.wscomercios.log.UtilLogLevel;
import pe.dinersclub.wscomercios.mensajeria.formatos.EnviarMensajeriaFormatos;
import pe.dinersclub.wscomercios.security.service.JWTService;
import pe.dinersclub.wscomercios.service.SeguridadService;
import pe.dinersclub.wscomercios.util.Globales;
import pe.dinersclub.wscomercios.util.UtilString;

@Service
public class SeguridadServiceImpl implements SeguridadService {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private UtilLog utilLog;

	@Autowired
	private UsuarioDAO usuarioDao;

	@Autowired
	private BCryptPasswordEncoder passwordEncoder;

	@Autowired
	private EnviarMensajeriaFormatos enviarMensajeriaFormatos;

	@Autowired
	private JWTService jwtService;

	@Override
	public Boolean realizaCambioPassword(ActualizarPasswordDTO actualizarPasswordDTO, String identificador) {

		BeanLog beanLog = new BeanLog();
		beanLog.setIdentificador(identificador);
		beanLog.setMetodo(new Object() {
		}.getClass().getEnclosingMethod().getName());

		Usuario usuario = usuarioDao.findByIdUsuario(actualizarPasswordDTO.getIdUsuario(), identificador);
		boolean respuesta = false;

		if (usuario == null) {
			beanLog.setCodigoMensaje(Globales.USUARIO_NO_EXISTE);
			beanLog.setDescripcionMensaje("USUARIO_NO_EXISTE.");
			beanLog.setTipoMensaje(UtilLogLevel.INFO.name());
			utilLog.printInfo(logger, beanLog);
			throw new ModeloNotFountException(beanLog.getCodigoMensaje(), identificador);
		}

		String bcryptPassword = passwordEncoder.encode(actualizarPasswordDTO.getPassword());
		respuesta = usuarioDao.actualizarPassword(usuario.getIdUsuario(), bcryptPassword, identificador);

		if (!usuario.isAccesoCambioPassword()) {
			respuesta = usuarioDao.actualizarFlgAcceso(usuario.getIdUsuario(), Globales.FLG_ACCESO_PERMITIDO,
					identificador);
		}

		if (!usuario.isNoBloqueado()) {
			usuarioDao.actualizarFlgBloqueo(usuario.getIdUsuario(), Globales.FLG_USUARIO_NO_BLOQUEADO, identificador);
			usuarioDao.actualizarAccesosFallidos(usuario.getIdUsuario(), Globales.REINICIAR_ACCESOS_FALLIDOS,
					identificador);
		}

		if (!respuesta) {
			beanLog.setCodigoMensaje(Globales.OCURRIO_UN_PROBLEMA_AL_ACTUALIZAR_PASSWORD);
			beanLog.setDescripcionMensaje("OCURRIO_UN_PROBLEMA_AL_ACTUALIZAR_PASSWORD.");
			beanLog.setTipoMensaje(UtilLogLevel.ERROR.name());
			utilLog.printInfo(logger, beanLog);
		}

		return respuesta;
	}

	@Override
	public Boolean recuperarPassword(String username, String identificador, String urlBase) {

		BeanLog beanLog = new BeanLog();
		beanLog.setIdentificador(identificador);
		beanLog.setMetodo(new Object() {
		}.getClass().getEnclosingMethod().getName());

		Boolean resultado = false;

		Usuario usuario = usuarioDao.findByUsername(username, identificador);

		if (usuario == null) {
			beanLog.setCodigoMensaje(Globales.USUARIO_NO_EXISTE);
			beanLog.setDescripcionMensaje("USUARIO_NO_EXISTE");
			beanLog.setTipoMensaje(UtilLogLevel.INFO.name());
			utilLog.printInfo(logger, beanLog);
			throw new ModeloNotFountException(beanLog.getCodigoMensaje(), identificador);
		}

		String tokenUrl = jwtService.generaTokenUrl(identificador, usuario);

		UsuarioRecPassEmail usuarioRecuperaClaveEmail = new UsuarioRecPassEmail();
		usuarioRecuperaClaveEmail.setNombreCompleto(usuario.getUsuNombres() + " " + usuario.getUsuApellidos());
		usuarioRecuperaClaveEmail.setEmail(usuario.getEmail());
		usuarioRecuperaClaveEmail.setUrlRecuperaPassword(Globales.urlRecuperaPassword + "?token=" + tokenUrl);

		try {
			enviarMensajeriaFormatos.enviarRecuperaPassword(usuarioRecuperaClaveEmail);
			resultado = true;
		} catch (Exception ex) {
			beanLog.setCodigoMensaje(Globales.OCURRIO_UN_PROBLEMA_AL_ENVIAR_EMAIL);
			beanLog.setDescripcionMensaje("OCURRIO_UN_PROBLEMA_AL_ENVIAR_EMAIL. Email: " + usuario.getEmail());
			beanLog.setTipoMensaje(UtilLogLevel.INFO.name());
			utilLog.printInfo(logger, beanLog);
			throw new ModeloNotFountException(beanLog.getCodigoMensaje(), identificador);
		}

		return resultado;
	}

	@Override
	public Boolean procesarAccesosFallidos(String username, String uriRequest) {

		BeanLog beanLog = new BeanLog();
		beanLog.setIdentificador(UtilString.obtenerIdentificadorUnico());
		beanLog.setMetodo(new Object() {
		}.getClass().getEnclosingMethod().getName());

		boolean usuarioNoBloqueado = true;

		Usuario usuario = usuarioDao.findByUsername(username, beanLog.getIdentificador());

		if (usuario == null) {
			beanLog.setDescripcionMensaje(
					"INTENTO DE ACCESO DESDE " + uriRequest + " DE USUARIO NO REGISTRADO: " + username);
			beanLog.setTipoMensaje(UtilLogLevel.INFO.name());
			utilLog.printInfo(logger, beanLog);
			return usuarioNoBloqueado;
		}

		if (usuario.isNoBloqueado()) {
			if (usuario.getCantAccesos() < 3) {
				usuarioDao.actualizarAccesosFallidos(usuario.getIdUsuario(), Integer.sum(usuario.getCantAccesos(), 1),
						beanLog.getIdentificador());
				beanLog.setDescripcionMensaje("ACCESO FALLIDO DESDE " + uriRequest + " DE USUARIO "
						+ usuario.getUsername() + " - INTENTO NRO: " + Integer.sum(usuario.getCantAccesos(), 1));
				beanLog.setTipoMensaje(UtilLogLevel.INFO.name());
				utilLog.printInfo(logger, beanLog);

			} else {
				usuarioDao.actualizarFlgBloqueo(usuario.getIdUsuario(), Globales.FLG_USUARIO_BLOQUEADO,
						beanLog.getIdentificador());
				beanLog.setDescripcionMensaje("SE BLOQUEÓ POR ACCESOS FALLIDOS AL USUARIO: " + usuario.getUsername());
				beanLog.setTipoMensaje(UtilLogLevel.INFO.name());
				utilLog.printInfo(logger, beanLog);
			}
		} else {
			usuarioNoBloqueado = false;
		}

		return usuarioNoBloqueado;
	}
	
	
	@Override
	public boolean logout(String identificador, String idUsuario) {
		jwtService.logout(identificador, idUsuario);
		return true;
	}
	
	
}
