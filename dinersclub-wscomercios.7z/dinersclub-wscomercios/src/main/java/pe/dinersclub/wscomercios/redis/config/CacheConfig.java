package pe.dinersclub.wscomercios.redis.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.CachingConfigurerSupport;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.redis.cache.RedisCacheConfiguration;
import org.springframework.data.redis.cache.RedisCacheManager;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.connection.RedisStandaloneConfiguration;
import org.springframework.data.redis.connection.jedis.JedisClientConfiguration;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.GenericJackson2JsonRedisSerializer;
import org.springframework.data.redis.serializer.RedisSerializationContext;

import redis.clients.jedis.JedisPoolConfig;

import java.time.Duration;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.TimeUnit;

@Configuration
@EnableConfigurationProperties(CacheConfigurationProperties.class)
public class CacheConfig extends CachingConfigurerSupport {

	@Value("${app.redisHost}")
	private String redisHost;

	@Value("${app.redisPort}")
	private int redisPort;

	@Value("${app.redisPassword}")
	private String redisPassword;

	@Value("${app.redisMaxTotal}")
	private int redisMaxTotal;

	@Value("${app.redisMinIdle}")
	private int redisMinIdle;

	@Value("${app.redisMaxIdle}")
	private int redisMaxIdle;

	@Value("${app.redisMaxWaitMillis}")
	private int redisMaxWaitMillis;

	@Value("${app.redisTestWhileIdle}")
	private boolean redisTestWhileIdle;

	@Value("${app.redisTiempoVidaDatosUsuario}")
	private int redisTiempoVidaDatosUsuario;

	@Value("${app.redisTiempoVidaTablas}")
	private int redisTiempoVidaTablas;

	private static RedisCacheConfiguration createCacheConfiguration(long timeoutInSeconds) {
		// SE AGREGA LA SERIALIZACION PARA QUE LA INFORMACION SE GUARDE EN FORMATO JSON
		RedisSerializationContext.SerializationPair<Object> jsonSerializer = RedisSerializationContext.SerializationPair
				.fromSerializer(new GenericJackson2JsonRedisSerializer());
		return RedisCacheConfiguration.defaultCacheConfig().entryTtl(Duration.ofSeconds(timeoutInSeconds))
				.serializeValuesWith(jsonSerializer);
	}

	@Bean
	public JedisPoolConfig poolConfig() {
		JedisPoolConfig poolConfig = new JedisPoolConfig();
		// Número máximo de objetos activos
		poolConfig.setMaxTotal(redisMaxTotal);
		// Tiempo de espera máximo cuando no se devuelve ningún objeto en el grupo
		poolConfig.setMaxWaitMillis(redisMaxWaitMillis);
		// Número mínimo de objetos que pueden mantener el estado idle
		poolConfig.setMinIdle(redisMinIdle);
		// Número máximo de objetos que pueden mantener el estado idle
		poolConfig.setMaxIdle(redisMaxIdle);
		// Ya sea para detectar su tiempo de espera inactivo cuando el objeto "enlace"
		// se envía a la persona que llama
		poolConfig.setTestWhileIdle(redisTestWhileIdle);
		return poolConfig;
	}

	@Bean
	public RedisStandaloneConfiguration redisStandaloneConfiguration() {
		RedisStandaloneConfiguration redisStandaloneConfiguration = new RedisStandaloneConfiguration();
		redisStandaloneConfiguration.setHostName(redisHost);
		redisStandaloneConfiguration.setPort(redisPort);
		redisStandaloneConfiguration.setPassword(redisPassword);
		return redisStandaloneConfiguration;
	}

	@Bean
	public JedisClientConfiguration clientConfiguration() {
		JedisClientConfiguration.JedisClientConfigurationBuilder builder = JedisClientConfiguration.builder();
		return builder.usePooling().poolConfig(poolConfig()).build();
	}

	@Bean
	public JedisConnectionFactory redisConnectionFactory() {
		return new JedisConnectionFactory(redisStandaloneConfiguration(), clientConfiguration());
	}

	@Bean
	public RedisTemplate<String, String> redisTemplate(RedisConnectionFactory cf) {
		RedisTemplate<String, String> redisTemplate = new RedisTemplate<String, String>();
		redisTemplate.setConnectionFactory(cf);
		return redisTemplate;
	}

	@Bean
	@Primary // CONFIGURACION DE CACHE MANAGER POR DEFECTO
	public CacheManager cacheManager(RedisConnectionFactory redisConnectionFactory,
			CacheConfigurationProperties properties) {
		Map<String, RedisCacheConfiguration> cacheConfigurations = new HashMap<>();

		for (Entry<String, Long> cacheNameAndTimeout : properties.getCacheExpirations().entrySet()) {
			cacheConfigurations.put(cacheNameAndTimeout.getKey(),
					createCacheConfiguration(cacheNameAndTimeout.getValue()));
		}
		return RedisCacheManager.builder(redisConnectionFactory)
				.cacheDefaults(createCacheConfiguration(TimeUnit.HOURS.toSeconds(redisTiempoVidaDatosUsuario)))
				.withInitialCacheConfigurations(cacheConfigurations).build();
	}

	@Bean
	public CacheManager cacheManagerTablas(RedisConnectionFactory redisConnectionFactory,
			CacheConfigurationProperties properties) {
		Map<String, RedisCacheConfiguration> cacheConfigurations = new HashMap<>();

		for (Entry<String, Long> cacheNameAndTimeout : properties.getCacheExpirations().entrySet()) {
			cacheConfigurations.put(cacheNameAndTimeout.getKey(),
					createCacheConfiguration(cacheNameAndTimeout.getValue()));
		}
		return RedisCacheManager.builder(redisConnectionFactory)
				.cacheDefaults(createCacheConfiguration(TimeUnit.HOURS.toSeconds(redisTiempoVidaTablas)))
				.withInitialCacheConfigurations(cacheConfigurations).build();
	}
}