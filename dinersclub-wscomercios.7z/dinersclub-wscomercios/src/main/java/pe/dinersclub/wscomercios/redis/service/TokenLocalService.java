package pe.dinersclub.wscomercios.redis.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.type.TypeReference;

import pe.dinersclub.wscomercios.dto.usuario.TokenDTO;
import pe.dinersclub.wscomercios.log.BeanLog;
import pe.dinersclub.wscomercios.log.UtilLog;
import pe.dinersclub.wscomercios.log.UtilLogLevel;
import pe.dinersclub.wscomercios.util.UtilObjectMapper;


@EnableAsync
@Service
public class TokenLocalService {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private TokenCacheService tokenCacheService;
	@Autowired
	private UtilLog utilLog;

	// EL PARAMETRO "ID" ES EL IDUSUARIO

	@Async
	public void deleteAll(String identificador) {
		tokenCacheService.deleteAllRedis(identificador);
	}

	public void add(String identificador, TokenDTO tokenDTO) {
		
		BeanLog beanLog = new BeanLog();
		beanLog.setIdentificador(identificador);
		beanLog.setMetodo(new Object() {
		}.getClass().getEnclosingMethod().getName());
		try {
			tokenCacheService.addRedis(identificador, tokenDTO);
			
		} catch (Exception ex) {
			beanLog.setDescripcionMensaje(ex.getMessage());
			beanLog.setCausa(ex.getCause() != null ? ex.getCause().getMessage() : "");
			beanLog.setTipoMensaje(UtilLogLevel.ERROR.name());
			utilLog.printInfo(logger, beanLog);
			tokenCacheService.addLocal(identificador, tokenDTO);
		}
	}

	public TokenDTO findById(String identificador, String id) {
		BeanLog beanLog = new BeanLog();
		beanLog.setIdentificador(identificador);
		beanLog.setMetodo(new Object() {
		}.getClass().getEnclosingMethod().getName());
		try {
			return UtilObjectMapper.getObjectMapper().readValue(
					tokenCacheService.findByIdRedis(identificador, id),
					new TypeReference<TokenDTO>() {
					});
		} catch (InternalError ex) {
			// SI NO RETORNO DATOS LA CONSULTA
			return null;
		} catch (Exception ex) {
			beanLog.setDescripcionMensaje(ex.getMessage());
			beanLog.setCausa(ex.getCause() != null ? ex.getCause().getMessage() : "");
			beanLog.setTipoMensaje(UtilLogLevel.ERROR.name());
			utilLog.printInfo(logger, beanLog);
			return tokenCacheService.findByIdLocal(identificador, id);
		}
	}

	public void delete(String identificador, String id) {
		BeanLog beanLog = new BeanLog();
		beanLog.setIdentificador(identificador);
		beanLog.setMetodo(new Object() {
		}.getClass().getEnclosingMethod().getName());
		try {
			tokenCacheService.deleteRedis(identificador, id);
		} catch (Exception ex) {
			beanLog.setDescripcionMensaje(ex.getMessage());
			beanLog.setCausa(ex.getCause() != null ? ex.getCause().getMessage() : "");
			beanLog.setTipoMensaje(UtilLogLevel.ERROR.name());
			utilLog.printInfo(logger, beanLog);
		}
	}
}