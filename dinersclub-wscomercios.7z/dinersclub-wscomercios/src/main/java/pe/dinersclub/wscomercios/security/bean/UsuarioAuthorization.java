package pe.dinersclub.wscomercios.security.bean;

/**
 * 
 * Bean que permite extraer los datos del token y asiganarlos al objeto
 * principal
 *
 */

public class UsuarioAuthorization {

	private String idUsuario;
	private String empresa;
	private boolean acceso;

	public String getIdUsuario() {
		return idUsuario;
	}

	public void setIdUsuario(String idUsuario) {
		this.idUsuario = idUsuario;
	}

	public String getEmpresa() {
		return empresa;
	}

	public void setEmpresa(String empresa) {
		this.empresa = empresa;
	}

	public boolean isAcceso() {
		return acceso;
	}

	public void setAcceso(boolean acceso) {
		this.acceso = acceso;
	}

}
