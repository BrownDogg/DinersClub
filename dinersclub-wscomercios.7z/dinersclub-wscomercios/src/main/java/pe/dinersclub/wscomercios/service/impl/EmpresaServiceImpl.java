package pe.dinersclub.wscomercios.service.impl;

import java.util.LinkedList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pe.dinersclub.wscomercios.dao.ComercioDAO;
import pe.dinersclub.wscomercios.dao.EmpresaDAO;
import pe.dinersclub.wscomercios.domain.comercio.ComercioDomain;
import pe.dinersclub.wscomercios.domain.empresa.DatosCuentaDomain;
import pe.dinersclub.wscomercios.domain.empresa.DatosDireccionDomain;
import pe.dinersclub.wscomercios.domain.empresa.DatosTelefonoDomain;
import pe.dinersclub.wscomercios.domain.empresa.EmpresaDomain;
import pe.dinersclub.wscomercios.dto.comercio.ComercioDTO;
import pe.dinersclub.wscomercios.dto.comercio.DatosCuentasDTO;
import pe.dinersclub.wscomercios.dto.comercio.DatosDireccionDTO;
import pe.dinersclub.wscomercios.dto.comercio.DatosTelefonoDTO;
import pe.dinersclub.wscomercios.dto.empresa.EmpresaDTO;
import pe.dinersclub.wscomercios.service.EmpresaService;
import pe.dinersclub.wscomercios.util.UtilString;

@Service
public class EmpresaServiceImpl implements EmpresaService {

	@Autowired
	EmpresaDAO empresaDAO;
	
	@Autowired
	ComercioDAO comercioDAO;

	@Override
	public EmpresaDomain obtenerEmpresa(String idTransaccion, String rucEmpresa) {

		EmpresaDTO empresaDTO = null;
		EmpresaDomain empresaDom = null;

		try {

			empresaDTO = empresaDAO.obtenerDatosEmpresa(idTransaccion, rucEmpresa);

			if (empresaDTO != null)
				empresaDom = new EmpresaDomain(empresaDTO.getRucEmpresa(), empresaDTO.getRazonSocial());

		} catch (Exception e) {
			e.printStackTrace();
		}
		return empresaDom;
	}

	@Override
	public EmpresaDomain listarDatosComercios(String idTransaccion, String idEmpresa) {

		EmpresaDomain empresaDom = null;

		try {
			// 1. Obtener Datos Empresa
			EmpresaDTO empresaDto = empresaDAO.obtenerDatosEmpresa(idTransaccion, idEmpresa);

			if (empresaDto.getRucEmpresa().isEmpty())
				return null;

			empresaDom = new EmpresaDomain(empresaDto.getRucEmpresa(), empresaDto.getRazonSocial(),
					empresaDto.getRepLegal());

			// 2. Obtener Datos Comercio.
			List<ComercioDomain> listaComercioDom = obtenerDatosComercio(idTransaccion, empresaDom.getRucEmpresa());

			empresaDom.setListaComercio(listaComercioDom);

			return empresaDom;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	private List<ComercioDomain> obtenerDatosComercio(String idTransaccion, String idEmpresa) {

		// 2.1 Obtener Datos Comercio
		List<ComercioDomain> listadoComercios = null;
		List<DatosCuentaDomain> listaCuentasDom = null;
		List<DatosTelefonoDomain> listaTelefonosDom = null;
		List<DatosDireccionDomain> listaDireccionesDom = null;

		ComercioDomain comercioDom = null;
		DatosCuentaDomain cuentaDom = null;
		DatosTelefonoDomain telefonoDom = null;
		DatosDireccionDomain direccionDom = null;
		String direccionComercio = "";
		try {

			List<ComercioDTO> listaComerciosDto = empresaDAO.listarComercios(idTransaccion, idEmpresa);

			if (listaComerciosDto.isEmpty()) {
				return null;
			}

			// 2.1.1 Obtener Lista de Cuentas del comercio
			List<DatosCuentasDTO> listaCuentas = comercioDAO.listarCuentas(idTransaccion, idEmpresa, null);

			// 2.1.2 Obtener Lista de Telenefonos del comercio
			List<DatosTelefonoDTO> listaTelefonos = comercioDAO.listarTelefonos(idTransaccion, idEmpresa, null);

			// 2.1.3 Obtener Lista de Direcciones del comercio
			List<DatosDireccionDTO> listaDirecciones = comercioDAO.listarDirecciones(idTransaccion, idEmpresa, null);

			listadoComercios = new LinkedList<ComercioDomain>();

			for (ComercioDTO auxComercio : listaComerciosDto) {
				comercioDom = new ComercioDomain(auxComercio.getCodigoComercio(), auxComercio.getNombreComercio(),
						auxComercio.getPaginaWeb(), auxComercio.getCorreoCorporativo(),
						auxComercio.getCorreoComercial(), auxComercio.getEjecutivoComercio());

				listaCuentasDom = new LinkedList<>();
				for (DatosCuentasDTO auxCuenta : listaCuentas) {
					if (auxComercio.getCodigoComercio().equals(auxCuenta.getCodComercio())) {
						cuentaDom = new DatosCuentaDomain(auxCuenta.getNroCuenta(), auxCuenta.getBanco(),
								auxCuenta.getSistemaPago());
						listaCuentasDom.add(cuentaDom);
						comercioDom.setListaCuentas(listaCuentasDom);
					}
				}

				listaTelefonosDom = new LinkedList<>();
				for (DatosTelefonoDTO auxTelefono : listaTelefonos) {
					if (auxComercio.getCodigoComercio().equals(auxTelefono.getCodComercio())) {
						telefonoDom = new DatosTelefonoDomain(auxTelefono.getTipoTelefono(), auxTelefono.getNroTelefono());
						listaTelefonosDom.add(telefonoDom);
						comercioDom.setListaTelefonos(listaTelefonosDom);
					}
				}

				listaDireccionesDom = new LinkedList<>();
				for (DatosDireccionDTO auxDireccion : listaDirecciones) {
					if (auxComercio.getCodigoComercio().equals(auxDireccion.getCodComercio())) {
						direccionComercio = UtilString.getDireccionComercio(auxDireccion.getVia(),
								auxDireccion.getDireccionComercio(), auxDireccion.getNroDireccion(),
								auxDireccion.getCodigoPostal(), auxDireccion.getDepartamento(),
								auxDireccion.getProvincia(), auxDireccion.getDistrito());
						direccionDom = new DatosDireccionDomain(auxDireccion.getTipoDireccion(), direccionComercio);
						listaDireccionesDom.add(direccionDom);
						comercioDom.setListaDirecciones(listaDireccionesDom);
					}
				}
				listadoComercios.add(comercioDom);
			}

			return listadoComercios;

		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public List<ComercioDomain> listarComercios(String idTransaccion, String rucEmpresa) {

		List<ComercioDomain> listaDom = null;
		ComercioDomain comercioDom = null;
		List<ComercioDTO> listaDto = null;

		try {

			listaDto = empresaDAO.listarComercios(idTransaccion, rucEmpresa);

			if (!listaDto.isEmpty()) {
				listaDom = new LinkedList<>();
				for (ComercioDTO aux : listaDto) {
					comercioDom = new ComercioDomain(aux.getCodigoComercio(), aux.getNombreComercio());
					listaDom.add(comercioDom);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return listaDom;
	}

}
