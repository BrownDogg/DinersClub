package pe.dinersclub.wscomercios.domain;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.format.annotation.NumberFormat;

public class CadSolicitudesDinersRequest {

	@NotNull(message = "Se necesita el código de comercio.")
	@NumberFormat
	private Long codigoComercio;

	@Size(max = 10, message = "El codigo de comercio debe tener máximo 20 caracteres")
	private String codigoServicio;

	@NumberFormat
	private Long numeroTarjeta;

	private String fechaInicio;
	private String fechaFin;

	@NotNull(message = "No se indicó el número página")
	private Integer page;

	@NotNull(message = "No se indicó la cantidad de registros por página")
	private Integer xpage;

	public Long getCodigoComercio() {
		return codigoComercio;
	}

	public void setCodigoComercio(Long codigoComercio) {
		this.codigoComercio = codigoComercio;
	}

	public String getCodigoServicio() {
		return codigoServicio;
	}

	public void setCodigoServicio(String codigoServicio) {
		this.codigoServicio = codigoServicio;
	}

	public Long getNumeroTarjeta() {
		return numeroTarjeta;
	}

	public void setNumeroTarjeta(Long numeroTarjeta) {
		this.numeroTarjeta = numeroTarjeta;
	}

	public String getFechaInicio() {
		return fechaInicio;
	}

	public void setFechaInicio(String fechaInicio) {
		this.fechaInicio = fechaInicio;
	}

	public String getFechaFin() {
		return fechaFin;
	}

	public void setFechaFin(String fechaFin) {
		this.fechaFin = fechaFin;
	}

	public Integer getPage() {
		return page;
	}

	public void setPage(Integer page) {
		this.page = page;
	}

	public Integer getXpage() {
		return xpage;
	}

	public void setXpage(Integer xpage) {
		this.xpage = xpage;
	}

}
