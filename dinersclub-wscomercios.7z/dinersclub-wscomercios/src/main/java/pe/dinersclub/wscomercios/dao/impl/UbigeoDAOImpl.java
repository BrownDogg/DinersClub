package pe.dinersclub.wscomercios.dao.impl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.stereotype.Repository;

import pe.dinersclub.wscomercios.dao.UbigeoDAO;
import pe.dinersclub.wscomercios.util.ConnectionDB;
import pe.dinersclub.wscomercios.util.Globales;
import pe.dinersclub.wscomercios.util.UtilString;

@Repository
public class UbigeoDAOImpl implements UbigeoDAO {

	@Override
	public Map<String, String> listarDepartamentos() {

		LinkedHashMap<String, String> listaDepartamentos = null;
		Connection conn = null;
		CallableStatement cs = null;
		ResultSet rs = null;
		StringBuilder sbSQLConsulta = new StringBuilder();

		try {

			sbSQLConsulta.append(Globales.CALL_SP).append(Globales.ESQUEMA_PROC);
			sbSQLConsulta.append(".").append("SP_WSC_LISTAR_DEPARTAMENTOS").append("()}");
			conn = ConnectionDB.getConnectionServerAS400();
			cs = conn.prepareCall(sbSQLConsulta.toString());
			cs.execute();
			rs = cs.getResultSet();

			if (rs != null) {
				listaDepartamentos = new LinkedHashMap<>();
				while (rs.next()) {
					listaDepartamentos.put(rs.getString("ID_DEPT").trim(), rs.getString("DESC_DEPT").trim());
				}
			}
			return listaDepartamentos;

		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (cs != null)
					cs.close();
				if (conn != null)
					conn.close();
			} catch (SQLException ex) {
			}
		}
	}

	@Override
	public Map<String, String> listarProvincias(String idDepartamento) {

		LinkedHashMap<String, String> listaProvincias = null;
		Connection conn = null;
		CallableStatement cs = null;
		ResultSet rs = null;
		StringBuilder sbSQLConsulta = new StringBuilder();

		try {

			sbSQLConsulta.append(Globales.CALL_SP).append(Globales.ESQUEMA_PROC);
			sbSQLConsulta.append(".").append("SP_WSC_LISTAR_PROVINCIAS").append("(?)}");
			conn = ConnectionDB.getConnectionServerAS400();
			cs = conn.prepareCall(sbSQLConsulta.toString());
			cs.setString(1, idDepartamento);
			cs.execute();
			rs = cs.getResultSet();

			if (rs != null) {
				listaProvincias = new LinkedHashMap<>();
				while (rs.next()) {
					listaProvincias.put(rs.getString("ID_PROV").trim(), rs.getString("DESC_PROV").trim());
				}
			}
			return listaProvincias;

		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (cs != null)
					cs.close();
				if (conn != null)
					conn.close();
			} catch (SQLException ex) {
			}
		}
	}

	@Override
	public Map<String, String> listarDistritos(String idDepartamento, String idProvincia) {

		LinkedHashMap<String, String> listaDistritos = null;
		Connection conn = null;
		CallableStatement cs = null;
		ResultSet rs = null;
		StringBuilder sbSQLConsulta = new StringBuilder();
		String codDistrito = "";
		String descDistrito = "";

		try {

			sbSQLConsulta.append(Globales.CALL_SP).append(Globales.ESQUEMA_PROC);
			sbSQLConsulta.append(".").append("SP_WSC_LISTAR_DISTRITOS").append("(?,?)}");
			conn = ConnectionDB.getConnectionServerAS400();
			cs = conn.prepareCall(sbSQLConsulta.toString());
			cs.setString(1, idDepartamento);
			cs.setString(2, idProvincia);
			cs.execute();
			rs = cs.getResultSet();

			if (rs != null) {
				listaDistritos = new LinkedHashMap<>();
				while (rs.next()) {
					codDistrito = rs.getString("ID_DIST").trim();
					descDistrito = UtilString.splitString(rs.getString("DESC_DIST"), "  ");
					listaDistritos.put(codDistrito, descDistrito);
				}
			}
			return listaDistritos;

		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (cs != null)
					cs.close();
				if (conn != null)
					conn.close();
			} catch (SQLException ex) {
			}
		}
	}

}
