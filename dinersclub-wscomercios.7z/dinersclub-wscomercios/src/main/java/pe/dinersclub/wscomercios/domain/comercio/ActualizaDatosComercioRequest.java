package pe.dinersclub.wscomercios.domain.comercio;

import java.util.List;

public class ActualizaDatosComercioRequest {

	private String codigoComercio;
	private String sitioWeb;
	private String correoComercial;
	private List<TelefonoComercio> listaTelefonos;
	private List<DireccionComercio> listaDirecciones;

	
	public String getCodigoComercio() {
		return codigoComercio;
	}

	public void setCodigoComercio(String codigoComercio) {
		this.codigoComercio = codigoComercio;
	}
	
	public String getSitioWeb() {
		return sitioWeb;
	}

	public void setSitioWeb(String sitioWeb) {
		this.sitioWeb = sitioWeb;
	}

	public String getCorreoComercial() {
		return correoComercial;
	}

	public void setCorreoComercial(String correoComercial) {
		this.correoComercial = correoComercial;
	}

	public List<TelefonoComercio> getListaTelefonos() {
		return listaTelefonos;
	}

	public void setListaTelefonos(List<TelefonoComercio> listaTelefonos) {
		this.listaTelefonos = listaTelefonos;
	}

	public List<DireccionComercio> getListaDirecciones() {
		return listaDirecciones;
	}

	public void setListaDirecciones(List<DireccionComercio> listaDirecciones) {
		this.listaDirecciones = listaDirecciones;
	}

	@Override
	public String toString() {
		return "ActualizaDatosComercioRequest [codigoComercio=" + codigoComercio + ", sitioWeb=" + sitioWeb
				+ ", correoComercial=" + correoComercial + ", listaTelefonos=" + listaTelefonos + ", listaDirecciones="
				+ listaDirecciones + "]";
	}
	
}
