package pe.dinersclub.wscomercios.util;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "app")
public class Globales {

	
	public static String CALL_SP = "{CALL ";
	public static String ESQUEMA_PROC = "AYPDIAZE";

	public static int REQUEST_REMOTE_TIMEOUT = 1500;
	public static boolean USE_PROXY = true;
	public static String PROXY_HOST = "100.10.1.51";
	public static String PROXY_PORT = "8080";
	
	public static String GoogleRecaptchaApiKey = "6LetkEYUAAAAAG3X5R5PoW082mC_a4xcTr40JFK6";
	public static String GoogleRecaptchaURL = "https://www.google.com/recaptcha/api/siteverify";
	
	//REDIS
	public static int CACHE_USUARIO_HORA_FENCIMIENTO = 4;
	public static int CACHE_USUARIO_MINUTO_FENCIMIENTO = 0;
	

	// PARAMETROS DE MANEJO DE ARCHIVOS

	public static String uploadDir = "C:\\Sistemas\\pdf\\upload";
	public static String uploadDirDevolucion = "C:\\DinersProjects\\OGP-DF-10-2019\\Testing\\upload";

	// PARÁMETROS DE SEGURIDAD
	public static int FLG_ACCESO_PERMITIDO = 1;
	public static int FLG_ACCESO_DENEGADO = 0; // este valor solicitará cambio de contraseña.
	public static int FLG_USUARIO_NO_BLOQUEADO = 1;
	public static int FLG_USUARIO_BLOQUEADO = 0;
	public static int REINICIAR_ACCESOS_FALLIDOS = 0;

	// PROCEDURES TRANSACCIONES
	public static String SP_WSC_LISTARVENTASXCOMERCIO = "SP_WSC_LISTARVENTASXCOMERCIO";
	public static String SP_WSC_CANTIDADVENTASXCOMERCIO = "SP_WSC_CANTIDADVENTASXCOMERCIO";
	public static String SP_WSC_LISTARVENTASXEMPRESA = "SP_WSC_LISTARVENTASXEMPRESA";
	public static String SP_WSC_CANTIDADVENTASXEMPRESA = "SP_WSC_CANTIDADVENTASXEMPRESA";

	// PARAMETROS CAD

	public static String CAD_ESTADO_AFILIADO = "0";
	public static String CAD_ESTADO_DESAFILIADO = "9";
	public static String CAD_FLAG_SOLICITUD_AFILIACION = "A";
	public static String CAD_FLAG_SOLICITUD_DESAFILIACION = "D";
	public static String CAD_SERVICIO_NO_ES_PROCESO_EN_AUTOMATICO = "N";
	public static String CAD_TIPO_BOLSA_MANTENIMIENTO = "88";
	public static String MONTO_TOPE_DEFECTO = "0000010000";

	// PROCEDURES CAD
	public static String SP_WSC_LISTARSOLICITUDESCADDINERS = "SP_WSC_LISTARSOLICITUDESCADDINERS";
	public static String SP_WSC_CANTIDADSOLICITUDESCADDINERS = "SP_WSC_CANTIDADSOLICITUDESCADDINERS";
	public static String SP_WSC_DESCARGARSOLICITUDESCADDINERS = "SP_WSC_DESCARGARSOLICITUDESCADDINERS";
	public static String SP_WSC_BUSCARTARJETA = "SP_WSC_BUSCARTARJETA";
	public static String SP_WSC_OBTENERSERVICIOCAD = "SP_WSC_OBTENERSERVICIOCAD";
	public static String SP_WSC_OBTENERCORRELATIVOBOLSA = "SP413001";
	public static String SP_WSC_GRABARAFILIACIONINDIVIDUAL = "SP413225";
	public static String SP_WSC_LISTARAFILIACIONESCAD = "SP_WSC_LISTARAFILIACIONESCAD";
	public static String SP_WSC_CANTIDADAFILIACIONESCAD = "SP_WSC_CANTIDADAFILIACIONESCAD";
	public static String SP_WSC_OBTENERFILTRO = "SP_WSC_OBTENERFILTRO";
	public static String SP_WSC_OBTENERFILTROPORIDDCP = "SP_WSC_OBTENERFILTROPORIDDCP";
	public static String SP_WSC_GRABABOLSAMANTENIMIENTO = "SP413228";
	public static String SP_WSC_GRABADETALLEBOLSAMANTENIMIENTO = "SP413227";

	// PROCEDURES USUARIOS

	public static String SP_WSC_OBTENEROPCIONESDEMENU = "SP_WSC_OBTENEROPCIONESDEMENU";
	public static String SP_WSC_OBTENERDATOSUSUARIOEMPRESA = "SP_WSC_OBTENERDATOSUSUARIOEMPRESA";
	public static String SP_WSC_OBTENERCOMERCIOSXUSUARIO = "SP_WSC_OBTENERCOMERCIOSXUSUARIO";
	public static String SP_WSC_OBTENERUSUARIOXUSERNAME = "SP_WSC_OBTENERUSUARIOXUSERNAME";
	public static String SP_WSC_OBTENERUSUARIOXID = "SP_WSC_OBTENERUSUARIOXID";
	public static String SP_WSC_OBTENERROLESDEUSUARIO = "SP_WSC_OBTENERROLESDEUSUARIO";
	public static String SP_WSC_ACTUALIZARPASSWORD = "SP_WSC_ACTUALIZARPASSWORD";
	public static String SP_WSC_ACTUALIZARFLGACCESOUSUARIO = "SP_WSC_ACTUALIZARFLGACCESOUSUARIO";
	public static String SP_WSC_ACTUALIZARFLGESTADOUSUARIO = "SP_WSC_ACTUALIZARFLGESTADOUSUARIO";
	public static String SP_WSC_ACTUALIZARFLGBLOQUEOUSUARIO = "SP_WSC_ACTUALIZARFLGBLOQUEOUSUARIO";
	public static String SP_WSC_ACTUALIZARACCESOSFALLIDOS = "SP_WSC_ACTUALIZARACCESOSFALLIDOS";
	public static String SP_WSC_REGISTRARTOKEN = "SP_WSC_REGISTRARTOKEN";
	public static String SP_WSC_CONSULTARTOKENXIDUSUARIO = "SP_WSC_CONSULTARTOKENXIDUSUARIO";

	// PARÁMETROS MENSAJERIA
	public static String urlEnviarSolicitud = "http://172.24.34.171:28080/dinersclub-sendmail/enviarSolicitud";
	public static String urlRecuperaPassword = "http://172.24.34.171:28080/dinersclub-sendmail";
	public static String PLANTILLA_RECUPERA_CLAVE = "51";

	public static int CANTIDAD_DE_MESES_RANGO_INICIO = -12;

	/**
	 * CODIGOS DE RESPUESTA
	 */
	public static String RESPUESTA_EXITO = "000";
	public static String FECHA_INICIO_MENOR_AL_RANGO_PERMITIDO = "001";
	public static String FECHA_FIN_MENOR_A_FECHA_INICIO = "002";
	public static String SOLICITUD_SIN_RESULTADOS = "003";
	public static String OCURRIO_UN_PROBLEMA_AL_PROCESAR = "500";
	public static String VALORES_RECIBIDOS_INCORRECTOS = "005";
	public static String OCURRIO_UN_PROBLEMA_AL_ENVIAR_EMAIL = "020";
	public static String RESPUESTA_ERROR_BD = "90001";
	public static String RESPUESTA_ERROR_WS = "90002";
	public static String RESPUESTA_ERROR_GENERICO = "90003";
	public static String RESPUESTA_ERROR_MAIL = "90004";

	// CODIGOS DE RESPUESTA PARA SEGURIDAD

	public static String USUARIO_NO_EXISTE = "004";
	public static String USUARIO_SIN_ROLES_ASIGNADOS = "005";
	public static String PASSWORD_NO_CUMPLE_POLITICAS = "006";
	public static String OCURRIO_UN_PROBLEMA_AL_ACTUALIZAR_PASSWORD = "007";
	public static String ERROR_AL_RECUPERAR_PASSWORD = "007";
	public static String USUARIO_PASSWORD_CAPTCHA_INCORRECTO = "008";
	public static String USUARIO_BLOQUEADO = "009";

	// CODIGOS DE RESPUESTA PARA TRANSACCIONES

	// CODIGOS DE RESPUESTA PARA CAD

	public static String NUMERO_TARJETA_NO_NUMERICO = "021";

	public static String SERVICIO_NO_SE_ENCUENTRA_AFILIADO_AL_CAD = "016";
	public static String TARJETA_NO_CORRESPONDE_AL_SERVICIO = "098";

	public static String SERVICIO_SE_ENCUENTRA_AFILIADO = "013";
	public static String ARCHIVO_CON_FORMATO_INCORRECTO = "017";
	public static String VENCIMIENTO_TARJETA_NO_VALIDO = "018";
	public static String CODIGO_DE_COMERCIO_INCORRECTO = "023";
	public static String NO_COINCIDE_NUMERO_DE_REGISTROS = "026";
	public static String FECHA_ENVIO_MAYOR_QUE_HOY = "034";
	public static String SERVICIO_EN_ESTADO_DESAFILIADO = "039";
	public static String CODIGO_DE_SERVICIO_ES_BLANCO = "042";
	public static String REGISTROS_DEL_ARCHIVO_CON_ERROR = "059";
	public static String TARJETA_NO_EXISTE = "081";
	public static String TARJETA_NO_ACTIVA = "083";
	public static String TARJETA_VENCIDA = "084";
	public static String TIPO_DE_MANTENIMIENTO_INVALIDO = "099";
	public static String ARCHIVO_SIN_REGISTROS = "100";
	public static String TIPO_DE_MANTENIMIENTO_NO_CORRESPONDE_AL_SOLICITADO = "301";
	public static String NUMERO_DE_TARJETA_DEBE_SER_NUMERICO = "302";
	public static String NOMBRE_USUARIO_DE_SERVICIO_EN_BLANCO = "303";
	public static String LONGITUD_DOCUMENTO_MENOR_8_DIGITOS = "304";
	public static String MONTO_TOPE_DEBE_SER_NUMERICO = "305";
	public static String PROBLEMA_AL_PROCESAR_EL_ARCHIVO = "306";
	public static String ARCHIVO_CON_ERROR_DE_ESTRUCTURA = "307";

	
	public static final class ModuloEmpresa{
		//03
		public static String EMPRESA_NO_ENCONTRADA = "03001";
		public static String COMERCIOS_NO_ENCONTRADOS = "03002";
		
	}
	
	public static final class ModuloComercio{
		//04
		public static String COMERCIO_NO_ENCONTRADO = "04001";
		public static String COMERCIO_ACTUALIZA_ERROR = "04002";
		
	}
	
	public static final class ModuloTransacciones{
		
		//05
		public static String DEVOLUCIONES_NO_ENCONTRADAS = "05001";
		public static String CONSUMOS_NO_ENCONTRADOS = "05002";
		public static String VENTAS_NO_ENCONTRADAS = "05003";
		public static String REGISTRAR_DEVOLUCION_ERROR = "05004";
		
		
		public static String CODIGO_COMERCIO_INCORRECTO = "05010";
		public static String NUMERO_TARJETA_NO_NUMERICO = "05011";
		public static String FORMATO_FECHA_INCORRECTO = "05012";
		public static String CODIGO_AUTORIZACION_NO_NUMERICO = "05013";
		public static String NUMERO_TICKET_NO_NUMERICO = "05014";
		public static String TIPO_MONEDA_INCORRECTO = "05015";
		public static String IMPORTE_CONSUMO_NO_NUMERICO = "05016";
		public static String IMPORTE_DEVOLUCION_NO_NUMERICO = "05017";
		public static String TIPO_DEVOLUCION_INCORRECTO = "05018";
		public static String REFERENCIA_DEVOLUCION_lONGITUD = "05019";
		public static String OBSERVACION_DEVOLUCION_lONGITUD = "05020";
		
		public static String ORIGEN_TRANSACCION_CONTROVERSIAS = "001";
		public static String ORIGEN_TRANSACCION_POR_COMERCIO = "002";
		public static String ESTADO_DEVOLUCION_REGISTRADO = "001";
		
	}

	public static final class ModuloLiquidaciones{
		//06
		public static String LIQUIDACIONES_NO_ENCONTRADAS = "06001";
		public static String LIQUIDACIONES_DETALLE_NO_ENCONTRADAS = "06002";
	}

	
	
	//GENERALES
	public static String SOLICITUD_PROCESADA_CORRECTAMENTE = "Solicitud procesada correctamente";
	public static String CONSULTA_SIN_RESULTADO = "Sin resultados para la consulta";
	
	public static int DEVOLUCION_INDIVIDUAL = 1;
	public static String TIPO_MONEDA_SOLES_KEY = "604";
	public static String TIPO_MONEDA_SOLES_VALUE = "S";
	public static String TIPO_MONEDA_DOLARES_KEY = "840";
	public static String TIPO_MONEDA_DOLARES_VALUE = "D";
	public static String TIPO_DEVOLUCION_TOTAL_KEY = "001";
	public static String TIPO_DEVOLUCION_TOTAL_VALUE = "TOTAL";
	public static String TIPO_DEVOLUCION_PARCIAL_KEY = "002";
	public static String TIPO_DEVOLUCION_PARCIAL_VALUE = "PARCIAL";
	public static String FORMATO_FECHA_YYYYMMDD = "yyyyMMdd";
	
	
	
	
}
