package pe.dinersclub.wscomercios.dto.usuario;

import java.util.List;

public class Usuario {

	private Long idUsuario;
	private String username;
	private String password;
	private String usuNombres;
	private String usuApellidos;
	private String rucEmpresa;
	private boolean estado;
	private boolean accesoCambioPassword;
	private boolean noBloqueado;
	private Integer cantAccesos;
	private String email;
	private List<Rol> roles;

	public Long getIdUsuario() {
		return idUsuario;
	}

	public void setIdUsuario(Long idUsuario) {
		this.idUsuario = idUsuario;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getUsuNombres() {
		return usuNombres;
	}

	public void setUsuNombres(String usuNombres) {
		this.usuNombres = usuNombres;
	}

	public String getUsuApellidos() {
		return usuApellidos;
	}

	public void setUsuApellidos(String usuApellidos) {
		this.usuApellidos = usuApellidos;
	}

	public String getRucEmpresa() {
		return rucEmpresa;
	}

	public void setRucEmpresa(String rucEmpresa) {
		this.rucEmpresa = rucEmpresa;
	}

	public boolean isEstado() {
		return estado;
	}

	public void setEstado(boolean estado) {
		this.estado = estado;
	}

	public boolean isAccesoCambioPassword() {
		return accesoCambioPassword;
	}

	public void setAccesoCambioPassword(boolean accesoCambioPassword) {
		this.accesoCambioPassword = accesoCambioPassword;
	}

	public boolean isNoBloqueado() {
		return noBloqueado;
	}

	public void setNoBloqueado(boolean noBloqueado) {
		this.noBloqueado = noBloqueado;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public List<Rol> getRoles() {
		return roles;
	}

	public void setRoles(List<Rol> roles) {
		this.roles = roles;
	}

	public Integer getCantAccesos() {
		return cantAccesos;
	}

	public void setCantAccesos(Integer cantAccesos) {
		this.cantAccesos = cantAccesos;
	}

}
