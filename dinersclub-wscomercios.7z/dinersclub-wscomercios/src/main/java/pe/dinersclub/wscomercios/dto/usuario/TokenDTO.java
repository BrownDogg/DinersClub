package pe.dinersclub.wscomercios.dto.usuario;

import java.util.Date;

public class TokenDTO {

	private String idUsuario;
	private String tokenAcceso;
	private Date fechaAcceso;

	public TokenDTO() {
	}
	
	public TokenDTO(String idUsuario, String tokenAcceso, Date fechaAcceso) {
		this.idUsuario = idUsuario;
		this.tokenAcceso = tokenAcceso;
		this.fechaAcceso = fechaAcceso;
	}

	public String getIdUsuario() {
		return idUsuario;
	}

	public void setIdUsuario(String idUsuario) {
		this.idUsuario = idUsuario;
	}

	public String getTokenAcceso() {
		return tokenAcceso;
	}

	public void setTokenAcceso(String tokenAcceso) {
		this.tokenAcceso = tokenAcceso;
	}

	public Date getFechaAcceso() {
		return fechaAcceso;
	}

	public void setFechaAcceso(Date fechaAcceso) {
		this.fechaAcceso = fechaAcceso;
	}

}
