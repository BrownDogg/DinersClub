package pe.dinersclub.wscomercios.domain.empresa;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import pe.dinersclub.wscomercios.domain.comercio.ComercioDomain;

public class EmpresaDomain {

	private String rucEmpresa;
	private String razonSocial;
	@JsonInclude(Include.NON_NULL)
	private String repLegal;
	@JsonInclude(Include.NON_NULL)
	private List<ComercioDomain> listaComercio;
	
	public EmpresaDomain() {
		super();
	}

	public EmpresaDomain(String rucEmpresa, String razonSocial, String repLegal) {
		super();
		this.rucEmpresa = rucEmpresa;
		this.razonSocial = razonSocial;
		this.repLegal = repLegal;
	}

	public EmpresaDomain(String rucEmpresa, String razonSocial) {
		super();
		this.rucEmpresa = rucEmpresa;
		this.razonSocial = razonSocial;
	}

	public String getRucEmpresa() {
		return rucEmpresa;
	}
	public void setRucEmpresa(String rucEmpresa) {
		this.rucEmpresa = rucEmpresa;
	}
	public String getRazonSocial() {
		return razonSocial;
	}
	public void setRazonSocial(String razonSocial) {
		this.razonSocial = razonSocial;
	}
	public String getRepLegal() {
		return repLegal;
	}
	public void setRepLegal(String repLegal) {
		this.repLegal = repLegal;
	}
	public List<ComercioDomain> getListaComercio() {
		return listaComercio;
	}
	public void setListaComercio(List<ComercioDomain> listaComercio) {
		this.listaComercio = listaComercio;
	}
	
}
