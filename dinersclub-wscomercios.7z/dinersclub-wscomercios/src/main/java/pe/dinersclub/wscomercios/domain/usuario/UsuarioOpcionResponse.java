package pe.dinersclub.wscomercios.domain.usuario;

public class UsuarioOpcionResponse {

	private String codigo;
	private String nombreOpcion;
	private Boolean isConsulta;
	private Boolean isTransaccional;

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public String getNombreOpcion() {
		return nombreOpcion;
	}

	public void setNombreOpcion(String nombreOpcion) {
		this.nombreOpcion = nombreOpcion;
	}

	public Boolean getIsConsulta() {
		return isConsulta;
	}

	public void setIsConsulta(Boolean isConsulta) {
		this.isConsulta = isConsulta;
	}

	public Boolean getIsTransaccional() {
		return isTransaccional;
	}

	public void setIsTransaccional(Boolean isTransaccional) {
		this.isTransaccional = isTransaccional;
	}

}
