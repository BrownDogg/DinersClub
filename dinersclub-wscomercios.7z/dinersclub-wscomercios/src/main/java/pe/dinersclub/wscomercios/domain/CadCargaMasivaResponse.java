package pe.dinersclub.wscomercios.domain;

import java.util.List;

import pe.dinersclub.wscomercios.dto.cad.CadMasivaRegistroRespuesta;

public class CadCargaMasivaResponse {

	private Integer codigoPrecarga;
	private Integer numeroRegistros;
	private Integer registrosCorrectos;
	private Integer registrosFallidos;
	private List<CadMasivaRegistroRespuesta> registrosDetalle;

	public Integer getCodigoPrecarga() {
		return codigoPrecarga;
	}

	public void setCodigoPrecarga(Integer codigoPrecarga) {
		this.codigoPrecarga = codigoPrecarga;
	}

	public Integer getNumeroRegistros() {
		return numeroRegistros;
	}

	public void setNumeroRegistros(Integer numeroRegistros) {
		this.numeroRegistros = numeroRegistros;
	}

	public Integer getRegistrosCorrectos() {
		return registrosCorrectos;
	}

	public void setRegistrosCorrectos(Integer registrosCorrectos) {
		this.registrosCorrectos = registrosCorrectos;
	}

	public Integer getRegistrosFallidos() {
		return registrosFallidos;
	}

	public void setRegistrosFallidos(Integer registrosFallidos) {
		this.registrosFallidos = registrosFallidos;
	}

	public List<CadMasivaRegistroRespuesta> getRegistrosDetalle() {
		return registrosDetalle;
	}

	public void setRegistrosDetalle(List<CadMasivaRegistroRespuesta> registrosDetalle) {
		this.registrosDetalle = registrosDetalle;
	}

}
