package pe.dinersclub.wscomercios.domain;

import java.util.List;

import pe.dinersclub.wscomercios.dto.cad.CadSolicitudDiners;

public class CadSolicitudesDinersResponse {

	private Long cantidad;
	private List<CadSolicitudDiners> cadSolicitudesDiners;

	public Long getCantidad() {
		return cantidad;
	}

	public void setCantidad(Long cantidad) {
		this.cantidad = cantidad;
	}

	public List<CadSolicitudDiners> getCadSolicitudesDiners() {
		return cadSolicitudesDiners;
	}

	public void setCadSolicitudesDiners(List<CadSolicitudDiners> cadSolicitudesDiners) {
		this.cadSolicitudesDiners = cadSolicitudesDiners;
	}

}
