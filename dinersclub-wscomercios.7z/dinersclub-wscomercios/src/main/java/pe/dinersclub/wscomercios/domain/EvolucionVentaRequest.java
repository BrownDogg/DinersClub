package pe.dinersclub.wscomercios.domain;

import javax.validation.constraints.NotNull;

public class EvolucionVentaRequest {

	private String idEmpresa;
	private String idComercio;
	private String moneda;
	private String fechaInicio;
	private String fechaFin;
	
	@NotNull
	public String getIdEmpresa() {
		return idEmpresa;
	}
	public void setIdEmpresa(String idEmpresa) {
		this.idEmpresa = idEmpresa;
	}
	public String getIdComercio() {
		return idComercio;
	}
	public void setIdComercio(String idComercio) {
		this.idComercio = idComercio;
	}
	public String getMoneda() {
		return moneda;
	}
	public void setMoneda(String moneda) {
		this.moneda = moneda;
	}
	public String getFechaInicio() {
		return fechaInicio;
	}
	public void setFechaInicio(String fechaInicio) {
		this.fechaInicio = fechaInicio;
	}
	public String getFechaFin() {
		return fechaFin;
	}
	public void setFechaFin(String fechaFin) {
		this.fechaFin = fechaFin;
	}
	@Override
	public String toString() {
		return "EvolucionVentaRequest [idEmpresa=" + idEmpresa + ", idComercio=" + idComercio + ", moneda=" + moneda
				+ ", fechaInicio=" + fechaInicio + ", fechaFin=" + fechaFin + "]";
	}
	
	
	
}
