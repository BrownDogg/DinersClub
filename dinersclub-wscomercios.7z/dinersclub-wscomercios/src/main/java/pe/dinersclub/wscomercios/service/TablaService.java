package pe.dinersclub.wscomercios.service;

import java.util.LinkedHashMap;

public interface TablaService {

	public LinkedHashMap<String,String> obtenerFiltro(String identificador, String codigoFiltro);

}
