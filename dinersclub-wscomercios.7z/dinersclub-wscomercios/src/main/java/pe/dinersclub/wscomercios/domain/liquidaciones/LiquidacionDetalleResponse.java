package pe.dinersclub.wscomercios.domain.liquidaciones;

public class LiquidacionDetalleResponse {

	private String codAntiguo;
	private String fecRecep;
	private String codComercio;
	private String codRecap;
	private String nroTicket;
	private String tarjetaSocio;
	private String fecTicket;
	private String impTicket;
	private String impComTicket;
	private String moneda;
	private String nroAut;
	private String correlativo;
	private String estado;
	private String impIgvTicket;
	private String impComiTicket;
	private String impNoComiTicket;
	private String docAut;
	private String cuenta;
	private String fecPagoEfect;
	private String formaPago;
	private String banco;
	private String impAjuste;
	private String nroComprobante;
	
	public String getCodAntiguo() {
		return codAntiguo;
	}
	public void setCodAntiguo(String codAntiguo) {
		this.codAntiguo = codAntiguo;
	}
	public String getFecRecep() {
		return fecRecep;
	}
	public void setFecRecep(String fecRecep) {
		this.fecRecep = fecRecep;
	}
	public String getCodComercio() {
		return codComercio;
	}
	public void setCodComercio(String codComercio) {
		this.codComercio = codComercio;
	}
	public String getCodRecap() {
		return codRecap;
	}
	public void setCodRecap(String codRecap) {
		this.codRecap = codRecap;
	}
	public String getNroTicket() {
		return nroTicket;
	}
	public void setNroTicket(String nroTicket) {
		this.nroTicket = nroTicket;
	}
	public String getTarjetaSocio() {
		return tarjetaSocio;
	}
	public void setTarjetaSocio(String tarjetaSocio) {
		this.tarjetaSocio = tarjetaSocio;
	}
	public String getFecTicket() {
		return fecTicket;
	}
	public void setFecTicket(String fecTicket) {
		this.fecTicket = fecTicket;
	}
	public String getImpTicket() {
		return impTicket;
	}
	public void setImpTicket(String impTicket) {
		this.impTicket = impTicket;
	}
	public String getImpComTicket() {
		return impComTicket;
	}
	public void setImpComTicket(String impComTicket) {
		this.impComTicket = impComTicket;
	}
	public String getMoneda() {
		return moneda;
	}
	public void setMoneda(String moneda) {
		this.moneda = moneda;
	}
	public String getNroAut() {
		return nroAut;
	}
	public void setNroAut(String nroAut) {
		this.nroAut = nroAut;
	}
	public String getCorrelativo() {
		return correlativo;
	}
	public void setCorrelativo(String correlativo) {
		this.correlativo = correlativo;
	}
	public String getEstado() {
		return estado;
	}
	public void setEstado(String estado) {
		this.estado = estado;
	}
	public String getImpIgvTicket() {
		return impIgvTicket;
	}
	public void setImpIgvTicket(String impIgvTicket) {
		this.impIgvTicket = impIgvTicket;
	}
	public String getImpComiTicket() {
		return impComiTicket;
	}
	public void setImpComiTicket(String impComiTicket) {
		this.impComiTicket = impComiTicket;
	}
	public String getImpNoComiTicket() {
		return impNoComiTicket;
	}
	public void setImpNoComiTicket(String impNoComiTicket) {
		this.impNoComiTicket = impNoComiTicket;
	}
	public String getDocAut() {
		return docAut;
	}
	public void setDocAut(String docAut) {
		this.docAut = docAut;
	}
	public String getCuenta() {
		return cuenta;
	}
	public void setCuenta(String cuenta) {
		this.cuenta = cuenta;
	}
	public String getFecPagoEfect() {
		return fecPagoEfect;
	}
	public void setFecPagoEfect(String fecPagoEfect) {
		this.fecPagoEfect = fecPagoEfect;
	}
	public String getFormaPago() {
		return formaPago;
	}
	public void setFormaPago(String formaPago) {
		this.formaPago = formaPago;
	}
	public String getBanco() {
		return banco;
	}
	public void setBanco(String banco) {
		this.banco = banco;
	}
	public String getImpAjuste() {
		return impAjuste;
	}
	public void setImpAjuste(String impAjuste) {
		this.impAjuste = impAjuste;
	}
	public String getNroComprobante() {
		return nroComprobante;
	}
	public void setNroComprobante(String nroComprobante) {
		this.nroComprobante = nroComprobante;
	}
	
}
