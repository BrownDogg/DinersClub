package pe.dinersclub.wscomercios.domain.empresa;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

public class DatosCuentaDomain {

	@JsonInclude(Include.NON_NULL)
	private String codComercio;
	private String nroCuenta;
	private String banco;
	private String sistemaPago;
	
	public DatosCuentaDomain() {
		super();
	}
	
	public DatosCuentaDomain(String nroCuenta, String banco, String sistemaPago) {
		super();
		this.nroCuenta = nroCuenta;
		this.banco = banco;
		this.sistemaPago = sistemaPago;
	}
	
	public String getNroCuenta() {
		return nroCuenta;
	}
	public void setNroCuenta(String nroCuenta) {
		this.nroCuenta = nroCuenta;
	}
	public String getBanco() {
		return banco;
	}
	public void setBanco(String banco) {
		this.banco = banco;
	}
	public String getSistemaPago() {
		return sistemaPago;
	}
	public void setSistemaPago(String sistemaPago) {
		this.sistemaPago = sistemaPago;
	}

	public String getCodComercio() {
		return codComercio;
	}

	public void setCodComercio(String codComercio) {
		this.codComercio = codComercio;
	}
}
