package pe.dinersclub.wscomercios.domain;

import java.math.BigDecimal;

public class VentaXRango {

	private String descripcionRango;
	private BigDecimal importeRango;
	
	public String getDescripcionRango() {
		return descripcionRango;
	}
	public void setDescripcionRango(String descripcionRango) {
		this.descripcionRango = descripcionRango;
	}
	public BigDecimal getImporteRango() {
		return importeRango;
	}
	public void setImporteRango(BigDecimal importeRango) {
		this.importeRango = importeRango;
	}
	
	@Override
	public String toString() {
		return "VentaXRango [descripcionRango=" + descripcionRango + ", importeRango=" + importeRango + "]";
	}
	
}
