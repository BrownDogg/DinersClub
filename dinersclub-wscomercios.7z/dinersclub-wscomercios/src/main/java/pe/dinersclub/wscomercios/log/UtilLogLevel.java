package pe.dinersclub.wscomercios.log;

public enum UtilLogLevel {
	DEBUG, ERROR, FATAL, INFO, TRACE, WARN;
}
