package pe.dinersclub.wscomercios.service;

import pe.dinersclub.wscomercios.domain.CadAfiliacionIndividualRequest;
import pe.dinersclub.wscomercios.domain.CadCargaMasivaResponse;
import pe.dinersclub.wscomercios.domain.CadDesafiliacionIndividualRequest;
import pe.dinersclub.wscomercios.domain.BuscarTarjetaResponse;
import pe.dinersclub.wscomercios.domain.CadDescargaSolicitudesDinersRequest;
import pe.dinersclub.wscomercios.domain.CadListarAfiliacionesRequest;
import pe.dinersclub.wscomercios.domain.CadListarAfiliacionesResponse;
import pe.dinersclub.wscomercios.domain.CadSolicitudesDinersRequest;
import pe.dinersclub.wscomercios.domain.CadSolicitudesDinersResponse;

public interface CadService {

	public CadSolicitudesDinersResponse listarCadSolicitudesDiners(String identificador,
			CadSolicitudesDinersRequest cadSolicitudesDinersRequest);

	public byte[] descargarCadSolicitudesDinersFormatoAfiliacionMasivaTxt(String identificador,
			CadDescargaSolicitudesDinersRequest cadDescargaSolicitudesDinersRequest) throws Exception;

	public BuscarTarjetaResponse buscarTarjeta(String identificador, Long numeroTarjeta);

	public String afiliarCadIndividual(String identificador,
			CadAfiliacionIndividualRequest cadAfiliacionIndividualRequest);

	public String desafiliarCadIndividual(String identificador,
			CadDesafiliacionIndividualRequest cadDesafiliacionIndividualRequest);

	public CadListarAfiliacionesResponse listarCadAfiliaciones(String identificador,
			CadListarAfiliacionesRequest cadListarAfiliacionesRequest);

	public String obtenerCorrelativoArchivoBolsaMantenimiento(String identificador, String tipoBolsa);

	public CadCargaMasivaResponse PrecargaMasiva(Long codigoComercio, String tipoMantenimineto,
			String nombreArchivo, String identificador);


}
