package pe.dinersclub.wscomercios.dto.cad;

import java.math.BigDecimal;

public class CadMasivaRegistroRespuesta {

	private String numeroTarjeta;
	private String vencimientoTarjeta;
	private String codigoServicio;
	private String nombreUsuarioServicio;
	// private String tipoDocumentoIdentidadUsuarioServicio;
	private String numeroDocumentoIdentidadUsuarioServicio;
	private String telefono;
	private String email;
	private String tipoMantenimiento;
	private String fechaEnvio;
	private BigDecimal montoTope;

	private String codigoError;
	private String descripcionError;

	public String getNumeroTarjeta() {
		return numeroTarjeta;
	}

	public void setNumeroTarjeta(String numeroTarjeta) {
		this.numeroTarjeta = numeroTarjeta;
	}

	public String getVencimientoTarjeta() {
		return vencimientoTarjeta;
	}

	public void setVencimientoTarjeta(String vencimientoTarjeta) {
		this.vencimientoTarjeta = vencimientoTarjeta;
	}

	public String getCodigoServicio() {
		return codigoServicio;
	}

	public void setCodigoServicio(String codigoServicio) {
		this.codigoServicio = codigoServicio;
	}

	public String getNombreUsuarioServicio() {
		return nombreUsuarioServicio;
	}

	public void setNombreUsuarioServicio(String nombreUsuarioServicio) {
		this.nombreUsuarioServicio = nombreUsuarioServicio;
	}

	public String getNumeroDocumentoIdentidadUsuarioServicio() {
		return numeroDocumentoIdentidadUsuarioServicio;
	}

	public void setNumeroDocumentoIdentidadUsuarioServicio(String numeroDocumentoIdentidadUsuarioServicio) {
		this.numeroDocumentoIdentidadUsuarioServicio = numeroDocumentoIdentidadUsuarioServicio;
	}

	public String getTelefono() {
		return telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getTipoMantenimiento() {
		return tipoMantenimiento;
	}

	public void setTipoMantenimiento(String tipoMantenimiento) {
		this.tipoMantenimiento = tipoMantenimiento;
	}

	public String getCodigoError() {
		return codigoError;
	}

	public void setCodigoError(String codigoError) {
		this.codigoError = codigoError;
	}

	public String getDescripcionError() {
		return descripcionError;
	}

	public void setDescripcionError(String descripcionError) {
		this.descripcionError = descripcionError;
	}

	public String getFechaEnvio() {
		return fechaEnvio;
	}

	public void setFechaEnvio(String fechaEnvio) {
		this.fechaEnvio = fechaEnvio;
	}

	public BigDecimal getMontoTope() {
		return montoTope;
	}

	public void setMontoTope(BigDecimal montoTope) {
		this.montoTope = montoTope;
	}

}
