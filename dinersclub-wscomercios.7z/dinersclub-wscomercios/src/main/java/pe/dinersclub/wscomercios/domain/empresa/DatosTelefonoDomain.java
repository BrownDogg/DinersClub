package pe.dinersclub.wscomercios.domain.empresa;

public class DatosTelefonoDomain {

	private String tipoTelefono;
	private String nroTelefono;
	
	public DatosTelefonoDomain() {
		super();
	}
	public DatosTelefonoDomain(String tipoTelefono, String nroTelefono) {
		super();
		this.tipoTelefono = tipoTelefono;
		this.nroTelefono = nroTelefono;
	}
	public String getTipoTelefono() {
		return tipoTelefono;
	}
	public void setTipoTelefono(String tipoTelefono) {
		this.tipoTelefono = tipoTelefono;
	}
	public String getNroTelefono() {
		return nroTelefono;
	}
	public void setNroTelefono(String nroTelefono) {
		this.nroTelefono = nroTelefono;
	}
	
}
