package pe.dinersclub.wscomercios.mensajeria;

public class BeanCorreo {

	private String asunto;
	private String correo;
	private String formato;
	private boolean enviarMensaje;
	private boolean enviarArchivo;

	public String getAsunto() {
		return asunto;
	}

	public void setAsunto(String asunto) {
		this.asunto = asunto;
	}

	public String getCorreo() {
		return correo;
	}

	public void setCorreo(String correo) {
		this.correo = correo;
	}

	public String getFormato() {
		return formato;
	}

	public void setFormato(String formato) {
		this.formato = formato;
	}

	public boolean isEnviarMensaje() {
		return enviarMensaje;
	}

	public void setEnviarMensaje(boolean enviarMensaje) {
		this.enviarMensaje = enviarMensaje;
	}

	public boolean isEnviarArchivo() {
		return enviarArchivo;
	}

	public void setEnviarArchivo(boolean enviarArchivo) {
		this.enviarArchivo = enviarArchivo;
	}

}
