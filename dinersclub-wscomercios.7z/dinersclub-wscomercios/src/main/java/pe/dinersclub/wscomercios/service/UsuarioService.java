package pe.dinersclub.wscomercios.service;

import java.util.List;

import pe.dinersclub.wscomercios.domain.usuario.UsuarioDatosResponse;
import pe.dinersclub.wscomercios.domain.usuario.UsuarioOpcionResponse;

public interface UsuarioService {

	public List<UsuarioOpcionResponse> obtenerOpcionesDeUsuario(String identificador, String idUsuario);
	
	public UsuarioDatosResponse obtenerDatosIniciales(String identificador, String idUsuario);
	
}
