package pe.dinersclub.wscomercios.dto.usuario;

public class UsuarioRecPassEmail {

	private String nombreCompleto;
	private String urlRecuperaPassword;
	private String email;

	public String getNombreCompleto() {
		return nombreCompleto;
	}

	public void setNombreCompleto(String nombreCompleto) {
		this.nombreCompleto = nombreCompleto;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getUrlRecuperaPassword() {
		return urlRecuperaPassword;
	}

	public void setUrlRecuperaPassword(String urlRecuperaPassword) {
		this.urlRecuperaPassword = urlRecuperaPassword;
	}

}
