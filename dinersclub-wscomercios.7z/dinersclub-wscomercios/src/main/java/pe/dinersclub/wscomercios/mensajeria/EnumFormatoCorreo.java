package pe.dinersclub.wscomercios.mensajeria;

public enum EnumFormatoCorreo {

	FormatoComercios("comercios"), FormatoDiners("diners");

	private String formatoCorreo;

	EnumFormatoCorreo(final String formatoCorreo) {
		this.formatoCorreo = formatoCorreo;
	}

	public String getFormatoCorreo() {
		return formatoCorreo;
	}
}
