package pe.dinersclub.wscomercios.dao;

import java.util.Map;

public interface UbigeoDAO {

	public Map<String,String> listarDepartamentos();
	public Map<String,String> listarProvincias(String idDepartamento);
	public Map<String,String> listarDistritos(String idDepartamento, String idProvincia);
	
}
