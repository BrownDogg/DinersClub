package pe.dinersclub.wscomercios.controller;

import java.util.LinkedHashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.annotations.Api;
import pe.dinersclub.wscomercios.domain.BodyResponse;
import pe.dinersclub.wscomercios.exception.ModeloNotFountException;
import pe.dinersclub.wscomercios.log.BeanLog;
import pe.dinersclub.wscomercios.service.UbigeoService;
import pe.dinersclub.wscomercios.util.Globales;
import pe.dinersclub.wscomercios.util.UtilString;

@RestController
@Api(tags = {"Módulo Ubigeo"})
@RequestMapping("/ubigeo")
public class UbigeoController {

	@Autowired
	UbigeoService ubigeoService;
	
	@GetMapping(value = "/listarDepartamento", produces = "application/json")
	public ResponseEntity<Object> listarDepartamento(){
		
		BeanLog beanLog = new BeanLog();
		beanLog.setIdentificador(UtilString.obtenerIdentificadorUnico());
		beanLog.setMetodo(new Object(){}.getClass().getEnclosingMethod().getName());
		beanLog.setEsPadre(true);
		beanLog.setNombreOperacion("Listar Departamento");
		
		LinkedHashMap<String,String> datosFiltro = ubigeoService.listarDepartamentos();
		
		if (!datosFiltro.isEmpty()) {
			beanLog.setDescripcionMensaje(Globales.SOLICITUD_PROCESADA_CORRECTAMENTE);
			return new ResponseEntity<>(
					new BodyResponse<LinkedHashMap<String,String>>(datosFiltro, Globales.RESPUESTA_EXITO), HttpStatus.OK);
		} else {
			beanLog.setDescripcionMensaje(Globales.CONSULTA_SIN_RESULTADO);
			throw new ModeloNotFountException(Globales.SOLICITUD_SIN_RESULTADOS, beanLog.getIdentificador());
		}
	}
	
	
	@GetMapping(value = "/listarProvincias", produces = "application/json")
	public ResponseEntity<Object> listarProvincias(String idDepartamento){
		
		BeanLog beanLog = new BeanLog();
		beanLog.setIdentificador(UtilString.obtenerIdentificadorUnico());
		beanLog.setMetodo(new Object(){}.getClass().getEnclosingMethod().getName());
		beanLog.setEsPadre(true);
		beanLog.setNombreOperacion("Listar Provincias");
		
		LinkedHashMap<String,String> datosFiltro = ubigeoService.listarProvincias(idDepartamento);
		
		if (!datosFiltro.isEmpty()) {
			beanLog.setDescripcionMensaje(Globales.SOLICITUD_PROCESADA_CORRECTAMENTE);
			return new ResponseEntity<>(
					new BodyResponse<LinkedHashMap<String,String>>(datosFiltro, Globales.RESPUESTA_EXITO), HttpStatus.OK);
		} else {
			beanLog.setDescripcionMensaje(Globales.CONSULTA_SIN_RESULTADO);
			throw new ModeloNotFountException(Globales.SOLICITUD_SIN_RESULTADOS, beanLog.getIdentificador());
		}
	}
	
	
	@GetMapping(value = "/listarDistritos", produces = "application/json")
	public ResponseEntity<Object> listarDistritos(String idDepartamento, String idProvincia){
		
		BeanLog beanLog = new BeanLog();
		beanLog.setIdentificador(UtilString.obtenerIdentificadorUnico());
		beanLog.setMetodo(new Object(){}.getClass().getEnclosingMethod().getName());
		beanLog.setEsPadre(true);
		beanLog.setNombreOperacion("Listar Distritos");
		
		LinkedHashMap<String,String> datosFiltro = ubigeoService.listarDistritos(idDepartamento, idProvincia);
		
		if (!datosFiltro.isEmpty()) {
			beanLog.setDescripcionMensaje(Globales.SOLICITUD_PROCESADA_CORRECTAMENTE);
			return new ResponseEntity<>(
					new BodyResponse<LinkedHashMap<String,String>>(datosFiltro, Globales.RESPUESTA_EXITO), HttpStatus.OK);
		} else {
			beanLog.setDescripcionMensaje(Globales.CONSULTA_SIN_RESULTADO);
			throw new ModeloNotFountException(Globales.SOLICITUD_SIN_RESULTADOS, beanLog.getIdentificador());
		}
	}
	
}
