package pe.dinersclub.wscomercios.service.impl;

import java.util.LinkedList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pe.dinersclub.wscomercios.dao.LiquidacionesDAO;
import pe.dinersclub.wscomercios.domain.liquidaciones.LiquidacionDetalleResponse;
import pe.dinersclub.wscomercios.domain.liquidaciones.LiquidacionesRequest;
import pe.dinersclub.wscomercios.domain.liquidaciones.LiquidacionesResponse;
import pe.dinersclub.wscomercios.dto.liquidaciones.DatosLiquidacion;
import pe.dinersclub.wscomercios.dto.liquidaciones.LiquidacionDTO;
import pe.dinersclub.wscomercios.dto.liquidaciones.LiquidacionDetalleDTO;
import pe.dinersclub.wscomercios.log.BeanLog;
import pe.dinersclub.wscomercios.service.LiquidacionesService;
import pe.dinersclub.wscomercios.util.UtilAuditoria;
import pe.dinersclub.wscomercios.util.UtilDate;

@Service
public class LiquidacionesServiceImpl implements LiquidacionesService {

	@Autowired
	LiquidacionesDAO liquidacionesDAO;
	@Autowired
	private UtilAuditoria utilAudit;

	@Override
	public List<DatosLiquidacion> listarLiquidaciones(String idTransaccion, LiquidacionesRequest request) {

		BeanLog beanLog = new BeanLog();
		long fechaInicio = UtilDate.getCurrentDateTime();
		String metodo = new Object(){}.getClass().getEnclosingMethod().getName();
		beanLog = utilAudit.initLog(idTransaccion, null, metodo, true, "Actualizar datos del Comercio");
		
		List<LiquidacionesResponse> listaResponse = null;
		LiquidacionesResponse response = null;
		List<DatosLiquidacion> listaLiquidacion = null;
		LiquidacionDTO liquidacion = null;

		try {
			liquidacion = new LiquidacionDTO(request.getIdEmpresa(), request.getCodComercio(),
					request.getIdMoneda(), request.getIdFormaPago(), request.getIdEstadoPago(),
					request.getFechaInicio(), request.getFechaFin(), request.getDocumentoAutorizado(),
					request.getPage(), request.getXpage());

			listaLiquidacion = liquidacionesDAO.listarLiquidaciones(idTransaccion, liquidacion);
			if (listaLiquidacion.isEmpty()) {

				listaResponse = new LinkedList<LiquidacionesResponse>();

				for (DatosLiquidacion aux : listaLiquidacion) {
					response = new LiquidacionesResponse(aux.getIdLiquidacion(), aux.getCodigoComercio(),
							aux.getNombreComercio(), aux.getFechaPago(), aux.getMonedaPago(), aux.getImporteConsumo(),
							aux.getImporteComision(), aux.getIgv(), aux.getCargo(), aux.getImporteNetoLiquidacion(),
							aux.getDocumentoAautorizado(), aux.getFormaPago(), aux.getBanco(), aux.getTipoCuenta(),
							aux.getNroCtaBancaria(), aux.getNroCheque());
					listaResponse.add(response);
				}
			} 
		} catch (Exception e) {
			utilAudit.errorExceptionLog(beanLog, e.getMessage(), e.getCause().getMessage());
		}finally {
			utilAudit.endLog(beanLog, fechaInicio);
		}
		
		return listaLiquidacion;
	}

	@Override
	public List<LiquidacionDetalleResponse> listarLiquidacionesDetalle(String idTransaccion, String codPago) {
		
		BeanLog beanLog = new BeanLog();
		long fechaInicio = UtilDate.getCurrentDateTime();
		String metodo = new Object(){}.getClass().getEnclosingMethod().getName();
		beanLog = utilAudit.initLog(idTransaccion, null, metodo, true, "Actualizar datos del Comercio");

		LiquidacionDetalleResponse response = null;
		List<LiquidacionDetalleResponse> listaLiqDetalle = null;

		try {
			List<LiquidacionDetalleDTO> listaDetalle = liquidacionesDAO.listarLiquidacionesDetalle(idTransaccion,
					codPago);

			if (!listaDetalle.isEmpty()) {
				listaLiqDetalle = new LinkedList<>();

				for (LiquidacionDetalleDTO aux : listaDetalle) {
					response = new LiquidacionDetalleResponse();
					response.setCodAntiguo(aux.getCodAntiguo());
					response.setFecRecep(aux.getFecRecep());
					response.setCodComercio(aux.getCodComercio());
					response.setCodRecap(aux.getCodRecap());
					response.setNroTicket(aux.getNroTicket());
					response.setTarjetaSocio(aux.getTarjetaSocio());
					response.setFecTicket(aux.getFecTicket());
					response.setImpTicket(aux.getImpTicket());
					response.setImpComTicket(aux.getImpComTicket());
					response.setMoneda(aux.getMoneda());
					response.setNroAut(aux.getNroAut());
					response.setCorrelativo(aux.getCorrelativo());
					response.setEstado(aux.getEstado());
					response.setImpIgvTicket(aux.getImpIgvTicket());
					response.setImpComiTicket(aux.getImpComiTicket());
					response.setImpNoComiTicket(aux.getImpNoComiTicket());
					response.setDocAut(aux.getDocAut());
					response.setCuenta(aux.getCuenta());
					response.setFecPagoEfect(aux.getFecPagoEfect());
					response.setFormaPago(aux.getFormaPago());
					response.setBanco(aux.getBanco());
					response.setImpAjuste(aux.getImpAjuste());
					response.setNroComprobante(aux.getNroComprobante());
					listaLiqDetalle.add(response);
				}
			} 
		} catch (Exception e) {
			utilAudit.errorExceptionLog(beanLog, e.getMessage(), e.getCause().getMessage());
		}finally {
			utilAudit.endLog(beanLog, fechaInicio);
		}
		return listaLiqDetalle;
	}

}
