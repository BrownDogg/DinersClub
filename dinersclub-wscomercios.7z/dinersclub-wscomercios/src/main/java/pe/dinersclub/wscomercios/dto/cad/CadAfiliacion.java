package pe.dinersclub.wscomercios.dto.cad;

import java.math.BigDecimal;

public class CadAfiliacion {

	private String codigoServicio;
	private Long numeroTarjeta;
	private String anioVencimientoTarjeta;
	private String mesVencimientoTarjeta;
	private String fechaAfiliacion;
	private BigDecimal montoTope;
	private String UsuarioServicio;
	private String tipoDocumentoIdentidad;
	private String numeroDocumentoIdentidad;
	private String estadoServicio;
	private String estadoTarjeta;

	public String getCodigoServicio() {
		return codigoServicio;
	}

	public void setCodigoServicio(String codigoServicio) {
		this.codigoServicio = codigoServicio;
	}

	public Long getNumeroTarjeta() {
		return numeroTarjeta;
	}

	public void setNumeroTarjeta(Long numeroTarjeta) {
		this.numeroTarjeta = numeroTarjeta;
	}

	public String getAnioVencimientoTarjeta() {
		return anioVencimientoTarjeta;
	}

	public void setAnioVencimientoTarjeta(String anioVencimientoTarjeta) {
		this.anioVencimientoTarjeta = anioVencimientoTarjeta;
	}

	public String getMesVencimientoTarjeta() {
		return mesVencimientoTarjeta;
	}

	public void setMesVencimientoTarjeta(String mesVencimientoTarjeta) {
		this.mesVencimientoTarjeta = mesVencimientoTarjeta;
	}

	public String getFechaAfiliacion() {
		return fechaAfiliacion;
	}

	public void setFechaAfiliacion(String fechaAfiliacion) {
		this.fechaAfiliacion = fechaAfiliacion;
	}

	public BigDecimal getMontoTope() {
		return montoTope;
	}

	public void setMontoTope(BigDecimal montoTope) {
		this.montoTope = montoTope;
	}

	public String getUsuarioServicio() {
		return UsuarioServicio;
	}

	public void setUsuarioServicio(String usuarioServicio) {
		UsuarioServicio = usuarioServicio;
	}

	public String getTipoDocumentoIdentidad() {
		return tipoDocumentoIdentidad;
	}

	public void setTipoDocumentoIdentidad(String tipoDocumentoIdentidad) {
		this.tipoDocumentoIdentidad = tipoDocumentoIdentidad;
	}

	public String getNumeroDocumentoIdentidad() {
		return numeroDocumentoIdentidad;
	}

	public void setNumeroDocumentoIdentidad(String numeroDocumentoIdentidad) {
		this.numeroDocumentoIdentidad = numeroDocumentoIdentidad;
	}

	public String getEstadoServicio() {
		return estadoServicio;
	}

	public void setEstadoServicio(String estadoServicio) {
		this.estadoServicio = estadoServicio;
	}

	public String getEstadoTarjeta() {
		return estadoTarjeta;
	}

	public void setEstadoTarjeta(String estadoTarjeta) {
		this.estadoTarjeta = estadoTarjeta;
	}

}
