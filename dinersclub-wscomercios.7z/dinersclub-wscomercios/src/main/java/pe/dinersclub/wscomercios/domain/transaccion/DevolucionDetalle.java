package pe.dinersclub.wscomercios.domain.transaccion;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

public class DevolucionDetalle {

	private String codigoComercio;
	private String numeroTarjeta;
	private String fechaConsumo;
	private String codigoAutorizacion;
	private String nroTicket;
	private String idMoneda;
	private String importeConsumo;
	private String importeDevolucion;
	private String tipoDevolucion;
	private String referencia;
	private String observaciones;
	@JsonInclude(Include.NON_NULL)
	private String codigoDevolucion;
	@JsonInclude(Include.NON_NULL)
	private String codigoRespuesta;

	public String getCodigoComercio() {
		return codigoComercio;
	}

	public void setCodigoComercio(String codigoComercio) {
		this.codigoComercio = codigoComercio;
	}

	public String getNumeroTarjeta() {
		return numeroTarjeta;
	}

	public void setNumeroTarjeta(String numeroTarjeta) {
		this.numeroTarjeta = numeroTarjeta;
	}

	public String getFechaConsumo() {
		return fechaConsumo;
	}

	public void setFechaConsumo(String fechaConsumo) {
		this.fechaConsumo = fechaConsumo;
	}

	public String getCodigoAutorizacion() {
		return codigoAutorizacion;
	}

	public void setCodigoAutorizacion(String codigoAutorizacion) {
		this.codigoAutorizacion = codigoAutorizacion;
	}

	public String getNroTicket() {
		return nroTicket;
	}

	public void setNroTicket(String nroTicket) {
		this.nroTicket = nroTicket;
	}

	public String getIdMoneda() {
		return idMoneda;
	}

	public void setIdMoneda(String idMoneda) {
		this.idMoneda = idMoneda;
	}

	public String getImporteConsumo() {
		return importeConsumo;
	}

	public void setImporteConsumo(String importeConsumo) {
		this.importeConsumo = importeConsumo;
	}

	public String getImporteDevolucion() {
		return importeDevolucion;
	}

	public void setImporteDevolucion(String importeDevolucion) {
		this.importeDevolucion = importeDevolucion;
	}

	public String getTipoDevolucion() {
		return tipoDevolucion;
	}

	public void setTipoDevolucion(String tipoDevolucion) {
		this.tipoDevolucion = tipoDevolucion;
	}

	public String getReferencia() {
		return (referencia == null) ? "" : referencia;
	}

	public void setReferencia(String referencia) {
		this.referencia = referencia;
	}

	public String getObservaciones() {
		return (observaciones == null) ? "" : observaciones;
	}

	public void setObservaciones(String observaciones) {
		this.observaciones = observaciones;
	}

	public String getCodigoDevolucion() {
		return codigoDevolucion;
	}

	public void setCodigoDevolucion(String codigoDevolucion) {
		this.codigoDevolucion = codigoDevolucion;
	}

	public String getCodigoRespuesta() {
		return codigoRespuesta;
	}

	public void setCodigoRespuesta(String codigoRespuesta) {
		this.codigoRespuesta = codigoRespuesta;
	}

	@Override
	public String toString() {
		return "DevolucionDomain [codigoComercio=" + codigoComercio + ", numeroTarjeta=" + numeroTarjeta
				+ ", fechaConsumo=" + fechaConsumo + ", codigoAutorizacion=" + codigoAutorizacion + ", nroTicket="
				+ nroTicket + ", idMoneda=" + idMoneda + ", importeConsumo=" + importeConsumo + ", importeDevolucion="
				+ importeDevolucion + ", tipoDevolucion=" + tipoDevolucion + ", referencia=" + referencia
				+ ", observaciones=" + observaciones + ", codigoDevolucion=" + codigoDevolucion + ", codigoRespuesta="
				+ codigoRespuesta + "]";
	}

	public boolean validarDataVacia(DevolucionDetalle devolucion) {
		if (devolucion.getCodigoComercio() == null)
			return false;
		if (devolucion.getNumeroTarjeta() == null)
			return false;
		if (devolucion.getFechaConsumo() == null)
			return false;
		if (devolucion.getCodigoAutorizacion() == null)
			return false;
		if (devolucion.getNroTicket() == null)
			return false;
		if (devolucion.getIdMoneda() == null)
			return false;
		if (devolucion.getImporteConsumo() == null)
			return false;
		if (devolucion.getImporteDevolucion() == null)
			return false;
		if (devolucion.getTipoDevolucion() == null)
			return false;
		return true;
	}
	
}
