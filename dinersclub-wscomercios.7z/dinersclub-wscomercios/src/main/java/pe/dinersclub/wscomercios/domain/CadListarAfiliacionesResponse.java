package pe.dinersclub.wscomercios.domain;

import java.util.List;

import pe.dinersclub.wscomercios.dto.cad.CadAfiliacion;

public class CadListarAfiliacionesResponse {

	private Long cantidad;
	private List<CadAfiliacion> afiliaciones;

	public Long getCantidad() {
		return cantidad;
	}

	public void setCantidad(Long cantidad) {
		this.cantidad = cantidad;
	}

	public List<CadAfiliacion> getAfiliaciones() {
		return afiliaciones;
	}

	public void setAfiliaciones(List<CadAfiliacion> afiliaciones) {
		this.afiliaciones = afiliaciones;
	}

}
