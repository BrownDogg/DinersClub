package pe.dinersclub.wscomercios.dao.impl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import pe.dinersclub.wscomercios.dao.TablaDAO;
import pe.dinersclub.wscomercios.dto.filtros.Tabla;
import pe.dinersclub.wscomercios.log.BeanLog;
import pe.dinersclub.wscomercios.log.UtilLog;
import pe.dinersclub.wscomercios.log.UtilLogLevel;
import pe.dinersclub.wscomercios.util.ConnectionDB;
import pe.dinersclub.wscomercios.util.Globales;

@Repository
public class TablaDAOImpl implements TablaDAO{

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private UtilLog utilLog;
	
	@Override
	public List<Tabla> obtenerFiltro(String identificador, String codigoTabla) {
		
		BeanLog beanLog = new BeanLog();
		beanLog.setIdentificador(identificador);
		beanLog.setMetodo(new Object(){}.getClass().getEnclosingMethod().getName());
		List<Tabla> tablas = new ArrayList<>();
		Tabla tabla = null;
		Connection conn = null;
		CallableStatement cs = null;
		ResultSet rs = null;
		StringBuilder sbSQL = new StringBuilder();

		try {
			sbSQL.append(Globales.CALL_SP).append(Globales.ESQUEMA_PROC);
			sbSQL.append(".").append(Globales.SP_WSC_OBTENERFILTRO).append("(?,?)}");
			conn = ConnectionDB.getConnectionServerAS400();
			cs = conn.prepareCall(sbSQL.toString());
			cs.setString(1, codigoTabla);
			cs.setNull(2, 1);
			cs.execute();

			rs = cs.getResultSet();

			while (rs.next()) {
				tabla = new Tabla();
				tabla.setCodigoTabla(rs.getString(1).trim());
				tabla.setIdItemTabla(rs.getString(2).trim());
				tabla.setDescripcion(rs.getString(3).trim());
				tabla.setIdItemDCP(rs.getString(4).trim());
				tablas.add(tabla);
				tabla = null;
			}

		} catch (Exception ex) {
			beanLog.setDescripcionMensaje(ex.getMessage());
			beanLog.setCausa(ex.getCause() != null ? ex.getCause().getMessage() : "");
			beanLog.setTipoMensaje(UtilLogLevel.ERROR.name());
			utilLog.printInfo(logger, beanLog);

		} finally {
			try {
				if (rs != null)
					rs.close();
				if (cs != null)
					cs.close();
				if (conn != null)
					conn.close();
			} catch (SQLException ex) {
			}
		}

		return tablas;
	}

	@Override
	public Tabla obtenerDatoPorCodigoAndItem(String identificador, String codigoTabla, String idItem) {
		
		BeanLog beanLog = new BeanLog();
		beanLog.setIdentificador(identificador);
		beanLog.setMetodo(new Object(){}.getClass().getEnclosingMethod().getName());
		Tabla tabla = null;
		Connection conn = null;
		CallableStatement cs = null;
		ResultSet rs = null;
		StringBuilder sbSQL = new StringBuilder();
		
		try {
			sbSQL.append(Globales.CALL_SP).append(Globales.ESQUEMA_PROC);
			sbSQL.append(".").append(Globales.SP_WSC_OBTENERFILTRO).append("(?,?)}");
			conn = ConnectionDB.getConnectionServerAS400();
			cs = conn.prepareCall(sbSQL.toString());
			cs.setString(1, codigoTabla);
			cs.setString(2, idItem);
			cs.execute();
			rs = cs.getResultSet();

			while (rs.next()) {
				tabla = new Tabla();
				tabla.setCodigoTabla(rs.getString(1).trim());
				tabla.setIdItemTabla(rs.getString(2).trim());
				tabla.setDescripcion(rs.getString(3).trim());
				tabla.setIdItemDCP(rs.getString(4).trim());
			}

		} catch (Exception ex) {
			beanLog.setDescripcionMensaje(ex.getMessage());
			beanLog.setCausa(ex.getCause() != null ? ex.getCause().getMessage() : "");
			beanLog.setTipoMensaje(UtilLogLevel.ERROR.name());
			utilLog.printInfo(logger, beanLog);

		} finally {
			try {
				if (rs != null)
					rs.close();
				if (cs != null)
					cs.close();
				if (conn != null)
					conn.close();
			} catch (SQLException ex) {
			}
		}
		
		return tabla;
	}

	@Override
	public Tabla obtenerDatoPorCodigoAndItemDCP(String identificador, 	String codigoTabla, String idItemDCP) {
		
		BeanLog beanLog = new BeanLog();
		beanLog.setIdentificador(identificador);
		beanLog.setMetodo(new Object(){}.getClass().getEnclosingMethod().getName());
		Tabla tabla = null;
		Connection conn = null;
		CallableStatement cs = null;
		ResultSet rs = null;
		StringBuilder sbSQL = new StringBuilder();
		
		try {
			sbSQL.append(Globales.CALL_SP).append(Globales.ESQUEMA_PROC);
			sbSQL.append(".").append(Globales.SP_WSC_OBTENERFILTROPORIDDCP).append("(?,?)}");
			conn = ConnectionDB.getConnectionServerAS400();
			cs = conn.prepareCall(sbSQL.toString());
			cs.setString(1, codigoTabla);
			cs.setString(2, idItemDCP);
			cs.execute();
			rs = cs.getResultSet();

			while (rs.next()) {
				tabla = new Tabla();
				tabla.setCodigoTabla(rs.getString(1).trim());
				tabla.setIdItemTabla(rs.getString(2).trim());
				tabla.setDescripcion(rs.getString(3).trim());
				tabla.setIdItemDCP(rs.getString(4).trim());
			}

		} catch (Exception ex) {
			beanLog.setDescripcionMensaje(ex.getMessage());
			beanLog.setCausa(ex.getCause() != null ? ex.getCause().getMessage() : "");
			beanLog.setTipoMensaje(UtilLogLevel.ERROR.name());
			utilLog.printInfo(logger, beanLog);

		} finally {
			try {
				if (rs != null)
					rs.close();
				if (cs != null)
					cs.close();
				if (conn != null)
					conn.close();
			} catch (SQLException ex) {
			}
		}
		
		return tabla;
	}
	
}
