package pe.dinersclub.wscomercios.redis.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;

import pe.dinersclub.wscomercios.dao.TokenDAO;
import pe.dinersclub.wscomercios.dto.usuario.TokenDTO;
import pe.dinersclub.wscomercios.util.UtilObjectMapper;

/*
 * SE AGREGA EL SCOPE PARA SOLUCIONAR EL PROBLEMA DE CONSULTA DE OTRO METODO DEL MISMO BEAN
 * PORQUE SINO, NO SE GUARDA EN CACHE
 */
@Service
@Scope(proxyMode = ScopedProxyMode.TARGET_CLASS)
public class TokenCacheService {

	private Logger logger = LoggerFactory.getLogger(this.getClass());
	public final String cacheNames = "Token";

	@Autowired
	private TokenDAO tokenDAO;

	public TokenDTO addLocal(String identificador, TokenDTO tokenDTO) {
		tokenDAO.add(identificador, tokenDTO);
		return tokenDTO;
	}

	public TokenDTO findByIdLocal(String identificador, String id) {
		return tokenDAO.findById(identificador, id);
	}

	@CachePut(cacheNames = cacheNames, key = "(#root.target.cacheNames).concat('_').concat(#tokenDTO.idUsuario)", unless = "#result == null")
	public String addRedis(String identificador, TokenDTO tokenDTO) {
		String json = null;
		try {
			json = UtilObjectMapper.getObjectMapper().writeValueAsString(addLocal(identificador, tokenDTO));
		} catch (JsonProcessingException ex) {
			ex.printStackTrace();
		} finally {
			if (json != null)
				logger.info("Se agrego al cache a {} con id: {}", cacheNames, tokenDTO.getIdUsuario());
		}
		return json;
	}

	@Cacheable(cacheNames = cacheNames, key = "(#root.target.cacheNames).concat('_').concat(#id)", unless = "#result == null")
	public String findByIdRedis(String identificador, String id) {
		String json = null;
		try {
			TokenDTO tokenDTO = findByIdLocal(identificador, id);
			if (tokenDTO != null) {
				json = UtilObjectMapper.getObjectMapper().writeValueAsString(tokenDTO);
			} else {
				throw new InternalError();
			}
		} catch (JsonProcessingException ex) {
			ex.printStackTrace();
		} finally {
			if (json != null)
				logger.info("Se agrego al cache a {} con id: {}", cacheNames, id);
		}
		return json;
	}

	@CacheEvict(cacheNames = cacheNames, key = "(#root.target.cacheNames).concat('_').concat(#id)")
	public void deleteRedis(String identificador, String id) {
		logger.info("Se quito del cache a {} con id: {}", cacheNames, id);
	}

	@CacheEvict(cacheNames = cacheNames, allEntries = true)
	public void deleteAllRedis(String identificador) {
		logger.info("Se elimino del cache a todo {}", cacheNames);
	}
}