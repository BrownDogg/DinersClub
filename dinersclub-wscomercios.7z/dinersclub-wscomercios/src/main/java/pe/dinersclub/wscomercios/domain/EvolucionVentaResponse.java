package pe.dinersclub.wscomercios.domain;

import java.math.BigDecimal;
import java.util.List;

public class EvolucionVentaResponse {

	private BigDecimal totalVentas;
	private Integer cantidadRegistros;
	private List<VentaXRango> listaVentaRango;
	
	public BigDecimal getTotalVentas() {
		return totalVentas;
	}
	public void setTotalVentas(BigDecimal totalVentas) {
		this.totalVentas = totalVentas;
	}
	public Integer getCantidadRegistros() {
		return cantidadRegistros;
	}
	public void setCantidadRegistros(Integer cantidadRegistros) {
		this.cantidadRegistros = cantidadRegistros;
	}
	public List<VentaXRango> getListaVentaRango() {
		return listaVentaRango;
	}
	public void setListaVentaRango(List<VentaXRango> listaVentaRango) {
		this.listaVentaRango = listaVentaRango;
	}
	
}
