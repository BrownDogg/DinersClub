package pe.dinersclub.wscomercios.domain;

import java.math.BigDecimal;

public class CadAfiliacionIndividualRequest {

	private Long codigoComercio;
	private String codigoServicio;
	private Long numeroTarjeta;
	private BigDecimal montoTope;
	private String anioVencimientoTarjeta;
	private String mesVencimientoTarjeta;
	private String usuarioServicio;
	private String tipoDocumentoIdentidad;
	private String numeroDocumentoIdentidad;
	private String telefono;
	private String email;

	public Long getCodigoComercio() {
		return codigoComercio;
	}

	public void setCodigoComercio(Long codigoComercio) {
		this.codigoComercio = codigoComercio;
	}

	public String getCodigoServicio() {
		return codigoServicio;
	}

	public void setCodigoServicio(String codigoServicio) {
		this.codigoServicio = codigoServicio;
	}

	public Long getNumeroTarjeta() {
		return numeroTarjeta;
	}

	public void setNumeroTarjeta(Long numeroTarjeta) {
		this.numeroTarjeta = numeroTarjeta;
	}

	public BigDecimal getMontoTope() {
		return montoTope;
	}

	public void setMontoTope(BigDecimal montoTope) {
		this.montoTope = montoTope;
	}

	public String getAnioVencimientoTarjeta() {
		return anioVencimientoTarjeta;
	}

	public void setAnioVencimientoTarjeta(String anioVencimientoTarjeta) {
		this.anioVencimientoTarjeta = anioVencimientoTarjeta;
	}

	public String getMesVencimientoTarjeta() {
		return mesVencimientoTarjeta;
	}

	public void setMesVencimientoTarjeta(String mesVencimientoTarjeta) {
		this.mesVencimientoTarjeta = mesVencimientoTarjeta;
	}

	public String getUsuarioServicio() {
		return usuarioServicio;
	}

	public void setUsuarioServicio(String usuarioServicio) {
		this.usuarioServicio = usuarioServicio;
	}

	public String getTipoDocumentoIdentidad() {
		return tipoDocumentoIdentidad;
	}

	public void setTipoDocumentoIdentidad(String tipoDocumentoIdentidad) {
		this.tipoDocumentoIdentidad = tipoDocumentoIdentidad;
	}

	public String getNumeroDocumentoIdentidad() {
		return numeroDocumentoIdentidad;
	}

	public void setNumeroDocumentoIdentidad(String numeroDocumentoIdentidad) {
		this.numeroDocumentoIdentidad = numeroDocumentoIdentidad;
	}

	public String getTelefono() {
		return telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

}
