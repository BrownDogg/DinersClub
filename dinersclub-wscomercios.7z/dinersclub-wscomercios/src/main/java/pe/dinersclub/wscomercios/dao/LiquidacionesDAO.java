package pe.dinersclub.wscomercios.dao;

import java.util.List;

import pe.dinersclub.wscomercios.dto.liquidaciones.DatosLiquidacion;
import pe.dinersclub.wscomercios.dto.liquidaciones.LiquidacionDTO;
import pe.dinersclub.wscomercios.dto.liquidaciones.LiquidacionDetalleDTO;

public interface LiquidacionesDAO {

	
	public List<DatosLiquidacion> listarLiquidaciones(String idTransaccion, LiquidacionDTO liquidacion);
	public List<LiquidacionDetalleDTO> listarLiquidacionesDetalle(String idTransaccion, String codPago);
	
}
