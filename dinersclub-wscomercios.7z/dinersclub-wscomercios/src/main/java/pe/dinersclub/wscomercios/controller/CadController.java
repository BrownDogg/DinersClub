package pe.dinersclub.wscomercios.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import io.swagger.annotations.Api;
import pe.dinersclub.wscomercios.domain.CadAfiliacionIndividualRequest;
import pe.dinersclub.wscomercios.domain.CadCargaMasivaResponse;
import pe.dinersclub.wscomercios.domain.CadDesafiliacionIndividualRequest;
import pe.dinersclub.wscomercios.domain.CadDesafiliacionIndividualResponse;
import pe.dinersclub.wscomercios.domain.BodyResponse;
import pe.dinersclub.wscomercios.domain.BuscarTarjetaResponse;
import pe.dinersclub.wscomercios.domain.CadDescargaSolicitudesDinersRequest;
import pe.dinersclub.wscomercios.domain.CadListarAfiliacionesRequest;
import pe.dinersclub.wscomercios.domain.CadListarAfiliacionesResponse;
import pe.dinersclub.wscomercios.domain.CadSolicitudesDinersRequest;
import pe.dinersclub.wscomercios.domain.CadSolicitudesDinersResponse;
import pe.dinersclub.wscomercios.exception.ModeloNotFountException;
import pe.dinersclub.wscomercios.log.BeanLog;
import pe.dinersclub.wscomercios.log.UtilLog;
import pe.dinersclub.wscomercios.log.UtilLogLevel;
import pe.dinersclub.wscomercios.service.CadService;
import pe.dinersclub.wscomercios.service.FileStorageService;
import pe.dinersclub.wscomercios.util.Globales;
import pe.dinersclub.wscomercios.util.UtilAuditoria;
import pe.dinersclub.wscomercios.util.UtilDate;
import pe.dinersclub.wscomercios.util.UtilString;

@RestController
@Api(tags = { "Módulo CAD" })
@RequestMapping("/apicad")
public class CadController {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private HttpServletRequest request;
	@Autowired
	private UtilLog utilLog;
	@Autowired
	private UtilAuditoria utilAudit;
	@Autowired
	private CadService cadServiceInterface;
	@Autowired
	private FileStorageService fileStorageService;

	@GetMapping(value = "/listar-solicitudes-diners", produces = "application/json")
	public ResponseEntity<Object> listarSolicitudesDiners(
			@Valid @ModelAttribute CadSolicitudesDinersRequest cadSolicitudesDinersRequest) {

		long fechaInicio = UtilDate.getCurrentDateTime();
		BeanLog beanLog = new BeanLog();
		String idTx = UtilString.obtenerIdentificadorUnico();
		String metodo = new Object(){}.getClass().getEnclosingMethod().getName();
		utilAudit.initLog(idTx, request.getRequestURI(), metodo, true, "Listar Ventas para Homepage");

		/**
		 * Se validan las fechas ingresadas
		 */
		String fechaInicioTope = UtilDate.adicionarMesesFechaActualYYYYMMDD(Globales.CANTIDAD_DE_MESES_RANGO_INICIO);

		// Se valida la fecha de inicio
		if (cadSolicitudesDinersRequest.getFechaInicio() == null) {
			cadSolicitudesDinersRequest.setFechaInicio(fechaInicioTope);
		} else if (UtilDate
				.convertStringToDate(cadSolicitudesDinersRequest.getFechaInicio(), UtilDate.formatDateYYYYMMDD)
				.before(UtilDate.convertStringToDate(fechaInicioTope, UtilDate.formatDateYYYYMMDD))) {
			throw new ModeloNotFountException(Globales.FECHA_INICIO_MENOR_AL_RANGO_PERMITIDO,
					beanLog.getIdentificador());
		}
		// Se valida la fecha de fin
		if (cadSolicitudesDinersRequest.getFechaFin() == null) {
			cadSolicitudesDinersRequest.setFechaFin(UtilDate.fechaHoyYYYYMMDD());
		} else if (UtilDate.convertStringToDate(cadSolicitudesDinersRequest.getFechaFin(), UtilDate.formatDateYYYYMMDD)
				.before(UtilDate.convertStringToDate(cadSolicitudesDinersRequest.getFechaInicio(),
						UtilDate.formatDateYYYYMMDD))) {
			throw new ModeloNotFountException(Globales.FECHA_FIN_MENOR_A_FECHA_INICIO, beanLog.getIdentificador());
		}

		try {

			CadSolicitudesDinersResponse cadSolicitudesDinersResponse = cadServiceInterface
					.listarCadSolicitudesDiners(beanLog.getIdentificador(), cadSolicitudesDinersRequest);

			if (cadSolicitudesDinersResponse != null) {
				beanLog.setIdComercio(cadSolicitudesDinersRequest.getCodigoComercio().toString());
				beanLog.setDescripcionMensaje("Solicitud procesada correctamente.");

				return new ResponseEntity<>(new BodyResponse<CadSolicitudesDinersResponse>(
						cadSolicitudesDinersResponse, Globales.RESPUESTA_EXITO), HttpStatus.OK);
			} else {
				beanLog.setDescripcionMensaje("No se obtuvieron resultados para la solicitud.");

				throw new ModeloNotFountException(Globales.SOLICITUD_SIN_RESULTADOS, beanLog.getIdentificador());
			}

		} finally {

			long fechafinal = UtilDate.getCurrentDateTime();
			beanLog.setDuracion(fechafinal - fechaInicio);
			utilLog.printInfo(logger, beanLog);
		}
	}

	@GetMapping(value = "/descargar-solicitudes-diners", produces = "text/plain")
	public ResponseEntity<Object> descargarSolicitudesDiners(
			@Valid @ModelAttribute CadDescargaSolicitudesDinersRequest cadDescargaSolicitudesDinersRequest) {

		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-Disposition", "attachment; filename=\"CargosExt.txt\"");

		long fechaInicio = UtilDate.getCurrentDateTime();
		BeanLog beanLog = new BeanLog();
		beanLog.setIdentificador(UtilString.obtenerIdentificadorUnico());
		beanLog.setSolicitud(request.getRequestURI());
		beanLog.setMetodo(new Object(){}.getClass().getEnclosingMethod().getName());
		beanLog.setEsPadre(true);
		beanLog.setNombreOperacion("Descargar solicitudes Diners");

		/**
		 * Se validan las fechas ingresadas
		 */
		String fechaInicioTope = UtilDate.adicionarMesesFechaActualYYYYMMDD(Globales.CANTIDAD_DE_MESES_RANGO_INICIO);

		// Se valida la fecha de inicio
		if (cadDescargaSolicitudesDinersRequest.getFechaInicio() == null) {
			cadDescargaSolicitudesDinersRequest.setFechaInicio(fechaInicioTope);
		} else if (UtilDate
				.convertStringToDate(cadDescargaSolicitudesDinersRequest.getFechaInicio(), UtilDate.formatDateYYYYMMDD)
				.before(UtilDate.convertStringToDate(fechaInicioTope, UtilDate.formatDateYYYYMMDD))) {
			throw new ModeloNotFountException(Globales.FECHA_INICIO_MENOR_AL_RANGO_PERMITIDO,
					beanLog.getIdentificador());
		}
		// Se valida la fecha de fin
		if (cadDescargaSolicitudesDinersRequest.getFechaFin() == null) {
			cadDescargaSolicitudesDinersRequest.setFechaFin(UtilDate.fechaHoyYYYYMMDD());
		} else if (UtilDate
				.convertStringToDate(cadDescargaSolicitudesDinersRequest.getFechaFin(), UtilDate.formatDateYYYYMMDD)
				.before(UtilDate.convertStringToDate(cadDescargaSolicitudesDinersRequest.getFechaInicio(),
						UtilDate.formatDateYYYYMMDD))) {
			throw new ModeloNotFountException(Globales.FECHA_FIN_MENOR_A_FECHA_INICIO, beanLog.getIdentificador());
		}

		byte[] byteArrayFile = null;

		try {
			// Se obtiene el contenido del archivo en arreglo de bytes
			byteArrayFile = cadServiceInterface.descargarCadSolicitudesDinersFormatoAfiliacionMasivaTxt(
					beanLog.getIdentificador(), cadDescargaSolicitudesDinersRequest);

			if (byteArrayFile != null) {

				ByteArrayResource resource = new ByteArrayResource(byteArrayFile);

				beanLog.setIdComercio(cadDescargaSolicitudesDinersRequest.getCodigoComercio().toString());
				beanLog.setDescripcionMensaje("Solicitud procesada correctamente");
				return new ResponseEntity<>(resource, headers, HttpStatus.OK);

			} else {
				beanLog.setDescripcionMensaje("No existen resultados en la consulta");
				throw new ModeloNotFountException(Globales.SOLICITUD_SIN_RESULTADOS, beanLog.getIdentificador());
			}

		} catch (Exception e) {
			beanLog.setDescripcionMensaje("Error al procesar la solicitud");
			throw new ModeloNotFountException(Globales.OCURRIO_UN_PROBLEMA_AL_PROCESAR, beanLog.getIdentificador());
		} finally {

			long fechafinal = UtilDate.getCurrentDateTime();
			beanLog.setDuracion(fechafinal - fechaInicio);
			utilLog.printInfo(logger, beanLog);
		}
	}

	@PostMapping(value = "/afiliaciones/individual", produces = "application/json")
	public ResponseEntity<Object> afiliarCadIndividual(
			@RequestBody CadAfiliacionIndividualRequest afiliarCadIndividualRequest) {

		long fechaInicio = UtilDate.getCurrentDateTime();
		BeanLog beanLog = new BeanLog();
		beanLog.setIdentificador(UtilString.obtenerIdentificadorUnico());
		beanLog.setSolicitud(request.getRequestURI());
		beanLog.setMetodo(new Object(){}.getClass().getEnclosingMethod().getName());
		beanLog.setEsPadre(true);
		beanLog.setNombreOperacion("Afiliación al CAD individual");

		try {

			String resultadoAfiliacion = cadServiceInterface.afiliarCadIndividual(beanLog.getIdentificador(),
					afiliarCadIndividualRequest);

			if (resultadoAfiliacion.isEmpty()) {
				beanLog.setDescripcionMensaje("Error al procesar la solicitud");
				throw new ModeloNotFountException(Globales.OCURRIO_UN_PROBLEMA_AL_PROCESAR, beanLog.getIdentificador());
			}

			if (resultadoAfiliacion.substring(0, 5).equals("00000")) {
				beanLog.setIdComercio(afiliarCadIndividualRequest.getCodigoComercio().toString());
				beanLog.setDescripcionMensaje(Globales.SOLICITUD_PROCESADA_CORRECTAMENTE);

				return new ResponseEntity<>(new BodyResponse<String>(null, Globales.RESPUESTA_EXITO),
						HttpStatus.CREATED);
			} else {
				beanLog.setDescripcionMensaje(resultadoAfiliacion);
				throw new ModeloNotFountException(resultadoAfiliacion, beanLog.getIdentificador());
			}

		} finally {

			long fechafinal = UtilDate.getCurrentDateTime();
			beanLog.setDuracion(fechafinal - fechaInicio);
			utilLog.printInfo(logger, beanLog);
		}

	}

	@PostMapping(value = "/desafiliaciones/individual", produces = "application/json")
	public ResponseEntity<List<CadDesafiliacionIndividualResponse>> desafiliarCadIndividual(
			@RequestBody List<CadDesafiliacionIndividualRequest> desafiliarCadsIndividualRequest) {

		long fechaInicio = UtilDate.getCurrentDateTime();
		BeanLog beanLog = new BeanLog();
		beanLog.setIdentificador(UtilString.obtenerIdentificadorUnico());
		beanLog.setSolicitud(request.getRequestURI());
		beanLog.setMetodo(new Object(){}.getClass().getEnclosingMethod().getName());
		beanLog.setEsPadre(true);
		beanLog.setNombreOperacion("Desafiliación al CAD individual");

		List<CadDesafiliacionIndividualResponse> resultados = new ArrayList<>();
		CadDesafiliacionIndividualResponse cadDesafiliacionIndividualResponse = null;

		try {

			for (CadDesafiliacionIndividualRequest desafiliacion : desafiliarCadsIndividualRequest) {

				String resultadoAfiliacion = cadServiceInterface.desafiliarCadIndividual(beanLog.getIdentificador(),
						desafiliacion);
				cadDesafiliacionIndividualResponse = new CadDesafiliacionIndividualResponse();

				cadDesafiliacionIndividualResponse.setCorrelativoSolicitud(desafiliacion.getCorrelativoSolicitud());

				if (resultadoAfiliacion.equals("")) {
					cadDesafiliacionIndividualResponse.setCodigoRespuesta(Globales.OCURRIO_UN_PROBLEMA_AL_PROCESAR);
				} else {
					cadDesafiliacionIndividualResponse.setCodigoRespuesta(resultadoAfiliacion);
				}

				resultados.add(cadDesafiliacionIndividualResponse);
			}

			return new ResponseEntity<>(resultados, HttpStatus.CREATED);

		} finally {

			long fechafinal = UtilDate.getCurrentDateTime();
			beanLog.setDuracion(fechafinal - fechaInicio);
			utilLog.printInfo(logger, beanLog);
		}

	}

	@GetMapping(value = "/buscar-tarjeta/{numeroTarjeta}", produces = "application/json")
	public ResponseEntity<BuscarTarjetaResponse> buscarTarjeta(
			@PathVariable(value = "numeroTarjeta") Long numeroTarjeta) {

		long fechaInicio = UtilDate.getCurrentDateTime();
		BeanLog beanLog = new BeanLog();
		beanLog.setIdentificador(UtilString.obtenerIdentificadorUnico());
		beanLog.setSolicitud(request.getRequestURI());
		beanLog.setMetodo(new Object(){}.getClass().getEnclosingMethod().getName());
		beanLog.setEsPadre(true);
		beanLog.setNombreOperacion("Buscar Tarjeta");

		try {

			BuscarTarjetaResponse tarjetaResponse = cadServiceInterface.buscarTarjeta(beanLog.getIdentificador(),
					numeroTarjeta);
			if (tarjetaResponse != null) {
				beanLog.setDescripcionMensaje(Globales.SOLICITUD_PROCESADA_CORRECTAMENTE);
				return new ResponseEntity<>(tarjetaResponse, HttpStatus.OK);
			} else {
				beanLog.setDescripcionMensaje("Número de Tarjeta no existe");
				throw new ModeloNotFountException(Globales.TARJETA_NO_EXISTE, beanLog.getIdentificador());
			}
		} finally {
			long fechafinal = UtilDate.getCurrentDateTime();
			beanLog.setDuracion(fechafinal - fechaInicio);
			utilLog.printInfo(logger, beanLog);
		}
	}

	@GetMapping(value = "/afiliaciones", produces = "application/json")
	public ResponseEntity<Object> listarAfiliacionesCad(
			@Valid @ModelAttribute CadListarAfiliacionesRequest cadListarAfiliacionesRequest) {

		long fechaInicio = UtilDate.getCurrentDateTime();
		BeanLog beanLog = new BeanLog();
		beanLog.setIdentificador(UtilString.obtenerIdentificadorUnico());
		beanLog.setSolicitud(request.getRequestURI());
		beanLog.setMetodo(new Object(){}.getClass().getEnclosingMethod().getName());
		beanLog.setEsPadre(true);
		beanLog.setNombreOperacion("Listar afiliaciones CAD");

		CadListarAfiliacionesResponse cadListarAfiliacionesResponse = null;

		/**
		 * Se validan las fechas ingresadas
		 */
		String fechaInicioTope = UtilDate.adicionarMesesFechaActualYYYYMMDD(Globales.CANTIDAD_DE_MESES_RANGO_INICIO);

		try {
			// Se valida la fecha de inicio
			if (cadListarAfiliacionesRequest.getFechaInicio() == null) {
				cadListarAfiliacionesRequest.setFechaInicio(fechaInicioTope);
			} else if (UtilDate
					.convertStringToDate(cadListarAfiliacionesRequest.getFechaInicio(), UtilDate.formatDateYYYYMMDD)
					.before(UtilDate.convertStringToDate(fechaInicioTope, UtilDate.formatDateYYYYMMDD))) {
				throw new ModeloNotFountException(Globales.FECHA_INICIO_MENOR_AL_RANGO_PERMITIDO,
						beanLog.getIdentificador());
			}
			// Se valida la fecha de fin
			if (cadListarAfiliacionesRequest.getFechaFin() == null) {
				cadListarAfiliacionesRequest.setFechaFin(UtilDate.fechaHoyYYYYMMDD());
			} else if (UtilDate
					.convertStringToDate(cadListarAfiliacionesRequest.getFechaFin(), UtilDate.formatDateYYYYMMDD)
					.before(UtilDate.convertStringToDate(cadListarAfiliacionesRequest.getFechaInicio(),
							UtilDate.formatDateYYYYMMDD))) {
				throw new ModeloNotFountException(Globales.FECHA_FIN_MENOR_A_FECHA_INICIO, beanLog.getIdentificador());
			}

			cadListarAfiliacionesResponse = cadServiceInterface.listarCadAfiliaciones(beanLog.getIdentificador(),
					cadListarAfiliacionesRequest);

			if (cadListarAfiliacionesResponse == null) {
				beanLog.setCodigoMensaje(Globales.SOLICITUD_SIN_RESULTADOS);
				beanLog.setDescripcionMensaje("No se obtuvieron resultados para la solicitud.");

				throw new ModeloNotFountException(beanLog.getCodigoMensaje(), beanLog.getIdentificador());
			} else {
				beanLog.setIdComercio(cadListarAfiliacionesRequest.getCodigoComercio().toString());
				beanLog.setDescripcionMensaje(Globales.SOLICITUD_PROCESADA_CORRECTAMENTE);

				return new ResponseEntity<>(new BodyResponse<CadListarAfiliacionesResponse>(
						cadListarAfiliacionesResponse, Globales.RESPUESTA_EXITO), HttpStatus.OK);
			}

		} finally {

			long fechafinal = UtilDate.getCurrentDateTime();
			beanLog.setDuracion(fechafinal - fechaInicio);
			utilLog.printInfo(logger, beanLog);
		}
	}

	@PostMapping(value = "/masivas/pre-carga", produces = "application/json")
	public ResponseEntity<Object> afiliacionMasivaPreCarga(@RequestParam("codigoComercio") Long codigoComercio,
			@RequestParam("tipoMantenimiento") String tipoMantenimiento, @RequestParam("file") MultipartFile file) {

		long fechaInicio = UtilDate.getCurrentDateTime();
		BeanLog beanLog = new BeanLog();
		beanLog.setIdentificador(UtilString.obtenerIdentificadorUnico());
		beanLog.setSolicitud(request.getRequestURI());
		beanLog.setMetodo(new Object(){}.getClass().getEnclosingMethod().getName());
		beanLog.setEsPadre(true);
		beanLog.setNombreOperacion("Pre-Carga de Afiliacion Masiva");
		CadCargaMasivaResponse cadCargaMasivaResponse = null;

		try {

			// se valida el tipo de Mantenimiento

			if (!(tipoMantenimiento.equals(Globales.CAD_FLAG_SOLICITUD_AFILIACION)
					|| tipoMantenimiento.equals(Globales.CAD_FLAG_SOLICITUD_DESAFILIACION))) {
				beanLog.setCodigoMensaje(Globales.TIPO_DE_MANTENIMIENTO_INVALIDO);
				beanLog.setTipoMensaje(UtilLogLevel.INFO.name());
				throw new ModeloNotFountException(beanLog.getCodigoMensaje(), beanLog.getIdentificador());
			}

			// Se valida la extensión del archivo

			String extension = "";
			int i = file.getOriginalFilename().lastIndexOf('.');
			if (i >= 0) {
				extension = file.getOriginalFilename().substring(i + 1);
			}

			if (!(extension.equals("xlsx") || extension.equals("txt"))) {
				beanLog.setCodigoMensaje(Globales.ARCHIVO_CON_FORMATO_INCORRECTO);
				beanLog.setTipoMensaje(UtilLogLevel.INFO.name());
				throw new ModeloNotFountException(beanLog.getCodigoMensaje(), beanLog.getIdentificador());
			}

			// Se obtiene el correlativo para el nombre del archivo

			String correlativo = cadServiceInterface.obtenerCorrelativoArchivoBolsaMantenimiento(
					beanLog.getIdentificador(), Globales.CAD_TIPO_BOLSA_MANTENIMIENTO);
			if (correlativo == null) {
				throw new ModeloNotFountException("No se pudo obtener el correlativo para el archivo.",
						beanLog.getIdentificador());
			}

			// se copia el archivo en el servidor con el número de correlativo.
			String fileName = fileStorageService.storeFile(file, correlativo + "." + extension,
					beanLog.getIdentificador());

			// Realizar la precarga del archivo
			cadCargaMasivaResponse = cadServiceInterface.PrecargaMasiva(codigoComercio, tipoMantenimiento, fileName,
					beanLog.getIdentificador());

			if (cadCargaMasivaResponse.getRegistrosFallidos() == 0) {
				return new ResponseEntity<>(
						new BodyResponse<CadCargaMasivaResponse>(cadCargaMasivaResponse, Globales.RESPUESTA_EXITO),
						HttpStatus.ACCEPTED);
			} else {
				return new ResponseEntity<>(new BodyResponse<CadCargaMasivaResponse>(cadCargaMasivaResponse,
						Globales.REGISTROS_DEL_ARCHIVO_CON_ERROR), HttpStatus.OK);
			}

		} finally {

			long fechafinal = UtilDate.getCurrentDateTime();
			beanLog.setDuracion(fechafinal - fechaInicio);
			utilLog.printInfo(logger, beanLog);
		}

	}

}
