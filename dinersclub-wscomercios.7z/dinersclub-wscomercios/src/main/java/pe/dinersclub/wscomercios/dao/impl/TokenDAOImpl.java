package pe.dinersclub.wscomercios.dao.impl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import pe.dinersclub.wscomercios.dao.TokenDAO;
import pe.dinersclub.wscomercios.dto.usuario.TokenDTO;
import pe.dinersclub.wscomercios.log.BeanLog;
import pe.dinersclub.wscomercios.log.UtilLog;
import pe.dinersclub.wscomercios.log.UtilLogLevel;
import pe.dinersclub.wscomercios.util.ConnectionDB;
import pe.dinersclub.wscomercios.util.Globales;
import pe.dinersclub.wscomercios.util.UtilDate;

@Repository
public class TokenDAOImpl implements TokenDAO {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private UtilLog utilLog;

	public void add(String identificador, TokenDTO object) {
		long fechaInicio = UtilDate.getCurrentDateTime();
		BeanLog beanLog = new BeanLog();
		beanLog.setIdentificador(identificador);
		beanLog.setMetodo(new Object(){}.getClass().getEnclosingMethod().getName());

		Connection conn = null;
		CallableStatement cs = null;
		StringBuilder sbSQL = new StringBuilder();
		try {
			sbSQL.append(Globales.CALL_SP).append(Globales.ESQUEMA_PROC);
			sbSQL.append(".").append(Globales.SP_WSC_REGISTRARTOKEN).append("(?,?,?,?)}");

			String[] splitFechaHora = UtilDate
					.convertDateToString(object.getFechaAcceso(), UtilDate.formatDateYYYYMMDD_HHMMSS).split("_");

			conn = ConnectionDB.getConnectionServerAS400();
			cs = conn.prepareCall(sbSQL.toString());
			cs.setString(1, object.getIdUsuario());
			cs.setString(2, object.getTokenAcceso());
			cs.setString(3, splitFechaHora[0]);
			cs.setString(4, splitFechaHora[1]);
			cs.execute();

		} catch (Exception ex) {
			ex.printStackTrace();
			beanLog.setDescripcionMensaje(ex.getMessage());
			beanLog.setCausa(ex.getCause() != null ? ex.getCause().getMessage() : "");
			beanLog.setConsulta(sbSQL.toString());
			beanLog.setTipoMensaje(UtilLogLevel.ERROR.name());
		} finally {
			try {
				if (cs != null)
					cs.close();
				if (conn != null)
					conn.close();
			} catch (Exception ex) {
			}
			long fechaFin = UtilDate.getCurrentDateTime();
			beanLog.setDuracion(fechaFin - fechaInicio);
			utilLog.printInfo(logger, beanLog);
		}
	}

	public TokenDTO findById(String identificador, final String idUsuario) {
		long fechaInicio = UtilDate.getCurrentDateTime();
		BeanLog beanLog = new BeanLog();
		beanLog.setIdentificador(identificador);
		beanLog.setMetodo(new Object(){}.getClass().getEnclosingMethod().getName());
		Connection conn = null;
		CallableStatement cs = null;
		ResultSet rs = null;
		TokenDTO usuarioLogueado = null;
		StringBuilder sbSQL = new StringBuilder();
		try {
			sbSQL.append(Globales.CALL_SP).append(Globales.ESQUEMA_PROC);
			sbSQL.append(".").append(Globales.SP_WSC_CONSULTARTOKENXIDUSUARIO).append("(?)}");

			conn = ConnectionDB.getConnectionServerAS400();
			cs = conn.prepareCall(sbSQL.toString());
			cs.setString(1, idUsuario);
			cs.execute();
			rs = cs.getResultSet();

			if (rs.next()) {
				usuarioLogueado = new TokenDTO();
				usuarioLogueado.setIdUsuario(idUsuario);
				usuarioLogueado.setTokenAcceso(rs.getString(1).trim());
				usuarioLogueado.setFechaAcceso(UtilDate.convertStringToDate(rs.getString(2) + "_" + rs.getString(3),
						UtilDate.formatDateYYYYMMDD_HHMMSS));
			}

		} catch (Exception ex) {
			ex.printStackTrace();
			beanLog.setDescripcionMensaje(ex.getMessage());
			beanLog.setCausa(ex.getCause() != null ? ex.getCause().getMessage() : "");
			beanLog.setConsulta(sbSQL.toString());
			beanLog.setTipoMensaje(UtilLogLevel.ERROR.name());
			utilLog.printInfo(logger, beanLog);
		} finally {
			try {
				if (cs != null)
					cs.close();
				if (conn != null)
					conn.close();
			} catch (Exception ex) {
			}
			long fechaFin = UtilDate.getCurrentDateTime();
			beanLog.setDuracion(fechaFin - fechaInicio);
			utilLog.printInfo(logger, beanLog);
		}
		return usuarioLogueado;
	}
}

