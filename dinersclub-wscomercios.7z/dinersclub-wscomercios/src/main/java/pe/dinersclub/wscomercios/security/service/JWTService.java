package pe.dinersclub.wscomercios.security.service;

import java.io.IOException;
import java.util.Collection;

import org.springframework.security.core.GrantedAuthority;

import io.jsonwebtoken.Claims;
import pe.dinersclub.wscomercios.dto.usuario.TokenDTO;
import pe.dinersclub.wscomercios.dto.usuario.Usuario;
import pe.dinersclub.wscomercios.security.bean.UsuarioAuthorization;

public interface JWTService {

	public boolean validate(String token);

	public Claims getClaims(String token);

	public UsuarioAuthorization getPrincipal(String token);

	public Collection<? extends GrantedAuthority> getRoles(String token) throws IOException;

	public String resolve(String token);

	public String generaTokenUrl(String identificador, Usuario usuario);

	public Boolean procesarAccesosFallidos(String username, String uriRequest);

	public void addToken(String identificador, TokenDTO tokenDTO);
	
	public TokenDTO findTokenById(String identificador, String idUsuario);
	
	public boolean logout(String identificador, String idUsuario);
}
