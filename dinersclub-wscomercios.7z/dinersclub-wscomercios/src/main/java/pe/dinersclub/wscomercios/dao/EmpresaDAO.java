package pe.dinersclub.wscomercios.dao;

import java.util.List;

import pe.dinersclub.wscomercios.dto.comercio.ComercioDTO;
import pe.dinersclub.wscomercios.dto.empresa.EmpresaDTO;

public interface EmpresaDAO {

	public EmpresaDTO obtenerDatosEmpresa (String idTransaccion, String idEmpresa);
	public List<ComercioDTO> listarComercios (String idTransaccion, String idEmpresa);
	
}
