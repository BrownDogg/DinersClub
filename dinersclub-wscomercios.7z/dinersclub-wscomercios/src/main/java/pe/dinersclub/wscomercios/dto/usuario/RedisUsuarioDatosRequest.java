package pe.dinersclub.wscomercios.dto.usuario;

import java.util.Date;

import pe.dinersclub.wscomercios.domain.usuario.UsuarioDatosResponse;

public class RedisUsuarioDatosRequest {

	private UsuarioDatosResponse respuesta;
	private Date fechaConsulta;

	public UsuarioDatosResponse getRespuesta() {
		return respuesta;
	}

	public void setRespuesta(UsuarioDatosResponse respuesta) {
		this.respuesta = respuesta;
	}

	public Date getFechaConsulta() {
		return fechaConsulta;
	}

	public void setFechaConsulta(Date fechaConsulta) {
		this.fechaConsulta = fechaConsulta;
	}

}
