package pe.dinersclub.wscomercios.security.bean;

import java.util.Collection;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.SpringSecurityCoreVersion;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;

/*
 * Clase que permite añadir el campo id de usuario y el campo acceso para agregarlo en el token
 */
public class UsuarioAuthentication extends User implements UserDetails {

	private static final long serialVersionUID = SpringSecurityCoreVersion.SERIAL_VERSION_UID;

	private Long idUsuario;
	private String empresa;

	// atributo que permite indicar el acceso a las apis si el usuario realizó su
	// cambio de contraseña
	// true: permite el acceso a todas las apis según el rol - false: permite el
	// acceso solo al api de cambio de contraseña
	private boolean acceso;

	public UsuarioAuthentication(Long idUsuario, String empresa, String username, String password, boolean enabled,
			boolean acceso, boolean accountNonExpired, boolean credentialsNonExpired, boolean accountNonLocked,
			Collection<? extends GrantedAuthority> authorities) {

		super(username, password, enabled, accountNonExpired, credentialsNonExpired, accountNonLocked, authorities);
		this.empresa = empresa;
		this.idUsuario = idUsuario;
		this.acceso = acceso;
	}

	public Long getIdUsuario() {
		return idUsuario;
	}

	public void setIdUsuario(Long idUsuario) {
		this.idUsuario = idUsuario;
	}

	public String getEmpresa() {
		return empresa;
	}

	public void setEmpresa(String empresa) {
		this.empresa = empresa;
	}

	public boolean isAcceso() {
		return acceso;
	}

	public void setAcceso(boolean acceso) {
		this.acceso = acceso;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	/**
	 * 
	 */

}
