package pe.dinersclub.wscomercios.dto.cad;

public class CadDatosTarjeta {

	private Long numeroCuenta;
	private String nombreSocio;
	private String anioVencimiento;
	private String mesVencimiento;
	private String bloqueoTarjeta;
	private Long idencta;
	private boolean isActivo;
	private String fechaVencimiento;

	public Long getNumeroCuenta() {
		return numeroCuenta;
	}

	public void setNumeroCuenta(Long numeroCuenta) {
		this.numeroCuenta = numeroCuenta;
	}

	public String getNombreSocio() {
		return nombreSocio;
	}

	public void setNombreSocio(String nombreSocio) {
		this.nombreSocio = nombreSocio;
	}

	public String getAnioVencimiento() {
		return anioVencimiento;
	}

	public void setAnioVencimiento(String anioVencimiento) {
		this.anioVencimiento = anioVencimiento;
	}

	public String getMesVencimiento() {
		return mesVencimiento;
	}

	public void setMesVencimiento(String mesVencimiento) {
		this.mesVencimiento = mesVencimiento;
	}

	public String getBloqueoTarjeta() {
		return bloqueoTarjeta;
	}

	public void setBloqueoTarjeta(String bloqueoTarjeta) {
		this.bloqueoTarjeta = bloqueoTarjeta;
	}

	public Long getIdencta() {
		return idencta;
	}

	public void setIdencta(Long idencta) {
		this.idencta = idencta;
	}

	public boolean isActivo() {
		return isActivo;
	}

	public void setActivo(boolean isActivo) {
		this.isActivo = isActivo;
	}

	public String getFechaVencimiento() {
		return fechaVencimiento;
	}

	public void setFechaVencimiento(String fechaVencimiento) {
		this.fechaVencimiento = fechaVencimiento;
	}

}
