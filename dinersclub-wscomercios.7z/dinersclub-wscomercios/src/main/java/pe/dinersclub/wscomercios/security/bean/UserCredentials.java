package pe.dinersclub.wscomercios.security.bean;

public class UserCredentials {

	private String username, password, identificador, uriRequest, tokenCaptcha;

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getIdentificador() {
		return identificador;
	}

	public void setIdentificador(String identificador) {
		this.identificador = identificador;
	}

	public String getUriRequest() {
		return uriRequest;
	}

	public void setUriRequest(String uriRequest) {
		this.uriRequest = uriRequest;
	}

	public String getTokenCaptcha() {
		return tokenCaptcha;
	}

	public void setTokenCaptcha(String tokenCaptcha) {
		this.tokenCaptcha = tokenCaptcha;
	}

}
