package pe.dinersclub.wscomercios.dao.impl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import pe.dinersclub.wscomercios.dao.CadDAO;
import pe.dinersclub.wscomercios.domain.CadDescargaSolicitudesDinersRequest;
import pe.dinersclub.wscomercios.domain.CadListarAfiliacionesRequest;
import pe.dinersclub.wscomercios.domain.CadListarAfiliacionesResponse;
import pe.dinersclub.wscomercios.domain.CadSolicitudesDinersRequest;
import pe.dinersclub.wscomercios.domain.CadSolicitudesDinersResponse;
import pe.dinersclub.wscomercios.dto.cad.CadAfiliacion;
import pe.dinersclub.wscomercios.dto.cad.CadDatosTarjeta;
import pe.dinersclub.wscomercios.dto.cad.CadServicio;
import pe.dinersclub.wscomercios.dto.cad.CadSolicitudDiners;
import pe.dinersclub.wscomercios.dto.cad.CadSolicitudesDinersDescarga;
import pe.dinersclub.wscomercios.dto.cad.GrabaBolsaMantenimientoAS;
import pe.dinersclub.wscomercios.log.BeanLog;
import pe.dinersclub.wscomercios.log.UtilLog;
import pe.dinersclub.wscomercios.log.UtilLogLevel;
import pe.dinersclub.wscomercios.util.ConnectionDB;
import pe.dinersclub.wscomercios.util.Globales;

@Repository
public class CadDAOImpl implements CadDAO {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private UtilLog utilLog;

	@Override
	public CadSolicitudesDinersResponse listarCadSolicitudesDiners(String identificador,
			CadSolicitudesDinersRequest cadSolicitudesDinersRequest) {

		BeanLog beanLog = new BeanLog();
		beanLog.setIdentificador(identificador);
		beanLog.setMetodo(new Object(){}.getClass().getEnclosingMethod().getName());
		CadSolicitudesDinersResponse cadSolicitudesDinersResponse = null;
		List<CadSolicitudDiners> cadSolicitudesDiners = new ArrayList<>();
		CadSolicitudDiners cadSolicitudDiners = null;
		Connection conn = null;
		CallableStatement cs = null;
		ResultSet rs = null;
		StringBuilder sbSQLConsulta = new StringBuilder();
		StringBuilder sbSQLCantidad = new StringBuilder();

		try {
			sbSQLConsulta.append(Globales.CALL_SP).append(Globales.ESQUEMA_PROC);
			sbSQLConsulta.append(".").append(Globales.SP_WSC_LISTARSOLICITUDESCADDINERS).append("(?,?,?,?,?,?,?)}");

			conn = ConnectionDB.getConnectionServerAS400();
			cs = conn.prepareCall(sbSQLConsulta.toString());

			cs.setString(1, cadSolicitudesDinersRequest.getCodigoComercio().toString());
			cs.setString(2, cadSolicitudesDinersRequest.getCodigoServicio());
			cs.setString(3, (cadSolicitudesDinersRequest.getNumeroTarjeta() != null) ? cadSolicitudesDinersRequest.getNumeroTarjeta().toString() : null);
			cs.setString(4, cadSolicitudesDinersRequest.getFechaInicio());
			cs.setString(5, cadSolicitudesDinersRequest.getFechaFin());
			cs.setInt(6, cadSolicitudesDinersRequest.getXpage());
			cs.setInt(7, cadSolicitudesDinersRequest.getPage());

			cs.execute();

			rs = cs.getResultSet();

			while (rs.next()) {
				cadSolicitudesDinersResponse = new CadSolicitudesDinersResponse();
				cadSolicitudDiners = new CadSolicitudDiners();
				cadSolicitudDiners.setSecuencia(rs.getLong(1));
				cadSolicitudDiners.setNumeroTarjeta(rs.getLong(2));
				cadSolicitudDiners.setSocio(rs.getString(3).trim());
				cadSolicitudDiners.setTipoSolicitud(rs.getString(4).trim());
				cadSolicitudDiners.setFechaRegistro(rs.getString(5).trim());
				cadSolicitudDiners.setCodigoServicio(rs.getString(6).trim());
				cadSolicitudDiners.setAnioVencimiento(rs.getString(7).trim());
				cadSolicitudDiners.setMesVencimiento(rs.getString(8).trim());
				cadSolicitudDiners.setMontoTope(rs.getBigDecimal(9));
				cadSolicitudDiners.setTipoDocumentoIdentidad(rs.getString(10).trim());
				cadSolicitudDiners.setNumeroDocumentoIdentidad(rs.getString(11).trim());
				cadSolicitudesDiners.add(cadSolicitudDiners);

				cadSolicitudDiners = null;
			}
			cadSolicitudesDinersResponse.setCadSolicitudesDiners(cadSolicitudesDiners);

		} catch (SQLException ex) {
			beanLog.setDescripcionMensaje(ex.getMessage());
			beanLog.setCausa(ex.getCause() != null ? ex.getCause().getMessage() : "");
			beanLog.setTipoMensaje(UtilLogLevel.ERROR.name());
			utilLog.printInfo(logger, beanLog);

		} catch (Exception ex) {
			beanLog.setDescripcionMensaje(ex.getMessage());
			beanLog.setCausa(ex.getCause() != null ? ex.getCause().getMessage() : "");
			beanLog.setTipoMensaje(UtilLogLevel.ERROR.name());
			utilLog.printInfo(logger, beanLog);

		} finally {
			try {
				if (rs != null)
					rs.close();
				if (cs != null)
					cs.close();
				if (conn != null)
					conn.close();
			} catch (SQLException ex) {
			}
		}

		if (!cadSolicitudesDiners.isEmpty()) {

			try {
				sbSQLCantidad.append(Globales.CALL_SP).append(Globales.ESQUEMA_PROC);
				sbSQLCantidad.append(".").append(Globales.SP_WSC_CANTIDADSOLICITUDESCADDINERS).append("(?,?,?,?,?)}");

				conn = ConnectionDB.getConnectionServerAS400();
				cs = conn.prepareCall(sbSQLCantidad.toString());

				cs.setLong(1, cadSolicitudesDinersRequest.getCodigoComercio());
				cs.setString(2, cadSolicitudesDinersRequest.getCodigoServicio());
				cs.setString(3, (cadSolicitudesDinersRequest.getNumeroTarjeta() == null) ? null
						: cadSolicitudesDinersRequest.getNumeroTarjeta().toString());
				cs.setString(4, cadSolicitudesDinersRequest.getFechaInicio());
				cs.setString(5, cadSolicitudesDinersRequest.getFechaFin());
				cs.execute();
				rs = cs.getResultSet();
				while (rs.next()) {
					cadSolicitudesDinersResponse.setCantidad(rs.getLong(1));
				}

			} catch (Exception ex) {
				beanLog.setDescripcionMensaje(ex.getMessage());
				beanLog.setCausa(ex.getCause() != null ? ex.getCause().getMessage() : "");
				beanLog.setTipoMensaje(UtilLogLevel.ERROR.name());
				utilLog.printInfo(logger, beanLog);

			} finally {
				try {
					if (rs != null)
						rs.close();
					if (cs != null)
						cs.close();
					if (conn != null)
						conn.close();
				} catch (SQLException ex) {
				}
			}
		}

		return cadSolicitudesDinersResponse;

	}

	@Override
	public CadSolicitudesDinersDescarga listarCadSolicitudesDinersDescarga(String identificador,
			CadDescargaSolicitudesDinersRequest cadDescargaSolicitudesDinersRequest) {

		BeanLog beanLog = new BeanLog();
		beanLog.setIdentificador(identificador);
		beanLog.setMetodo(new Object(){}.getClass().getEnclosingMethod().getName());
		CadSolicitudesDinersDescarga cadSolicitudesDinersDescarga = null;
		CadSolicitudDiners cadSolicitudDiners = null;
		List<CadSolicitudDiners> cadSolicitudesDiners = new ArrayList<>();
		Connection conn = null;
		CallableStatement cs = null;
		ResultSet rs = null;
		StringBuilder sbSQLConsulta = new StringBuilder();
		int cantAfiliaciones = 0;

		try {
			sbSQLConsulta.append(Globales.CALL_SP).append(Globales.ESQUEMA_PROC);
			sbSQLConsulta.append(".").append(Globales.SP_WSC_DESCARGARSOLICITUDESCADDINERS).append("(?,?,?,?,?)}");

			conn = ConnectionDB.getConnectionServerAS400();
			cs = conn.prepareCall(sbSQLConsulta.toString());

			cs.setLong(1, cadDescargaSolicitudesDinersRequest.getCodigoComercio());
			cs.setString(2, cadDescargaSolicitudesDinersRequest.getCodigoServicio());
			cs.setString(3, (cadDescargaSolicitudesDinersRequest.getNumeroTarjeta() == null) ? null
					: cadDescargaSolicitudesDinersRequest.getNumeroTarjeta().toString());
			cs.setString(4, cadDescargaSolicitudesDinersRequest.getFechaInicio());
			cs.setString(5, cadDescargaSolicitudesDinersRequest.getFechaFin());
			cs.execute();

			rs = cs.getResultSet();

			while (rs.next()) {
				cadSolicitudesDinersDescarga = new CadSolicitudesDinersDescarga();
				cadSolicitudDiners = new CadSolicitudDiners();
				cadSolicitudDiners.setSecuencia(rs.getLong(1));
				cadSolicitudDiners.setNumeroTarjeta(rs.getLong(2));
				cadSolicitudDiners.setSocio(rs.getString(3).trim());
				cadSolicitudDiners.setTipoSolicitud(rs.getString(4).trim());
				cadSolicitudDiners.setFechaRegistro(rs.getString(5).trim());
				cadSolicitudDiners.setCodigoServicio(rs.getString(6).trim());
				cadSolicitudDiners.setAnioVencimiento(rs.getString(7).trim());
				cadSolicitudDiners.setMesVencimiento(rs.getString(8).trim());
				cadSolicitudDiners.setMontoTope(rs.getBigDecimal(9));
				cadSolicitudDiners.setTipoDocumentoIdentidad(rs.getString(10).trim());
				cadSolicitudDiners.setNumeroDocumentoIdentidad(rs.getString(11).trim());
				cantAfiliaciones = (cadSolicitudDiners.getTipoSolicitud().equals("A")) ? cantAfiliaciones + 1
						: cantAfiliaciones;
				cadSolicitudesDiners.add(cadSolicitudDiners);
			}

			if (!cadSolicitudesDiners.isEmpty()) {
				cadSolicitudesDinersDescarga.setCadSolicitudesDiners(cadSolicitudesDiners);
				cadSolicitudesDinersDescarga.setCantidadRegistros(cadSolicitudesDiners.size());
				cadSolicitudesDinersDescarga.setCantidadSolicitudesAfiliacion(cantAfiliaciones);
				cadSolicitudesDinersDescarga
						.setCantidadSolicitudesDesafiliacion(cadSolicitudesDiners.size() - cantAfiliaciones);
			}

		} catch (Exception ex) {
			beanLog.setDescripcionMensaje(ex.getMessage());
			beanLog.setCausa(ex.getCause() != null ? ex.getCause().getMessage() : "");
			beanLog.setTipoMensaje(UtilLogLevel.ERROR.name());
			utilLog.printInfo(logger, beanLog);

		} finally {
			try {
				if (rs != null)
					rs.close();
				if (cs != null)
					cs.close();
				if (conn != null)
					conn.close();
			} catch (SQLException ex) {
			}
		}

		return cadSolicitudesDinersDescarga;

	}

	@Override
	public CadDatosTarjeta obtenerDatosTarjeta(String identificador, Long numeroTarjeta) {

		BeanLog beanLog = new BeanLog();
		beanLog.setIdentificador(identificador);
		beanLog.setMetodo(new Object(){}.getClass().getEnclosingMethod().getName());
		CadDatosTarjeta datosTarjeta = null;
		Connection conn = null;
		CallableStatement cs = null;
		ResultSet rs = null;
		StringBuilder sbSQL = new StringBuilder();

		try {
			sbSQL.append(Globales.CALL_SP).append(Globales.ESQUEMA_PROC);
			sbSQL.append(".").append(Globales.SP_WSC_BUSCARTARJETA).append("(?)}");

			conn = ConnectionDB.getConnectionServerAS400();
			cs = conn.prepareCall(sbSQL.toString());

			cs.setString(1, (numeroTarjeta == null) ? null : numeroTarjeta.toString());
			cs.execute();

			rs = cs.getResultSet();

			while (rs.next()) {
				datosTarjeta = new CadDatosTarjeta();
				datosTarjeta.setNumeroCuenta(rs.getLong(1));
				datosTarjeta.setNombreSocio(rs.getString(2).trim());
				datosTarjeta.setAnioVencimiento(rs.getString(3).trim());
				datosTarjeta.setMesVencimiento(rs.getString(4).trim());
				datosTarjeta.setBloqueoTarjeta(rs.getString(5).trim());
				datosTarjeta.setIdencta(rs.getLong(6));
				datosTarjeta.setActivo((rs.getString(7).trim().equals("1") ? true : false));
				datosTarjeta.setFechaVencimiento(rs.getString(8).trim());
			}

		} catch (Exception ex) {
			beanLog.setDescripcionMensaje(ex.getMessage());
			beanLog.setCausa(ex.getCause() != null ? ex.getCause().getMessage() : "");
			beanLog.setTipoMensaje(UtilLogLevel.ERROR.name());
			utilLog.printInfo(logger, beanLog);

		} finally {
			try {
				if (rs != null)
					rs.close();
				if (cs != null)
					cs.close();
				if (conn != null)
					conn.close();
			} catch (SQLException ex) {
			}
		}

		return datosTarjeta;
	}

	@Override
	public CadServicio obtenerServicioCad(String identificador, Long codigoComercio, String codigoServicio,
			Long numeroTarjeta) {

		BeanLog beanLog = new BeanLog();
		beanLog.setIdentificador(identificador);
		beanLog.setMetodo(new Object(){}.getClass().getEnclosingMethod().getName());
		CadServicio cadServicio = null;
		Connection conn = null;
		CallableStatement cs = null;
		ResultSet rs = null;
		StringBuilder sbSQL = new StringBuilder();

		try {
			sbSQL.append(Globales.CALL_SP).append(Globales.ESQUEMA_PROC);
			sbSQL.append(".").append(Globales.SP_WSC_OBTENERSERVICIOCAD).append("(?,?,?)}");

			conn = ConnectionDB.getConnectionServerAS400();
			cs = conn.prepareCall(sbSQL.toString());

			cs.setLong(1, codigoComercio);
			cs.setString(2, codigoServicio);
			cs.setString(3, (numeroTarjeta == null) ? null : numeroTarjeta.toString());
			cs.execute();

			rs = cs.getResultSet();

			if (rs.next()) {
				cadServicio = new CadServicio();
				cadServicio.setNumeroCuenta(rs.getLong(1));
				cadServicio.setCodigoComercio(rs.getLong(2));
				cadServicio.setCodigoServicio(rs.getString(3).trim());
				cadServicio.setItem(rs.getInt(4));
				cadServicio.setNumeroTarjeta(rs.getLong(5));
				cadServicio.setAnioVencimientoTarjeta(rs.getString(6).trim());
				cadServicio.setMesVencimientoTarjeta(rs.getString(7).trim());
				cadServicio.setFechaAfiliacion(rs.getString(8).trim());
				cadServicio.setFechaDesafiliacion(rs.getString(9).trim());
				cadServicio.setOrigenAfiliacion(rs.getString(10).trim());
				cadServicio.setEstadoAfiliacion(rs.getString(11).trim());
				cadServicio.setMoneda(rs.getString(12).trim());
				cadServicio.setMontoTope(rs.getBigDecimal(13));
				cadServicio.setTelefono(rs.getString(14).trim());
				cadServicio.setEmail(rs.getString(15).trim());
				cadServicio.setNombreUsuarioServicio(rs.getString(16).trim());
				cadServicio.setTipoDocumentoIdentidadUsuarioServicio(rs.getString(17).trim());
				cadServicio.setNumeroDocumentoIdentidadUsuarioServicio(rs.getString(18).trim());
				cadServicio.setFlagCargoAutomatico(rs.getString(19).trim());
				cadServicio.setFechaPrimerCargo(rs.getString(20).trim());
				cadServicio.setFechaProximoCargo(rs.getString(21).trim());
				cadServicio.setFechaFinCargo(rs.getString(22).trim());
				cadServicio.setImporteCargoAutomatico(rs.getBigDecimal(23));

			}

		} catch (Exception ex) {
			beanLog.setDescripcionMensaje(ex.getMessage());
			beanLog.setCausa(ex.getCause() != null ? ex.getCause().getMessage() : "");
			beanLog.setTipoMensaje(UtilLogLevel.ERROR.name());
			utilLog.printInfo(logger, beanLog);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (cs != null)
					cs.close();
				if (conn != null)
					conn.close();
			} catch (SQLException ex) {
			}
		}

		return cadServicio;

	}

	@Override
	public String guardarAfiliacionIndividual(String identificador, String pData, String pData1) {

		BeanLog beanLog = new BeanLog();
		beanLog.setIdentificador(identificador);
		beanLog.setMetodo(new Object(){}.getClass().getEnclosingMethod().getName());
		String resultado = "";
		Connection conn = null;
		CallableStatement cs = null;
		ResultSet rs = null;
		StringBuilder sbSQL = new StringBuilder();

		try {
			sbSQL.append(Globales.CALL_SP).append(Globales.ESQUEMA_PROC);
			sbSQL.append(".").append(Globales.SP_WSC_GRABARAFILIACIONINDIVIDUAL).append("(?,?,?)}");

			conn = ConnectionDB.getConnectionServerAS400();
			cs = conn.prepareCall(sbSQL.toString());

			cs.setString(1, pData);
			cs.setString(3, pData1);
			cs.registerOutParameter(2, 12);
			cs.execute();
			resultado = cs.getString(2);

		} catch (Exception ex) {
			beanLog.setDescripcionMensaje(ex.getMessage());
			beanLog.setCausa(ex.getCause() != null ? ex.getCause().getMessage() : "");
			beanLog.setTipoMensaje(UtilLogLevel.ERROR.name());
			utilLog.printInfo(logger, beanLog);

		} finally {
			try {
				if (rs != null)
					rs.close();
				if (cs != null)
					cs.close();
				if (conn != null)
					conn.close();
			} catch (SQLException ex) {
			}
		}

		return resultado.substring(2, 5);

	}

	@Override
	public CadListarAfiliacionesResponse listarCadAfiliaciones(String identificador,
			CadListarAfiliacionesRequest cadListarAfiliacionesRequest) {

		BeanLog beanLog = new BeanLog();
		beanLog.setIdentificador(identificador);
		beanLog.setMetodo(new Object(){}.getClass().getEnclosingMethod().getName());
		CadListarAfiliacionesResponse cadListarAfiliacionesResponse = null;
		List<CadAfiliacion> cadListarAfiliaciones = new ArrayList<>();
		CadAfiliacion cadAfiliacion = null;
		Connection conn = null;
		CallableStatement cs = null;
		ResultSet rs = null;
		StringBuilder sbSQLConsulta = new StringBuilder();
		StringBuilder sbSQLCantidad = new StringBuilder();

		try {
			sbSQLConsulta.append(Globales.CALL_SP).append(Globales.ESQUEMA_PROC);
			sbSQLConsulta.append(".").append(Globales.SP_WSC_LISTARAFILIACIONESCAD).append("(?,?,?,?,?,?,?,?,?,?,?)}");

			conn = ConnectionDB.getConnectionServerAS400();
			cs = conn.prepareCall(sbSQLConsulta.toString());

			cs.setString(1, cadListarAfiliacionesRequest.getCodigoComercio().toString());
			cs.setString(2, cadListarAfiliacionesRequest.getCodigoServicio());
			cs.setString(3, (cadListarAfiliacionesRequest.getNumeroTarjeta() == null) ? null
					: cadListarAfiliacionesRequest.getNumeroTarjeta().toString());
			cs.setString(4, cadListarAfiliacionesRequest.getIdEstadoServicio());
			cs.setString(5, cadListarAfiliacionesRequest.getUsuarioServicio());
			cs.setString(6, cadListarAfiliacionesRequest.getIdTipoDocumentoIdentidad());
			cs.setString(7, cadListarAfiliacionesRequest.getNumeroDocumentoIdentidad());
			cs.setString(8, cadListarAfiliacionesRequest.getFechaInicio());
			cs.setString(9, cadListarAfiliacionesRequest.getFechaFin());
			cs.setInt(10, cadListarAfiliacionesRequest.getXpage());
			cs.setInt(11, cadListarAfiliacionesRequest.getPage());

			cs.execute();

			rs = cs.getResultSet();

			while (rs.next()) {
				cadListarAfiliacionesResponse = new CadListarAfiliacionesResponse();
				cadAfiliacion = new CadAfiliacion();
				cadAfiliacion.setCodigoServicio(rs.getString(1).trim());
				cadAfiliacion.setNumeroTarjeta(rs.getLong(2));
				cadAfiliacion.setMesVencimientoTarjeta(rs.getString(3).trim());
				cadAfiliacion.setAnioVencimientoTarjeta(rs.getString(4).trim());
				cadAfiliacion.setFechaAfiliacion(rs.getString(5).trim());
				cadAfiliacion.setMontoTope(rs.getBigDecimal(6));
				cadAfiliacion.setUsuarioServicio(rs.getString(7).trim());
				cadAfiliacion.setTipoDocumentoIdentidad(rs.getString(8).trim());
				cadAfiliacion.setNumeroDocumentoIdentidad(rs.getString(9));
				cadAfiliacion.setEstadoServicio(rs.getString(10).trim());
				cadAfiliacion.setEstadoTarjeta(rs.getString(11).trim());

				cadListarAfiliaciones.add(cadAfiliacion);

				cadAfiliacion = null;
			}
			cadListarAfiliacionesResponse.setAfiliaciones(cadListarAfiliaciones);

		} catch (Exception ex) {
			beanLog.setDescripcionMensaje(ex.getMessage());
			beanLog.setCausa(ex.getCause() != null ? ex.getCause().getMessage() : "");
			beanLog.setTipoMensaje(UtilLogLevel.ERROR.name());
			utilLog.printInfo(logger, beanLog);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (cs != null)
					cs.close();
				if (conn != null)
					conn.close();
			} catch (SQLException ex) {
			}
		}

		if (!cadListarAfiliaciones.isEmpty()) {

			try {
				sbSQLCantidad.append(Globales.CALL_SP).append(Globales.ESQUEMA_PROC);
				sbSQLCantidad.append(".").append(Globales.SP_WSC_CANTIDADAFILIACIONESCAD)
						.append("(?,?,?,?,?,?,?,?,?)}");

				conn = ConnectionDB.getConnectionServerAS400();
				cs = conn.prepareCall(sbSQLCantidad.toString());

				cs.setString(1, cadListarAfiliacionesRequest.getCodigoComercio().toString());
				cs.setString(2, cadListarAfiliacionesRequest.getCodigoServicio());
				cs.setString(3, (cadListarAfiliacionesRequest.getNumeroTarjeta() == null) ? null
						: cadListarAfiliacionesRequest.getNumeroTarjeta().toString());
				cs.setString(4, cadListarAfiliacionesRequest.getIdEstadoServicio());
				cs.setString(5, cadListarAfiliacionesRequest.getUsuarioServicio());
				cs.setString(6, cadListarAfiliacionesRequest.getIdTipoDocumentoIdentidad());
				cs.setString(7, cadListarAfiliacionesRequest.getNumeroDocumentoIdentidad());
				cs.setString(8, cadListarAfiliacionesRequest.getFechaInicio());
				cs.setString(9, cadListarAfiliacionesRequest.getFechaFin());

				cs.execute();
				rs = cs.getResultSet();
				while (rs.next()) {
					cadListarAfiliacionesResponse.setCantidad(rs.getLong(1));
				}

			} catch (Exception ex) {
				beanLog.setDescripcionMensaje(ex.getMessage());
				beanLog.setCausa(ex.getCause() != null ? ex.getCause().getMessage() : "");
				beanLog.setTipoMensaje(UtilLogLevel.ERROR.name());
				utilLog.printInfo(logger, beanLog);

			} finally {
				try {
					if (rs != null)
						rs.close();
					if (cs != null)
						cs.close();
					if (conn != null)
						conn.close();
				} catch (SQLException ex) {
				}
			}
		}

		return cadListarAfiliacionesResponse;

	}

	@Override
	public String obtenerCorrelativoBolsa(String identificador, String tipoBolsa) {

		BeanLog beanLog = new BeanLog();
		beanLog.setIdentificador(identificador);
		beanLog.setMetodo(new Object(){}.getClass().getEnclosingMethod().getName());
		String correlativo = null;
		Connection conn = null;
		CallableStatement cs = null;
		StringBuilder sbSQL = new StringBuilder();

		try {
			sbSQL.append(Globales.CALL_SP).append(Globales.ESQUEMA_PROC);
			sbSQL.append(".").append(Globales.SP_WSC_OBTENERCORRELATIVOBOLSA).append("(?,?)}");

			conn = ConnectionDB.getConnectionServerAS400();
			cs = conn.prepareCall(sbSQL.toString());

			cs.setString(1, tipoBolsa);
			cs.setString(2, "");
			cs.registerOutParameter(2, java.sql.Types.VARCHAR);
			cs.execute();
			correlativo = cs.getString(2).trim();

		} catch (Exception ex) {
			beanLog.setDescripcionMensaje(ex.getMessage());
			beanLog.setCausa(ex.getCause() != null ? ex.getCause().getMessage() : "");
			beanLog.setTipoMensaje(UtilLogLevel.ERROR.name());
			utilLog.printInfo(logger, beanLog);
		} finally {
			try {
				if (cs != null)
					cs.close();
				if (conn != null)
					conn.close();
			} catch (SQLException ex) {
			}
		}

		return correlativo;

	}

	@Override
	public GrabaBolsaMantenimientoAS grabarBolsaMantemiento(String identificador, String tramaBolsaMantenimiento) {

		BeanLog beanLog = new BeanLog();
		beanLog.setIdentificador(identificador);
		beanLog.setMetodo(new Object(){}.getClass().getEnclosingMethod().getName());
		Connection conn = null;
		CallableStatement cs = null;
		StringBuilder sbSQL = new StringBuilder();
		GrabaBolsaMantenimientoAS grabaBolsaMantenimientoAS = new GrabaBolsaMantenimientoAS();

		try {
			sbSQL.append(Globales.CALL_SP).append(Globales.ESQUEMA_PROC);
			sbSQL.append(".").append(Globales.SP_WSC_GRABABOLSAMANTENIMIENTO).append("(?,?)}");

			conn = ConnectionDB.getConnectionServerAS400();
			cs = conn.prepareCall(sbSQL.toString());

			cs.setString(1, tramaBolsaMantenimiento);

			cs.registerOutParameter(1, java.sql.Types.VARCHAR);
			cs.registerOutParameter(2, java.sql.Types.VARCHAR);
			cs.execute();

			grabaBolsaMantenimientoAS.setTramaGrabaBolsa(cs.getString(1).trim());
			grabaBolsaMantenimientoAS.setTramaRespuestaBolsa(cs.getString(2).trim());

		} catch (Exception ex) {
			beanLog.setDescripcionMensaje(ex.getMessage());
			beanLog.setCausa(ex.getCause() != null ? ex.getCause().getMessage() : "");
			beanLog.setTipoMensaje(UtilLogLevel.ERROR.name());
			utilLog.printInfo(logger, beanLog);
		} finally {
			try {
				if (cs != null)
					cs.close();
				if (conn != null)
					conn.close();
			} catch (SQLException ex) {
			}
		}

		return grabaBolsaMantenimientoAS;
	}

	@Override
	public String grabarDetalleBolsaMantenimiento(String identificador, String tramaDetalleBolsaMantenimiento) {

		BeanLog beanLog = new BeanLog();
		beanLog.setIdentificador(identificador);
		beanLog.setMetodo(new Object(){}.getClass().getEnclosingMethod().getName());
		Connection conn = null;
		CallableStatement cs = null;
		StringBuilder sbSQL = new StringBuilder();
		String tramaDetalleRespuesta = null;

		try {
			sbSQL.append(Globales.CALL_SP).append(Globales.ESQUEMA_PROC);
			sbSQL.append(".").append(Globales.SP_WSC_GRABADETALLEBOLSAMANTENIMIENTO).append("(?,?)}");

			conn = ConnectionDB.getConnectionServerAS400();
			cs = conn.prepareCall(sbSQL.toString());

			cs.setString(1, tramaDetalleBolsaMantenimiento);

			cs.registerOutParameter(2, java.sql.Types.VARCHAR);
			cs.execute();

			tramaDetalleRespuesta = cs.getString(2).trim();

		} catch (Exception ex) {
			beanLog.setDescripcionMensaje(ex.getMessage());
			beanLog.setCausa(ex.getCause() != null ? ex.getCause().getMessage() : "");
			beanLog.setTipoMensaje(UtilLogLevel.ERROR.name());
			utilLog.printInfo(logger, beanLog);
		} finally {
			try {
				if (cs != null)
					cs.close();
				if (conn != null)
					conn.close();
			} catch (SQLException ex) {
			}
		}

		return tramaDetalleRespuesta;
	}

}
