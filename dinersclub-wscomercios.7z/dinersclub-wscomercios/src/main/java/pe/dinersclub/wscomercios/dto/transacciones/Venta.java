package pe.dinersclub.wscomercios.dto.transacciones;

import java.math.BigDecimal;

public class Venta {

	private Long codigoComercio;
	private String fechaTicket;
	private String moneda;
	private BigDecimal importe;

	public Long getCodigoComercio() {
		return codigoComercio;
	}

	public void setCodigoComercio(Long codigoComercio) {
		this.codigoComercio = codigoComercio;
	}

	public String getFechaTicket() {
		return fechaTicket;
	}

	public void setFechaTicket(String fechaTicket) {
		this.fechaTicket = fechaTicket;
	}

	public String getMoneda() {
		return moneda;
	}

	public void setMoneda(String moneda) {
		this.moneda = moneda;
	}

	public BigDecimal getImporte() {
		return importe;
	}

	public void setImporte(BigDecimal importe) {
		this.importe = importe;
	}
}
