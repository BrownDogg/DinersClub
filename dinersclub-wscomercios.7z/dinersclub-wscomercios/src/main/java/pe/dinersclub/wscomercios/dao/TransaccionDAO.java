package pe.dinersclub.wscomercios.dao;

import java.util.List;

import pe.dinersclub.wscomercios.domain.transaccion.DevolucionDomRequest;
import pe.dinersclub.wscomercios.domain.transaccion.DevolucionCabecera;
import pe.dinersclub.wscomercios.domain.transaccion.DevolucionDetalle;
import pe.dinersclub.wscomercios.domain.transaccion.VentaRequest;
import pe.dinersclub.wscomercios.domain.transaccion.VentaResponse;
import pe.dinersclub.wscomercios.dto.transacciones.ConsumoDTO;
import pe.dinersclub.wscomercios.dto.transacciones.ConsumoRespDTO;
import pe.dinersclub.wscomercios.dto.transacciones.DevolucionRespDTO;
import pe.dinersclub.wscomercios.dto.transacciones.EvolucionVentaDTO;
import pe.dinersclub.wscomercios.dto.transacciones.EvolucionVentaRespDTO;

public interface TransaccionDAO {

	public VentaResponse listarVentasxComercio(String idTransaccion, VentaRequest ventaRequest);
	public VentaResponse listarVentasxEmpresa(String idTransaccion, Long rucEmpresa, VentaRequest ventaRequest);
	public List<EvolucionVentaRespDTO> listarEvolucionVentas(String idTransaccion, EvolucionVentaDTO evolVentaComercio);
	public List<ConsumoRespDTO> litarConsumos(String idTransaccion, ConsumoDTO consumo);
	public int registrarDevolucionCabecera(String idTransaccion, DevolucionCabecera cabecera);
	public boolean registrarDevolucionDetalle(String idTransaccion, int codigoDevolucion, int correlativo, DevolucionDetalle detalle);
	public void rollBackRegistroDevolucion(String idTransaccion, int codigoDevolucion);
	public List<DevolucionRespDTO> listarDevolucion(String idTransaccion, DevolucionDomRequest devolucion);
	
}
