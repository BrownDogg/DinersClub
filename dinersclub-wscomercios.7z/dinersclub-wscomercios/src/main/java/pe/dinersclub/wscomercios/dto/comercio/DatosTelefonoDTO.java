package pe.dinersclub.wscomercios.dto.comercio;

public class DatosTelefonoDTO {
	
	private String codComercio;
	private String nroItem;
	private String tipoTelefono;
	private String nroTelefono;
	
	public String getCodComercio() {
		return codComercio;
	}
	public void setCodComercio(String codComercio) {
		this.codComercio = codComercio;
	}
	public String getTipoTelefono() {
		return tipoTelefono;
	}
	public void setTipoTelefono(String tipoTelefono) {
		this.tipoTelefono = tipoTelefono;
	}
	public String getNroTelefono() {
		return nroTelefono;
	}
	public void setNroTelefono(String nroTelefono) {
		this.nroTelefono = nroTelefono;
	}
	public DatosTelefonoDTO() {
		super();
	}
	public String getNroItem() {
		return nroItem;
	}
	public void setNroItem(String nroItem) {
		this.nroItem = nroItem;
	}
	public DatosTelefonoDTO(String codComercio, String nroItem, String tipoTelefono, String nroTelefono) {
		super();
		this.codComercio = codComercio;
		this.nroItem = nroItem;
		this.tipoTelefono = tipoTelefono;
		this.nroTelefono = nroTelefono;
	}
	
}
