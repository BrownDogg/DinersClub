package pe.dinersclub.wscomercios.dto.transacciones;

public class DevolucionDTO {

	private String codigoComercio;
	private String numeroTarjeta;
	private String fechaConsumo;
	private String codigoAutorizacion;
	private String ticket;
	private String idMoneda;
	private String importeConsumo;
	private String importeDevolucion;
	private String tipoDevolucion;
	private String referencia;
	private String observaciones;
	
	public String getCodigoComercio() {
		return codigoComercio;
	}
	public void setCodigoComercio(String codigoComercio) {
		this.codigoComercio = codigoComercio;
	}
	public String getNumeroTarjeta() {
		return numeroTarjeta;
	}
	public void setNumeroTarjeta(String numeroTarjeta) {
		this.numeroTarjeta = numeroTarjeta;
	}
	public String getFechaConsumo() {
		return fechaConsumo;
	}
	public void setFechaConsumo(String fechaConsumo) {
		this.fechaConsumo = fechaConsumo;
	}
	public String getCodigoAutorizacion() {
		return codigoAutorizacion;
	}
	public void setCodigoAutorizacion(String codigoAutorizacion) {
		this.codigoAutorizacion = codigoAutorizacion;
	}
	public String getTicket() {
		return ticket;
	}
	public void setTicket(String ticket) {
		this.ticket = ticket;
	}
	public String getIdMoneda() {
		return idMoneda;
	}
	public void setIdMoneda(String idMoneda) {
		this.idMoneda = idMoneda;
	}
	public String getImporteConsumo() {
		return importeConsumo;
	}
	public void setImporteConsumo(String importeConsumo) {
		this.importeConsumo = importeConsumo;
	}
	public String getImporteDevolucion() {
		return importeDevolucion;
	}
	public void setImporteDevolucion(String importeDevolucion) {
		this.importeDevolucion = importeDevolucion;
	}
	public String getTipoDevolucion() {
		return tipoDevolucion;
	}
	public void setTipoDevolucion(String tipoDevolucion) {
		this.tipoDevolucion = tipoDevolucion;
	}
	public String getReferencia() {
		return referencia;
	}
	public void setReferencia(String referencia) {
		this.referencia = referencia;
	}
	public String getObservaciones() {
		return observaciones;
	}
	public void setObservaciones(String observaciones) {
		this.observaciones = observaciones;
	}
	
}
