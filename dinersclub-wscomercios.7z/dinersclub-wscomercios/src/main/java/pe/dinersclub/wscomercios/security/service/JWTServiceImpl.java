package pe.dinersclub.wscomercios.security.service;

import java.io.IOException;
import java.util.Arrays;
import java.util.Collection;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import pe.dinersclub.wscomercios.dto.usuario.TokenDTO;
import pe.dinersclub.wscomercios.dto.usuario.Usuario;
import pe.dinersclub.wscomercios.redis.service.TokenLocalService;
import pe.dinersclub.wscomercios.security.bean.UsuarioAuthorization;
import pe.dinersclub.wscomercios.security.config.JwtConfig;
import pe.dinersclub.wscomercios.security.config.SimpleGrantedAuthorityMixin;
import pe.dinersclub.wscomercios.service.SeguridadService;

@Component
public class JWTServiceImpl implements JWTService {

	@Autowired
	private JwtConfig jwtConfig;

	@Autowired
	private SeguridadService seguridadService;

	@Autowired
	private TokenLocalService tokenLocalService;

	@Override
	public boolean validate(String token) {

		try {

			getClaims(token);

			return true;
		} catch (JwtException | IllegalArgumentException e) {
			return false;
		}

	}

	@Override
	public Claims getClaims(String token) {
		Claims claims = Jwts.parser().setSigningKey(jwtConfig.getSecret().getBytes()).parseClaimsJws(resolve(token))
				.getBody();
		return claims;
	}

	@Override
	public UsuarioAuthorization getPrincipal(String token) {

		UsuarioAuthorization usuarioAuthorization = new UsuarioAuthorization();

		usuarioAuthorization.setIdUsuario(getClaims(token).getSubject());
		usuarioAuthorization.setEmpresa(getClaims(token).get("empresa").toString());
		usuarioAuthorization.setAcceso((Boolean) getClaims(token).get("access"));

		return usuarioAuthorization;
	}

	@Override
	public Collection<? extends GrantedAuthority> getRoles(String token) throws IOException {
		Object roles = getClaims(token).get("authorities");

		Collection<? extends GrantedAuthority> authorities = Arrays
				.asList(new ObjectMapper().addMixIn(SimpleGrantedAuthority.class, SimpleGrantedAuthorityMixin.class)
						.readValue(roles.toString().getBytes(), SimpleGrantedAuthority[].class));

		return authorities;
	}

	@Override
	public String resolve(String token) {
		if (token != null && token.startsWith(jwtConfig.getPrefix())) {
			return token.replace(jwtConfig.getPrefix(), "");
		} else {
			return null;
		}
	}

	@Override
	public String generaTokenUrl(String identificador, Usuario usuario) {

		String token = null;
		Long now = System.currentTimeMillis();

		Date issued = new Date(now);
		Date expires = new Date(now + jwtConfig.getExpiration() * 100);

		Claims claims = Jwts.claims();
		claims.put("authorities", "[{\"authority\":\"CHANGE_PASSWORD\"}]");
		claims.put("empresa", usuario.getRucEmpresa());
		claims.put("enabled", usuario.isEstado());
		claims.put("access", usuario.isAccesoCambioPassword());

		token = Jwts.builder().setClaims(claims).setSubject(usuario.getIdUsuario().toString())
				.signWith(SignatureAlgorithm.HS512, jwtConfig.getSecret().getBytes()).setIssuedAt(issued)
				.setExpiration(expires).compact();
		
		// Se registra el  token 
		
		TokenDTO tokenDTO = new TokenDTO(usuario.getIdUsuario().toString(), token, new Date());
		tokenLocalService.add(identificador, tokenDTO);

		return token;

	}

	@Override
	public Boolean procesarAccesosFallidos(String username, String uriRequest) {
		return seguridadService.procesarAccesosFallidos(username, uriRequest);
	}

	@Override
	public void addToken(String identificador, TokenDTO tokenDTO) {
		tokenLocalService.add(identificador, tokenDTO);
	}
	
	@Override
	public TokenDTO findTokenById(String identificador, String idUsuario) {
		return tokenLocalService.findById(identificador, idUsuario);
	}

	@Override
	public boolean logout(String identificador, String idUsuario) {
		tokenLocalService.delete(identificador, idUsuario);
		return true;
	}
	
}
