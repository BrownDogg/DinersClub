package pe.dinersclub.wscomercios.domain.comercio;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import pe.dinersclub.wscomercios.domain.empresa.DatosCuentaDomain;
import pe.dinersclub.wscomercios.domain.empresa.DatosDireccionDomain;
import pe.dinersclub.wscomercios.domain.empresa.DatosTelefonoDomain;

public class ComercioDomain {
	
	private String codigoComercio;
	private String nombreComercio;
	
	@JsonInclude(Include.NON_NULL)
	private String rucComercio;
	@JsonInclude(Include.NON_NULL)
	private String razonSocial;
	@JsonInclude(Include.NON_NULL)
	private String representanteLegal;
		
	@JsonInclude(Include.NON_NULL)
	private String paginaWeb;
	@JsonInclude(Include.NON_NULL)
	private String correoCorporativo;
	@JsonInclude(Include.NON_NULL)
	private String correoComercial;
	@JsonInclude(Include.NON_NULL)
	private String ejecutivoComercio;
	@JsonInclude(Include.NON_NULL)
	private List<DatosCuentaDomain> listaCuentas;
	@JsonInclude(Include.NON_NULL)
	private List<DatosTelefonoDomain> listaTelefonos;
	@JsonInclude(Include.NON_NULL)
	private List<DatosDireccionDomain> listaDirecciones;
		
	public ComercioDomain(String codigoComercio, String nombreComercio, String paginaWeb, String correoCorporativo,
			String correoComercial, String ejecutivoComercio) {
		super();
		this.codigoComercio = codigoComercio;
		this.nombreComercio = nombreComercio;
		this.paginaWeb = paginaWeb;
		this.correoCorporativo = correoCorporativo;
		this.correoComercial = correoComercial;
		this.ejecutivoComercio = ejecutivoComercio;
	}
	
	public ComercioDomain(String codigoComercio, String nombreComercio) {
		super();
		this.codigoComercio = codigoComercio;
		this.nombreComercio = nombreComercio;
	}
	
	public ComercioDomain() {
		super();
	}

	public String getCodigoComercio() {
		return codigoComercio;
	}

	public void setCodigoComercio(String codigoComercio) {
		this.codigoComercio = codigoComercio;
	}

	public String getNombreComercio() {
		return nombreComercio;
	}

	public void setNombreComercio(String nombreComercio) {
		this.nombreComercio = nombreComercio;
	}

	public String getRucComercio() {
		return rucComercio;
	}

	public void setRucComercio(String rucComercio) {
		this.rucComercio = rucComercio;
	}

	public String getRazonSocial() {
		return razonSocial;
	}

	public void setRazonSocial(String razonSocial) {
		this.razonSocial = razonSocial;
	}

	public String getRepresentanteLegal() {
		return representanteLegal;
	}

	public void setRepresentanteLegal(String representanteLegal) {
		this.representanteLegal = representanteLegal;
	}

	public String getPaginaWeb() {
		return paginaWeb;
	}

	public void setPaginaWeb(String paginaWeb) {
		this.paginaWeb = paginaWeb;
	}

	public String getCorreoCorporativo() {
		return correoCorporativo;
	}

	public void setCorreoCorporativo(String correoCorporativo) {
		this.correoCorporativo = correoCorporativo;
	}

	public String getCorreoComercial() {
		return correoComercial;
	}

	public void setCorreoComercial(String correoComercial) {
		this.correoComercial = correoComercial;
	}

	public String getEjecutivoComercio() {
		return ejecutivoComercio;
	}

	public void setEjecutivoComercio(String ejecutivoComercio) {
		this.ejecutivoComercio = ejecutivoComercio;
	}

	public List<DatosCuentaDomain> getListaCuentas() {
		return listaCuentas;
	}

	public void setListaCuentas(List<DatosCuentaDomain> listaCuentas) {
		this.listaCuentas = listaCuentas;
	}

	public List<DatosTelefonoDomain> getListaTelefonos() {
		return listaTelefonos;
	}

	public void setListaTelefonos(List<DatosTelefonoDomain> listaTelefonos) {
		this.listaTelefonos = listaTelefonos;
	}

	public List<DatosDireccionDomain> getListaDirecciones() {
		return listaDirecciones;
	}

	public void setListaDirecciones(List<DatosDireccionDomain> listaDirecciones) {
		this.listaDirecciones = listaDirecciones;
	}
	
}
