package pe.dinersclub.wscomercios.dto.transacciones;

public class EvolucionVentaRespDTO {

	private String fechaTicket;
	private String horaTicket;
	private double importeTicket;
	private int cantRegistros;
	
	public String getFechaTicket() {
		return fechaTicket;
	}
	public void setFechaTicket(String fechaTicket) {
		this.fechaTicket = fechaTicket;
	}
	public String getHoraTicket() {
		return horaTicket;
	}
	public void setHoraTicket(String horaTicket) {
		this.horaTicket = horaTicket;
	}
	public double getImporteTicket() {
		return importeTicket;
	}
	public void setImporteTicket(double importeTicket) {
		this.importeTicket = importeTicket;
	}
	public int getCantRegistros() {
		return cantRegistros;
	}
	public void setCantRegistros(int cantRegistros) {
		this.cantRegistros = cantRegistros;
	}
	
	@Override
	public String toString() {
		return "EvolucionVentaRespDTO [fechaTicket=" + fechaTicket + ", horaTicket=" + horaTicket + ", importeTicket="
				+ importeTicket + ", cantRegistros=" + cantRegistros + "]";
	}
	
}
