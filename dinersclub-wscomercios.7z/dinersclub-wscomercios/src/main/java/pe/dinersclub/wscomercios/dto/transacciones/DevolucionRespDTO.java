package pe.dinersclub.wscomercios.dto.transacciones;

public class DevolucionRespDTO {

	private String codigoDevolucion;
	private String codigoComercio;
	private String nombreComercio;
	private String estadoDevolucion;
	private String fechaTicket;
	private String codigoAutorizacion;
	private String numeroTarjeta;
	private Double importeConsumo;
	private String moneda;
	private String importeDevolucion;
	private String referencia;
	private String observaciones;
	private String fechaRegistro;
	private String usuarioRegistro;
	private Double saldoPendiente;
	private String tipoTransaccion;
	private String origenTransaccion;
	private String tipoDocumentoContable;
	private String numeroDocumentoContable;
	private String motivo;
	
	public String getCodigoDevolucion() {
		return codigoDevolucion;
	}
	public void setCodigoDevolucion(String codigoDevolucion) {
		this.codigoDevolucion = codigoDevolucion;
	}
	public String getCodigoComercio() {
		return codigoComercio;
	}
	public void setCodigoComercio(String codigoComercio) {
		this.codigoComercio = codigoComercio;
	}
	public String getNombreComercio() {
		return nombreComercio;
	}
	public void setNombreComercio(String nombreComercio) {
		this.nombreComercio = nombreComercio;
	}
	public String getEstadoDevolucion() {
		return estadoDevolucion;
	}
	public void setEstadoDevolucion(String estadoDevolucion) {
		this.estadoDevolucion = estadoDevolucion;
	}
	public String getFechaTicket() {
		return fechaTicket;
	}
	public void setFechaTicket(String fechaTicket) {
		this.fechaTicket = fechaTicket;
	}
	public String getCodigoAutorizacion() {
		return codigoAutorizacion;
	}
	public void setCodigoAutorizacion(String codigoAutorizacion) {
		this.codigoAutorizacion = codigoAutorizacion;
	}
	public String getNumeroTarjeta() {
		return numeroTarjeta;
	}
	public void setNumeroTarjeta(String numeroTarjeta) {
		this.numeroTarjeta = numeroTarjeta;
	}
	public Double getImporteConsumo() {
		return importeConsumo;
	}
	public void setImporteConsumo(Double importeConsumo) {
		this.importeConsumo = importeConsumo;
	}
	public String getMoneda() {
		return moneda;
	}
	public void setMoneda(String moneda) {
		this.moneda = moneda;
	}
	public String getImporteDevolucion() {
		return importeDevolucion;
	}
	public void setImporteDevolucion(String importeDevolucion) {
		this.importeDevolucion = importeDevolucion;
	}
	public String getReferencia() {
		return referencia;
	}
	public void setReferencia(String referencia) {
		this.referencia = referencia;
	}
	public String getObservaciones() {
		return observaciones;
	}
	public void setObservaciones(String observaciones) {
		this.observaciones = observaciones;
	}
	public String getFechaRegistro() {
		return fechaRegistro;
	}
	public void setFechaRegistro(String fechaRegistro) {
		this.fechaRegistro = fechaRegistro;
	}
	public String getUsuarioRegistro() {
		return usuarioRegistro;
	}
	public void setUsuarioRegistro(String usuarioRegistro) {
		this.usuarioRegistro = usuarioRegistro;
	}
	public Double getSaldoPendiente() {
		return saldoPendiente;
	}
	public void setSaldoPendiente(Double saldoPendiente) {
		this.saldoPendiente = saldoPendiente;
	}
	public String getTipoTransaccion() {
		return tipoTransaccion;
	}
	public void setTipoTransaccion(String tipoTransaccion) {
		this.tipoTransaccion = tipoTransaccion;
	}
	public String getOrigenTransaccion() {
		return origenTransaccion;
	}
	public void setOrigenTransaccion(String origenTransaccion) {
		this.origenTransaccion = origenTransaccion;
	}
	public String getTipoDocumentoContable() {
		return tipoDocumentoContable;
	}
	public void setTipoDocumentoContable(String tipoDocumentoContable) {
		this.tipoDocumentoContable = tipoDocumentoContable;
	}
	public String getNumeroDocumentoContable() {
		return numeroDocumentoContable;
	}
	public void setNumeroDocumentoContable(String numeroDocumentoContable) {
		this.numeroDocumentoContable = numeroDocumentoContable;
	}
	public String getMotivo() {
		return motivo;
	}
	public void setMotivo(String motivo) {
		this.motivo = motivo;
	}
	
}
