package pe.dinersclub.wscomercios.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.annotations.Api;
import pe.dinersclub.wscomercios.domain.BodyResponse;
import pe.dinersclub.wscomercios.domain.usuario.UsuarioDatosResponse;
import pe.dinersclub.wscomercios.domain.usuario.UsuarioOpcionResponse;
import pe.dinersclub.wscomercios.exception.ModeloNotFountException;
import pe.dinersclub.wscomercios.log.BeanLog;
import pe.dinersclub.wscomercios.log.UtilLog;
import pe.dinersclub.wscomercios.security.bean.UsuarioAuthorization;
import pe.dinersclub.wscomercios.service.UsuarioService;
import pe.dinersclub.wscomercios.util.Globales;
import pe.dinersclub.wscomercios.util.UtilDate;

@RestController
@RequestMapping("/usuarios")
@Api(tags = { "Módulo de Usuarios" })
public class UsuarioController {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private UsuarioService usuarioServiceInterface;
	@Autowired
	private HttpServletRequest request;
	@Autowired
	private UtilLog utilLog;

	@GetMapping(path = "/opciones-menu", produces = "application/json")
	public ResponseEntity<Object> listarOpcionesDeMenu(Authentication auth) {

		long fechaInicio = UtilDate.getCurrentDateTime();
		UsuarioAuthorization usuario = (UsuarioAuthorization) auth.getPrincipal();
		BeanLog beanLog = new BeanLog();
		beanLog.setSolicitud(request.getRequestURI());
		beanLog.setMetodo(new Object(){}.getClass().getEnclosingMethod().getName());
		beanLog.setEsPadre(true);
		beanLog.setNombreOperacion("Listar las opciones de Menú del usuario");
		beanLog.setIdEmpresa(usuario.getEmpresa());
		List<UsuarioOpcionResponse> opcionesDeMenu = new ArrayList<>();

		try {

			opcionesDeMenu = usuarioServiceInterface.obtenerOpcionesDeUsuario(beanLog.getIdentificador(),
					usuario.getIdUsuario());

			if (opcionesDeMenu.isEmpty()) {
				throw new ModeloNotFountException("Rol de usuario no tiene opciones asignadas.",
						beanLog.getIdentificador());
			} else {
				return new ResponseEntity<>(
						new BodyResponse<List<UsuarioOpcionResponse>>(opcionesDeMenu, Globales.RESPUESTA_EXITO),
						HttpStatus.OK);
			}

		} finally {

			long fechafinal = UtilDate.getCurrentDateTime();
			beanLog.setDuracion(fechafinal - fechaInicio);
			utilLog.printInfo(logger, beanLog);
		}
	}

	@GetMapping(path = "/consultar-datos", produces = "application/json")
	public ResponseEntity<Object> consultarDatosIniciales(Authentication auth) {

		long fechaInicio = UtilDate.getCurrentDateTime();
		UsuarioAuthorization usuario = (UsuarioAuthorization) auth.getPrincipal();
		BeanLog beanLog = new BeanLog();
		beanLog.setSolicitud(request.getRequestURI());
		beanLog.setMetodo(new Object(){}.getClass().getEnclosingMethod().getName());
		beanLog.setEsPadre(true);
		beanLog.setNombreOperacion("Obtiene los datos del usuario para navegar en la web");
		beanLog.setIdEmpresa(usuario.getEmpresa());
		UsuarioDatosResponse datosIniciales = null;

		try {

			datosIniciales = usuarioServiceInterface.obtenerDatosIniciales(beanLog.getIdentificador(),
					usuario.getIdUsuario());

			if (datosIniciales == null) {
				throw new ModeloNotFountException("Ocurrió un problema al obtener los datos iniciales.",
						beanLog.getIdentificador());
			} else if (datosIniciales.getComercios().isEmpty()) {
				throw new ModeloNotFountException("El usuario no tiene comercios asignados.",
						beanLog.getIdentificador());
			} else {
				return new ResponseEntity<>(
						new BodyResponse<UsuarioDatosResponse>(datosIniciales, Globales.RESPUESTA_EXITO),
						HttpStatus.OK);
			}

		} finally {

			long fechafinal = UtilDate.getCurrentDateTime();
			beanLog.setDuracion(fechafinal - fechaInicio);
			utilLog.printInfo(logger, beanLog);
		}
	}

}
