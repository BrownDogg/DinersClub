package pe.dinersclub.wscomercios.dto.comercio;

public class DatosDireccionDTO {
	
	private String codComercio;
	private String tipoDireccion;
	private String via;
	private String direccionComercio;
	private String nroDireccion;
	private String codigoPostal;
	private String departamento;
	private String provincia;
	private String distrito;
	
	public String getCodComercio() {
		return codComercio;
	}
	public void setCodComercio(String codComercio) {
		this.codComercio = codComercio;
	}
	public String getTipoDireccion() {
		return tipoDireccion;
	}
	public void setTipoDireccion(String tipoDireccion) {
		this.tipoDireccion = tipoDireccion;
	}
	public String getDireccionComercio() {
		return direccionComercio;
	}
	public void setDireccionComercio(String direccionComercio) {
		this.direccionComercio = direccionComercio;
	}
	public String getNroDireccion() {
		return nroDireccion;
	}
	public void setNroDireccion(String nroDireccion) {
		this.nroDireccion = nroDireccion;
	}
	public String getCodigoPostal() {
		return codigoPostal;
	}
	public void setCodigoPostal(String codigoPostal) {
		this.codigoPostal = codigoPostal;
	}
	public String getDepartamento() {
		return departamento;
	}
	public void setDepartamento(String departamento) {
		this.departamento = departamento;
	}
	public String getProvincia() {
		return provincia;
	}
	public void setProvincia(String provincia) {
		this.provincia = provincia;
	}
	public String getDistrito() {
		return distrito;
	}
	public void setDistrito(String distrito) {
		this.distrito = distrito;
	}
	public String getVia() {
		return via;
	}
	public void setVia(String via) {
		this.via = via;
	}
	public DatosDireccionDTO(String codComercio, String tipoDireccion, String via, String direccionComercio,
			String nroDireccion, String codigoPostal, String departamento, String provincia, String distrito) {
		super();
		this.codComercio = codComercio;
		this.tipoDireccion = tipoDireccion;
		this.via = via;
		this.direccionComercio = direccionComercio;
		this.nroDireccion = nroDireccion;
		this.codigoPostal = codigoPostal;
		this.departamento = departamento;
		this.provincia = provincia;
		this.distrito = distrito;
	}
	public DatosDireccionDTO() {
		super();	
	}
	
}
