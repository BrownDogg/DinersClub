package pe.dinersclub.wscomercios.dto.comercio;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

public class DatosCuentasDTO {

	private String codComercio;
	private String nroCuenta;
	private String banco;
	private String sistemaPago;
	
	public String getCodComercio() {
		return codComercio;
	}
	public void setCodComercio(String codComercio) {
		this.codComercio = codComercio;
	}
	public String getNroCuenta() {
		return nroCuenta;
	}
	public void setNroCuenta(String nroCuenta) {
		this.nroCuenta = nroCuenta;
	}
	public String getBanco() {
		return banco;
	}
	public void setBanco(String banco) {
		this.banco = banco;
	}
	public String getSistemaPago() {
		return sistemaPago;
	}
	public void setSistemaPago(String sistemaPago) {
		this.sistemaPago = sistemaPago;
	}
	public DatosCuentasDTO(String nroCuenta, String banco, String sistemaPago) {
		super();
		this.nroCuenta = nroCuenta;
		this.banco = banco;
		this.sistemaPago = sistemaPago;
	}
	
	public DatosCuentasDTO() {
		super();
	}
	
}
