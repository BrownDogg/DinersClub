package pe.dinersclub.wscomercios.domain.usuario;

import java.util.Map;

/*
 * DATOS INICIALES LUEGO DEL LOGIN DEL USUARIO
 * */

public class UsuarioDatosResponse {

	private Long rucEmpresa;
	private String razonSocial;
	private String nombresUsuario;
	private Map<Long, String> comercios;

	public Long getRucEmpresa() {
		return rucEmpresa;
	}

	public void setRucEmpresa(Long rucEmpresa) {
		this.rucEmpresa = rucEmpresa;
	}

	public String getRazonSocial() {
		return razonSocial;
	}

	public void setRazonSocial(String razonSocial) {
		this.razonSocial = razonSocial;
	}

	public String getNombresUsuario() {
		return nombresUsuario;
	}

	public void setNombresUsuario(String nombresUsuario) {
		this.nombresUsuario = nombresUsuario;
	}

	public Map<Long, String> getComercios() {
		return comercios;
	}

	public void setComercios(Map<Long, String> comercios) {
		this.comercios = comercios;
	}

}
