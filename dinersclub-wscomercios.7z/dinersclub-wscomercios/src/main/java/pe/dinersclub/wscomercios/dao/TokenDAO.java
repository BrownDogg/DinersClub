package pe.dinersclub.wscomercios.dao;

import pe.dinersclub.wscomercios.dto.usuario.TokenDTO;

public interface TokenDAO {
	
	public void add(String identificador, TokenDTO object);

	public TokenDTO findById(String identificador, final String idUsuario);
}
