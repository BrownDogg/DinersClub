package pe.dinersclub.wscomercios.service.impl;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.math.BigDecimal;
import java.nio.file.Path;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import pe.dinersclub.wscomercios.dao.TransaccionDAO;
import pe.dinersclub.wscomercios.domain.ConsumoResp;
import pe.dinersclub.wscomercios.domain.ConsumosRequest;
import pe.dinersclub.wscomercios.domain.EvolucionVentaRequest;
import pe.dinersclub.wscomercios.domain.EvolucionVentaResponse;
import pe.dinersclub.wscomercios.domain.VentaXRango;
import pe.dinersclub.wscomercios.domain.transaccion.DevolucionDomRequest;
import pe.dinersclub.wscomercios.domain.transaccion.DevolucionMasivaResponse;
import pe.dinersclub.wscomercios.domain.transaccion.DevolucionCabecera;
import pe.dinersclub.wscomercios.domain.transaccion.DevolucionDetalle;
import pe.dinersclub.wscomercios.domain.transaccion.VentaRequest;
import pe.dinersclub.wscomercios.domain.transaccion.VentaResponse;
import pe.dinersclub.wscomercios.dto.transacciones.ConsumoDTO;
import pe.dinersclub.wscomercios.dto.transacciones.ConsumoRespDTO;
import pe.dinersclub.wscomercios.dto.transacciones.DevolucionRespDTO;
import pe.dinersclub.wscomercios.dto.transacciones.EvolucionVentaDTO;
import pe.dinersclub.wscomercios.dto.transacciones.EvolucionVentaRespDTO;
import pe.dinersclub.wscomercios.log.BeanLog;
import pe.dinersclub.wscomercios.log.UtilLog;
import pe.dinersclub.wscomercios.log.UtilLogLevel;
import pe.dinersclub.wscomercios.service.TransaccionService;
import pe.dinersclub.wscomercios.util.GeneradorRangoFechas;
import pe.dinersclub.wscomercios.util.Globales;
import pe.dinersclub.wscomercios.util.UtilAuditoria;
import pe.dinersclub.wscomercios.util.UtilDate;
import pe.dinersclub.wscomercios.util.UtilFile;
import pe.dinersclub.wscomercios.util.UtilString;

@Service
public class TransaccionServiceImpl implements TransaccionService {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private UtilLog utilLog;

	@Autowired
	private UtilAuditoria utilAudit;

	@Autowired
	private UtilFile utilFile;

	@Autowired
	private TransaccionDAO transaccionDao;

	@Override
	public VentaResponse listarVentas(String idTransaccion, Long rucEmpresa, VentaRequest ventaRequest) {
		VentaResponse ventaResponse = null;
		BeanLog beanLog = new BeanLog();
		beanLog.setMetodo(new Object() {
		}.getClass().getEnclosingMethod().getName());

		/**
		 * Si se recibe el codigo de comercio, el resultado devulve las ventas del
		 * comercio Caso contrario devuelve las ventas de toda la empresa
		 */
		try {

			if (ventaRequest.getCodigoComercio() == null) {
				ventaResponse = transaccionDao.listarVentasxEmpresa(idTransaccion, rucEmpresa, ventaRequest);

			} else {
				ventaResponse = transaccionDao.listarVentasxComercio(idTransaccion, ventaRequest);
			}
		} catch (Exception ex) {
			ex.printStackTrace();
			beanLog.setDescripcionMensaje(ex.getMessage());
			beanLog.setCausa(ex.getCause() != null ? ex.getCause().getMessage() : "");
			beanLog.setTipoMensaje(UtilLogLevel.ERROR.name());
			utilLog.printInfo(logger, beanLog);
		}

		return ventaResponse;
	}

	@Override
	public EvolucionVentaResponse listarEvolucionVentas(String idTransaccion, EvolucionVentaRequest evolucionRequest) {

		BigDecimal importeTotal = null;
		List<VentaXRango> listaVentaRango = null;
		EvolucionVentaDTO req = new EvolucionVentaDTO();
		VentaXRango ventaRango = null;
		EvolucionVentaResponse response = null;
		List<EvolucionVentaRespDTO> listaEvol = null;
		int cantRegistros = 0;

		try {

			req.setIdEmpresa(evolucionRequest.getIdEmpresa());
			req.setIdComercio(evolucionRequest.getIdComercio());
			req.setFechaInicio(evolucionRequest.getFechaInicio());
			req.setFechaFin(evolucionRequest.getFechaFin());
			req.setMoneda(evolucionRequest.getMoneda());

			Date fIni = UtilDate.convertStringToDate(evolucionRequest.getFechaInicio(), "yyyyMMdd");
			Date fFin = UtilDate.convertStringToDate(evolucionRequest.getFechaFin(), "yyyyMMdd");

			int rangoFec = (int) ((fFin.getTime() - fIni.getTime()) / 86400000);

			listaEvol = transaccionDao.listarEvolucionVentas(idTransaccion, req);

//			if (rangoFec == 0) { //DEPRECADO POR DATA (HORAS REGISTRADAS CON 999999
//				listaEvol = transaccionDao.listarEvolucionVentas(req);
//				if (!listaEvol.isEmpty())
//					listaVentaRango = evolXDia(evolucionRequest.getFechaInicio(), listaEvol);
//				cantRegistros = listaVentaRango.size();
//			} else 
			if (listaEvol == null || listaEvol.isEmpty()) {
				response = new EvolucionVentaResponse();
				listaVentaRango = new LinkedList<>();
				response.setCantidadRegistros(0);
				response.setTotalVentas(new BigDecimal(0));
				response.setListaVentaRango(listaVentaRango);
				return response;
			} else {
				listaVentaRango = new LinkedList<>();
				if (rangoFec >= 0 && rangoFec <= 7) {
					for (EvolucionVentaRespDTO aux : listaEvol) {
						ventaRango = new VentaXRango();
						ventaRango.setDescripcionRango(
								UtilDate.convertStringToDateString(aux.getFechaTicket(), "yyyyMMdd", "dd/MM"));
						ventaRango.setImporteRango(BigDecimal.valueOf(aux.getImporteTicket()));
						cantRegistros += aux.getCantRegistros();
						listaVentaRango.add(ventaRango);
					}
				} else if (rangoFec >= 8 && (fIni.getMonth() == fFin.getMonth())) {
					listaVentaRango = GeneradorRangoFechas.evolXSemana(fIni, fFin, listaEvol);
					for (EvolucionVentaRespDTO aux : listaEvol) {
						cantRegistros += aux.getCantRegistros();
					}
				} else if ((rangoFec >= 8 && rangoFec < 30) && (fIni.getMonth() != fFin.getMonth())) {
					listaVentaRango = GeneradorRangoFechas.evolXMeses(fIni, fFin, listaEvol, false);
					for (EvolucionVentaRespDTO aux : listaEvol) {
						cantRegistros += aux.getCantRegistros();
					}

				} else if (rangoFec > 30 || !UtilDate.validaFechaInicioMayorAFechaTope(fIni, fFin)) {
					listaVentaRango = GeneradorRangoFechas.evolXMeses(fIni, fFin, listaEvol, true);
					for (EvolucionVentaRespDTO aux : listaEvol) {
						cantRegistros += aux.getCantRegistros();
					}
				}

				importeTotal = new BigDecimal(0);
				for (VentaXRango aux : listaVentaRango) {
					importeTotal = importeTotal.add(aux.getImporteRango());
				}
				response = new EvolucionVentaResponse();
				response.setCantidadRegistros(cantRegistros);
				response.setTotalVentas(importeTotal);
				response.setListaVentaRango(listaVentaRango);

				return response;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public List<ConsumoResp> listarConsumos(String idTransaccion, ConsumosRequest consumoRequest) {

		List<ConsumoResp> listaConsumos = null;
		ConsumoResp consumos = null;
		try {

			ConsumoDTO bean = new ConsumoDTO();
			bean.setIdEmpresa(consumoRequest.getIdEmpresa());
			bean.setIdComercio(consumoRequest.getIdComercio());
			bean.setIdMoneda(consumoRequest.getIdMoneda());
			bean.setIdEstadoConsumo(consumoRequest.getIdEstadoConsumo());
			bean.setFechaInicio(consumoRequest.getFechaInicio());
			bean.setFechaFin(consumoRequest.getFechaFin());
			bean.setPage(consumoRequest.getPage());
			bean.setXpage(consumoRequest.getXpage());

			List<ConsumoRespDTO> lista = transaccionDao.litarConsumos(idTransaccion, bean);

			if (lista.isEmpty() || lista != null) {

				listaConsumos = new LinkedList<>();

				for (ConsumoRespDTO aux : lista) {
					consumos = new ConsumoResp();
					consumos.setCodigoComercio(aux.getCodigoComercio());
					consumos.setNombreComercio(aux.getNombreComercio().trim());
					consumos.setOrigenTransaccion(aux.getOrigenTransaccion().trim());
					consumos.setFechaProceso(aux.getFechaProceso());
					consumos.setTarjeta(aux.getTarjeta().trim());
					consumos.setTipoTarjeta(aux.getTipoTarjeta());
					consumos.setCodAutorizacion(aux.getCodAutorizacion());
					consumos.setFechaTicket(aux.getFechaTicket());
					consumos.setNumeroTicket(aux.getNumeroTicket());
					consumos.setMoneda(aux.getMoneda());
					consumos.setImporte(aux.getImporte());
					consumos.setNumeroCuotas(aux.getNumeroCuotas());
					consumos.setEstadoTicket(aux.getEstadoTicket());
					consumos.setPlazoPago(aux.getPlazoPago());
					consumos.setFechaPago(aux.getFechaPago());
					consumos.setComision(aux.getComision());
					consumos.setIgv(aux.getIgv());
					consumos.setImporteNeto(aux.getImporteNeto());

					listaConsumos.add(consumos);
				}
			}

			return listaConsumos;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public LinkedHashMap<String, String> cargarDevolucionIndividual(String idTransaccion, DevolucionDetalle devolucionDetalle) {

		BeanLog beanLog = new BeanLog();
		DevolucionCabecera cabecera = null;
		boolean respDetalle = false;
		int nroRegistro = Globales.DEVOLUCION_INDIVIDUAL;
		LinkedHashMap<String, String> response = new LinkedHashMap<String, String>();

		String idTrx = UtilString.obtenerIdentificadorUnico();

		try {

			beanLog = utilAudit.initLog(idTrx, "", "cargarDevolucionIndividual", true, "Devolución Individual");

			if (!devolucionDetalle.validarDataVacia(devolucionDetalle))
				return null;
			if (!validarIntegridadData(beanLog, devolucionDetalle))
				return null;

			cabecera = new DevolucionCabecera();
			cabecera.setCodigoComercio(devolucionDetalle.getCodigoComercio());
			cabecera.setOrigenTranx(Globales.ModuloTransacciones.ORIGEN_TRANSACCION_POR_COMERCIO);
			cabecera.setNroRegistros(String.valueOf(nroRegistro));
			cabecera.setFechaReg(UtilDate.fechaHoyYYYYMMDD());
			cabecera.setHoraReg(UtilDate.horaActualHHMMSS());

			int codDvl = transaccionDao.registrarDevolucionCabecera(idTransaccion, cabecera);

			if (codDvl != 0) {
				respDetalle = transaccionDao.registrarDevolucionDetalle(idTransaccion, codDvl, nroRegistro, devolucionDetalle);
			}

			// ROLLBACK
			if (respDetalle) {
				response.put("codigoSeguimiento", String.valueOf(codDvl));
				return response;
			} else {
				rollBackDevolucion(idTransaccion, codDvl);
				return null;
			}

		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public DevolucionMasivaResponse cargarDevolucionMasiva(String idTransaccion, Long codigoComercio, MultipartFile file) {

		long fechaInicio = UtilDate.getCurrentDateTime();
		BeanLog beanLog = new BeanLog();
		String idTrx = UtilString.obtenerIdentificadorUnico();
		String extension = "";
		boolean resultado = false;
		String fileName = "";
		List<DevolucionDetalle> listaDevolucion = null;
		DevolucionCabecera cabecera = null;
		boolean respDetalle = false;
		DevolucionMasivaResponse response = null;
		String archivo = "";

		try {

			beanLog = utilAudit.initLog(idTrx, null, "cargaDevolucionMasiva", true, "Devolución Masiva");

			// 1. Validar extensión de archivo
			extension = utilFile.obtenerExtension(file);
			if (extension.isEmpty())
				return null;

			resultado = utilFile.validaExtension(extension);
			if (!resultado)
				return null;

			archivo = UtilDate.fechaHoyYYYYMMDD() + UtilDate.horaActualHHMMSS();
			fileName = utilFile.storeFile(file, archivo + "." + extension, idTrx);

			// 2.0 Mover archivo al Servidor
			listaDevolucion = obtenerDatosArchivoExcel(codigoComercio, fileName, idTrx);

			utilFile.eliminarArchivo(fileName);

			// 3.0 Registrar Cabecera

			if (listaDevolucion.size() > 0) {

				cabecera = new DevolucionCabecera();
				cabecera.setCodigoComercio(codigoComercio.toString());
				cabecera.setOrigenTranx(Globales.ModuloTransacciones.ORIGEN_TRANSACCION_POR_COMERCIO);
				cabecera.setNroRegistros(String.valueOf(listaDevolucion.size()));
				cabecera.setFechaReg(UtilDate.fechaHoyYYYYMMDD());
				cabecera.setHoraReg(UtilDate.horaActualHHMMSS());

				int codDvl = transaccionDao.registrarDevolucionCabecera(idTransaccion, cabecera);

				// 4.0 Registrar Detalle
				if (codDvl != 0) {
					int correlativo = 0;
					for (DevolucionDetalle devolucionDetalle : listaDevolucion) {
						correlativo++;
						respDetalle = transaccionDao.registrarDevolucionDetalle(idTransaccion, codDvl, correlativo, devolucionDetalle);
						if (!respDetalle)
							break;
					}
				}

				// ROLLBACK
				if (respDetalle) {
					response = new DevolucionMasivaResponse();
					response.setCodigoDevolucion(String.valueOf(codDvl));

					for (DevolucionDetalle aux : listaDevolucion) {
						aux.setIdMoneda(UtilString.valorMoneda(aux.getIdMoneda()));
						aux.setTipoDevolucion(UtilString.valorTipoDevolucion(aux.getTipoDevolucion()));
					}

					response.setListaDetalleDevolucion(listaDevolucion);
					return response;

				} else {
					rollBackDevolucion(idTransaccion, codDvl);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			utilAudit.endLog(beanLog, fechaInicio);
		}
		return null;
	}

	@Override
	public List<DevolucionRespDTO> listarDevolucion(String idTransaccion, DevolucionDomRequest devolucionRequest) {
		return transaccionDao.listarDevolucion(idTransaccion, devolucionRequest);
	}

	private List<DevolucionDetalle> obtenerDatosArchivoExcel(Long codigoComercio, String nombreArchivo,
			String identificador) {

		BeanLog beanLog = new BeanLog();
		beanLog.setIdentificador(identificador);
		beanLog.setMetodo(new Object() {
		}.getClass().getEnclosingMethod().getName());

		List<DevolucionDetalle> listaDevolucion = new LinkedList<>();
		DevolucionDetalle devolucion = null;
		FileInputStream fis = null;
		XSSFWorkbook wb = null;
		Path filePath = utilFile.loadFileAsPath(nombreArchivo, identificador);
		int errorRow = 0;

		try {

			fis = new FileInputStream(filePath.toFile());
			wb = new XSSFWorkbook(fis);
			Sheet firstSheet = wb.getSheetAt(0);
			Iterator<Row> iterator = firstSheet.iterator();
			iterator.next();

			while (iterator.hasNext()) {

				Row nextRow = iterator.next();
				Iterator<Cell> cellIterator = nextRow.cellIterator();
				devolucion = new DevolucionDetalle();
				errorRow++;

				while (cellIterator.hasNext()) {
					Cell nextCell = cellIterator.next();
					int columnIndex = nextCell.getColumnIndex();

					switch (columnIndex) {

					case 0:
						devolucion.setCodigoComercio(nextCell.getStringCellValue());
						if (!devolucion.getCodigoComercio().equals(codigoComercio.toString())) {
							utilAudit.errorMessageLog(beanLog, Globales.ModuloTransacciones.CODIGO_COMERCIO_INCORRECTO,
									UtilLogLevel.INFO.name(),
									"El Codigo de Comercio es incorrecto. Error en línea: " + errorRow);
						}
						break;

					case 1:
						devolucion.setNumeroTarjeta(nextCell.getStringCellValue());
						if (!UtilString.validarEsNumerico(devolucion.getNumeroTarjeta())) {
							utilAudit.errorMessageLog(beanLog, Globales.ModuloTransacciones.NUMERO_TARJETA_NO_NUMERICO,
									UtilLogLevel.INFO.name(),
									"El Nro de Tarjeta debe ser numérico. Error en línea: " + errorRow);
						}
						break;

					case 2:
						devolucion.setFechaConsumo(nextCell.getStringCellValue());
						if (!UtilDate.validarEsFecha(devolucion.getFechaConsumo(), Globales.FORMATO_FECHA_YYYYMMDD)) {
							utilAudit.errorMessageLog(beanLog, Globales.ModuloTransacciones.FORMATO_FECHA_INCORRECTO,
									UtilLogLevel.INFO.name(), "El formato de la fecha debe ser: "
											+ Globales.FORMATO_FECHA_YYYYMMDD + ". Error en línea: " + errorRow);
						}
						break;

					case 3:
						devolucion.setCodigoAutorizacion(nextCell.getStringCellValue());
						if (!UtilString.validarEsNumerico(devolucion.getCodigoAutorizacion())) {
							utilAudit.errorMessageLog(beanLog,
									Globales.ModuloTransacciones.CODIGO_AUTORIZACION_NO_NUMERICO,
									UtilLogLevel.INFO.name(),
									"El Código de Autorización debe ser numérico. Error en línea: " + errorRow);
						}
						break;

					case 4:
						devolucion.setNroTicket(nextCell.getStringCellValue());
						if (!UtilString.validarEsNumerico(devolucion.getNroTicket())) {
							utilAudit.errorMessageLog(beanLog, Globales.ModuloTransacciones.NUMERO_TICKET_NO_NUMERICO,
									UtilLogLevel.INFO.name(),
									"El Nro de ticket debe ser numérico. Error en línea: " + errorRow);
						}
						break;

					case 5:
						devolucion.setIdMoneda(nextCell.getStringCellValue());
						if (devolucion.getIdMoneda().equals(Globales.TIPO_MONEDA_SOLES_KEY)) {
							break;
						} else if (devolucion.getIdMoneda().equals(Globales.TIPO_MONEDA_DOLARES_KEY)) {
							break;
						}

						utilAudit.errorMessageLog(beanLog, Globales.ModuloTransacciones.TIPO_MONEDA_INCORRECTO,
								UtilLogLevel.INFO.name(), "Tipo de moneda incorrecto. Error en línea: " + errorRow);
					case 6:
						devolucion.setImporteConsumo(nextCell.getStringCellValue());
						if (!UtilString.validarEsNumericoDecimal(devolucion.getImporteConsumo())) {
							utilAudit.errorMessageLog(beanLog, Globales.ModuloTransacciones.IMPORTE_CONSUMO_NO_NUMERICO,
									UtilLogLevel.INFO.name(),
									"El Importe de Consumo no es numérico. Error en línea: " + errorRow);
						}
						break;

					case 7:
						devolucion.setImporteDevolucion(nextCell.getStringCellValue());
						if (!UtilString.validarEsNumericoDecimal(devolucion.getImporteDevolucion())) {
							utilAudit.errorMessageLog(beanLog,
									Globales.ModuloTransacciones.IMPORTE_DEVOLUCION_NO_NUMERICO,
									UtilLogLevel.INFO.name(),
									"El Importe de Devolución no es numérico. Error en línea: " + errorRow);
						}
						break;

					case 8:
						devolucion.setTipoDevolucion(nextCell.getStringCellValue());
						if (devolucion.getTipoDevolucion().equals(Globales.TIPO_DEVOLUCION_TOTAL_KEY)) {
							break;
						} else if (devolucion.getTipoDevolucion().equals(Globales.TIPO_DEVOLUCION_PARCIAL_KEY)) {
							break;
						}
						utilAudit.errorMessageLog(beanLog, Globales.ModuloTransacciones.TIPO_DEVOLUCION_INCORRECTO,
								UtilLogLevel.INFO.name(),
								"El Tipo de Devolución no es correcto. Error en línea: " + errorRow);

					case 9:
						devolucion.setReferencia(nextCell.getStringCellValue());
						if (devolucion.getReferencia().length() > 100) {
							utilAudit.errorMessageLog(beanLog,
									Globales.ModuloTransacciones.REFERENCIA_DEVOLUCION_lONGITUD,
									UtilLogLevel.INFO.name(), "La referencia excedió la longitud máxima ("
											+ devolucion.getReferencia().length() + "). Error en línea: " + errorRow);
						}
						break;

					case 10:
						devolucion.setObservaciones(nextCell.getStringCellValue());
						if (devolucion.getObservaciones().length() > 100) {
							utilAudit.errorMessageLog(beanLog,
									Globales.ModuloTransacciones.OBSERVACION_DEVOLUCION_lONGITUD,
									UtilLogLevel.INFO.name(),
									"La referencia excedió la longitud máxima ("
											+ devolucion.getObservaciones().length() + "). Error en línea: "
											+ errorRow);
						}
						break;
						
					}
				}

				if (devolucion.validarDataVacia(devolucion))
					listaDevolucion.add(devolucion);
			}

		} catch (FileNotFoundException e) {
			utilAudit.errorMessageLog(beanLog, Globales.PROBLEMA_AL_PROCESAR_EL_ARCHIVO, UtilLogLevel.INFO.name(),
					"Error en el proceso: " + e.getMessage());
		} catch (IOException e) {
			utilAudit.errorMessageLog(beanLog, Globales.PROBLEMA_AL_PROCESAR_EL_ARCHIVO, UtilLogLevel.INFO.name(),
					"Error en el proceso: " + e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				wb.close();
				fis.close();
			} catch (IOException e) {
				utilAudit.errorMessageLog(beanLog, Globales.PROBLEMA_AL_PROCESAR_EL_ARCHIVO, UtilLogLevel.INFO.name(),
						"Error en el proceso: " + e.getMessage());
			}
		}

		if (listaDevolucion.size() == 0) {
			utilAudit.errorMessageLog(beanLog, Globales.ARCHIVO_SIN_REGISTROS, UtilLogLevel.INFO.name(),
					"Archivo sin registros.");
		}
		return listaDevolucion;
	}

	private boolean validarIntegridadData(BeanLog beanLog, DevolucionDetalle devolucion) {

		boolean resp = false;

		if (!UtilString.validarEsNumerico(devolucion.getNumeroTarjeta())) {
			utilAudit.errorMessageLog(beanLog, Globales.ModuloTransacciones.NUMERO_TARJETA_NO_NUMERICO,
					UtilLogLevel.INFO.name(), "El Nro de Tarjeta debe ser numérico");
		}

		if (!UtilDate.validarEsFecha(devolucion.getFechaConsumo(), Globales.FORMATO_FECHA_YYYYMMDD)) {
			utilAudit.errorMessageLog(beanLog, Globales.ModuloTransacciones.FORMATO_FECHA_INCORRECTO,
					UtilLogLevel.INFO.name(), "El formato de la fecha debe ser: " + Globales.FORMATO_FECHA_YYYYMMDD);
		}

		if (!UtilString.validarEsNumerico(devolucion.getCodigoAutorizacion())) {
			utilAudit.errorMessageLog(beanLog, Globales.ModuloTransacciones.CODIGO_AUTORIZACION_NO_NUMERICO,
					UtilLogLevel.INFO.name(), "El Código de Autorización debe ser numérico.");
		}

		if (!UtilString.validarEsNumerico(devolucion.getNroTicket())) {
			utilAudit.errorMessageLog(beanLog, Globales.ModuloTransacciones.NUMERO_TICKET_NO_NUMERICO,
					UtilLogLevel.INFO.name(), "El Nro de ticket debe ser numérico.");
		}

		switch (devolucion.getIdMoneda()) {
		case "604":
			break;
		case "840":
			break;
		default:
			utilAudit.errorMessageLog(beanLog, Globales.ModuloTransacciones.TIPO_MONEDA_INCORRECTO,
					UtilLogLevel.INFO.name(), "Tipo de moneda incorrecto.");
		}

		if (!UtilString.validarEsNumericoDecimal(devolucion.getImporteConsumo())) {
			utilAudit.errorMessageLog(beanLog, Globales.ModuloTransacciones.IMPORTE_CONSUMO_NO_NUMERICO,
					UtilLogLevel.INFO.name(), "El Importe de Consumo no es numérico.");
		}

		if (!UtilString.validarEsNumericoDecimal(devolucion.getImporteDevolucion())) {
			utilAudit.errorMessageLog(beanLog, Globales.ModuloTransacciones.IMPORTE_DEVOLUCION_NO_NUMERICO,
					UtilLogLevel.INFO.name(), "El Importe de Devolución no es numérico. Error en línea: ");
		}

		switch (devolucion.getTipoDevolucion()) {
		case "001": 
			break;
		case "002":
			break;
		default:
			utilAudit.errorMessageLog(beanLog, Globales.ModuloTransacciones.TIPO_DEVOLUCION_INCORRECTO,
					UtilLogLevel.INFO.name(), "El Tipo de Devolución no es correcto.");
		}

		if (devolucion.getReferencia().length() > 100) {
			utilAudit.errorMessageLog(beanLog, Globales.ModuloTransacciones.REFERENCIA_DEVOLUCION_lONGITUD,
					UtilLogLevel.INFO.name(),
					"La referencia excedió la longitud máxima (" + devolucion.getReferencia().length() + ").");
		}

		if (devolucion.getObservaciones().length() > 100) {
			utilAudit.errorMessageLog(beanLog, Globales.ModuloTransacciones.OBSERVACION_DEVOLUCION_lONGITUD,
					UtilLogLevel.INFO.name(),
					"La referencia excedió la longitud máxima (" + devolucion.getObservaciones().length() + ").");
		}

		resp = true;

		return resp;

	}

	@Async
	private void rollBackDevolucion(String idTransaccion, int codDvl) {
		transaccionDao.rollBackRegistroDevolucion(idTransaccion, codDvl);
	}

}
