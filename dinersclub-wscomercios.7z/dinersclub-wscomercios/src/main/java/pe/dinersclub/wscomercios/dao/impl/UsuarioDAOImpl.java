package pe.dinersclub.wscomercios.dao.impl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import pe.dinersclub.wscomercios.dao.UsuarioDAO;
import pe.dinersclub.wscomercios.domain.usuario.UsuarioDatosResponse;
import pe.dinersclub.wscomercios.domain.usuario.UsuarioOpcionResponse;
import pe.dinersclub.wscomercios.dto.usuario.Rol;
import pe.dinersclub.wscomercios.dto.usuario.Usuario;
import pe.dinersclub.wscomercios.log.BeanLog;
import pe.dinersclub.wscomercios.log.UtilLog;
import pe.dinersclub.wscomercios.log.UtilLogLevel;
import pe.dinersclub.wscomercios.util.ConnectionDB;
import pe.dinersclub.wscomercios.util.Globales;

@Repository
public class UsuarioDAOImpl implements UsuarioDAO {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private UtilLog utilLog;

	@Override
	public Usuario findByUsername(String username, String identificador) {

		BeanLog beanLog = new BeanLog();
		beanLog.setIdentificador(identificador);
		beanLog.setMetodo(new Object(){}.getClass().getEnclosingMethod().getName());

		Usuario usuario = null;
		List<Rol> roles = new ArrayList<Rol>();
		Connection conn = null;
		CallableStatement cs = null;
		ResultSet rs = null;
		StringBuilder sbSQLUsuario = new StringBuilder();
		StringBuilder sbSQLRoles = new StringBuilder();

		try {
			
			sbSQLUsuario.append(Globales.CALL_SP).append(Globales.ESQUEMA_PROC);
			sbSQLUsuario.append(".").append(Globales.SP_WSC_OBTENERUSUARIOXUSERNAME).append("(?)}");


			conn = ConnectionDB.getConnectionServerAS400();
			cs = conn.prepareCall(sbSQLUsuario.toString());

			cs.setString(1, username);
			cs.execute();
			rs = cs.getResultSet();

			if (rs.next()) {
				usuario = new Usuario();
				usuario.setIdUsuario(rs.getLong(1));
				usuario.setRucEmpresa(rs.getString(2).trim());
				usuario.setUsername(rs.getString(3).trim());
				usuario.setPassword(rs.getString(4).trim());
				usuario.setEstado((rs.getInt(5) == 1) ? true : false);
				usuario.setAccesoCambioPassword((rs.getInt(6) == 1) ? true : false);
				usuario.setNoBloqueado((rs.getInt(7) == 1) ? true : false);
				usuario.setUsuNombres(rs.getString(8).trim());
				usuario.setUsuApellidos(rs.getString(9).trim());
				usuario.setEmail(rs.getString(10).trim());
				usuario.setCantAccesos(rs.getInt(11));
			}

		} catch (Exception ex) {
			beanLog.setDescripcionMensaje(ex.getMessage());
			beanLog.setCausa(ex.getCause() != null ? ex.getCause().getMessage() : "");
			beanLog.setTipoMensaje(UtilLogLevel.ERROR.name());
			utilLog.printInfo(logger, beanLog);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (cs != null)
					cs.close();
			} catch (SQLException ex) {
			}
		}

		if (usuario != null) {
			try {
				
				sbSQLRoles.append(Globales.CALL_SP).append(Globales.ESQUEMA_PROC);
				sbSQLRoles.append(".").append(Globales.SP_WSC_OBTENERROLESDEUSUARIO).append("(?)}");
				
				cs = conn.prepareCall(sbSQLRoles.toString());
				cs.setLong(1, usuario.getIdUsuario());
				cs.execute();
				rs = cs.getResultSet();

				Rol rol = null;
				while (rs.next()) {
					rol = new Rol();
					rol.setIdRol(rs.getInt(1));
					rol.setNombreRol(rs.getString(2).trim());
					roles.add(rol);
				}

				usuario.setRoles(roles);
			} catch (Exception ex) {
				beanLog.setDescripcionMensaje(ex.getMessage());
				beanLog.setCausa(ex.getCause() != null ? ex.getCause().getMessage() : "");
				beanLog.setTipoMensaje(UtilLogLevel.ERROR.name());
				utilLog.printInfo(logger, beanLog);
			} finally {
				try {
					if (rs != null)
						rs.close();
					if (cs != null)
						cs.close();
					if (conn != null)
						conn.close();
				} catch (SQLException ex) {
				}
			}
		} else {
			try {
				if (conn != null)
					conn.close();
			} catch (SQLException ex) {
			}
		}

		return usuario;
	}


	@Override
	public Usuario findByIdUsuario(String idUsuario, String identificador) {

		BeanLog beanLog = new BeanLog();
		beanLog.setIdentificador(identificador);
		beanLog.setMetodo(new Object(){}.getClass().getEnclosingMethod().getName());
		
		Usuario usuario = null;
		Connection conn = null;
		CallableStatement cs = null;
		ResultSet rs = null;
		StringBuilder sbSQLUsuario = new StringBuilder();

		try {
			
			sbSQLUsuario.append(Globales.CALL_SP).append(Globales.ESQUEMA_PROC);
			sbSQLUsuario.append(".").append(Globales.SP_WSC_OBTENERUSUARIOXID).append("(?)}");
			
			conn = ConnectionDB.getConnectionServerAS400();
			cs = conn.prepareCall(sbSQLUsuario.toString());

			cs.setString(1, idUsuario);
			cs.execute();
			rs = cs.getResultSet();

			while (rs.next()) {
				usuario = new Usuario();
				usuario.setIdUsuario(rs.getLong(1));
				usuario.setUsername(rs.getString(2).trim());
				usuario.setUsuNombres(rs.getString(3).trim());
				usuario.setUsuApellidos(rs.getString(4).trim());
				usuario.setRucEmpresa(rs.getString(5).trim());
				usuario.setEstado((rs.getInt(6) == 1) ? true : false);
				usuario.setAccesoCambioPassword((rs.getInt(7) == 1) ? true : false);
				usuario.setEmail(rs.getString(8).trim());
				usuario.setNoBloqueado((rs.getInt(9) == 1) ? true : false);
				usuario.setCantAccesos(rs.getInt(10));
			}

		} catch (Exception ex) {
			beanLog.setDescripcionMensaje(ex.getMessage());
			beanLog.setCausa(ex.getCause() != null ? ex.getCause().getMessage() : "");
			beanLog.setTipoMensaje(UtilLogLevel.ERROR.name());
			utilLog.printInfo(logger, beanLog);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (cs != null)
					cs.close();
				if (conn != null)
					conn.close();
			} catch (SQLException ex) {
			}
		}

		return usuario;
	}

	@Override
	public Boolean actualizarPassword(Long idUsuario, String password, String identificador) {

		BeanLog beanLog = new BeanLog();
		beanLog.setIdentificador(identificador);
		beanLog.setMetodo(new Object(){}.getClass().getEnclosingMethod().getName());
		
		boolean respuesta = false;
		Connection conn = null;
		CallableStatement cs = null;
		ResultSet rs = null;
		StringBuilder sbSQL = new StringBuilder();

		try {
			
			sbSQL.append(Globales.CALL_SP).append(Globales.ESQUEMA_PROC);
			sbSQL.append(".").append(Globales.SP_WSC_ACTUALIZARPASSWORD).append("(?,?)}");
			
			conn = ConnectionDB.getConnectionServerAS400();
			cs = conn.prepareCall(sbSQL.toString());

			cs.setLong(1, idUsuario);
			cs.setString(2, password);
			cs.executeUpdate();
			respuesta = true;

		} catch (Exception ex) {
			beanLog.setDescripcionMensaje(ex.getMessage());
			beanLog.setCausa(ex.getCause() != null ? ex.getCause().getMessage() : "");
			beanLog.setTipoMensaje(UtilLogLevel.ERROR.name());
			utilLog.printInfo(logger, beanLog);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (cs != null)
					cs.close();
				if (conn != null)
					conn.close();
			} catch (SQLException ex) {
			}
		}

		return respuesta;
	}
	
	@Override
	public Boolean actualizarFlgAcceso(Long idUsuario, Integer flgAcceso, String identificador) {

		BeanLog beanLog = new BeanLog();
		beanLog.setIdentificador(identificador);
		beanLog.setMetodo(new Object(){}.getClass().getEnclosingMethod().getName());
		
		boolean respuesta = false;
		Connection conn = null;
		CallableStatement cs = null;
		ResultSet rs = null;
		StringBuilder sbSQL = new StringBuilder();

		try {
			
			sbSQL.append(Globales.CALL_SP).append(Globales.ESQUEMA_PROC);
			sbSQL.append(".").append(Globales.SP_WSC_ACTUALIZARFLGACCESOUSUARIO).append("(?,?)}");
			
			conn = ConnectionDB.getConnectionServerAS400();
			cs = conn.prepareCall(sbSQL.toString());

			cs.setLong(1, idUsuario);
			cs.setInt(2, flgAcceso);
			cs.executeUpdate();
			respuesta = true;

		} catch (Exception ex) {
			beanLog.setDescripcionMensaje(ex.getMessage());
			beanLog.setCausa(ex.getCause() != null ? ex.getCause().getMessage() : "");
			beanLog.setTipoMensaje(UtilLogLevel.ERROR.name());
			utilLog.printInfo(logger, beanLog);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (cs != null)
					cs.close();
				if (conn != null)
					conn.close();
			} catch (SQLException ex) {
			}
		}

		return respuesta;
	}
	
	@Override
	public Boolean actualizarFlgEstado(Long idUsuario, Integer flgEstado, String identificador) {

		BeanLog beanLog = new BeanLog();
		beanLog.setIdentificador(identificador);
		beanLog.setMetodo(new Object(){}.getClass().getEnclosingMethod().getName());
		
		boolean respuesta = false;
		Connection conn = null;
		CallableStatement cs = null;
		ResultSet rs = null;
		StringBuilder sbSQL = new StringBuilder();

		try {
			
			sbSQL.append(Globales.CALL_SP).append(Globales.ESQUEMA_PROC);
			sbSQL.append(".").append(Globales.SP_WSC_ACTUALIZARFLGESTADOUSUARIO).append("(?,?)}");
			
			conn = ConnectionDB.getConnectionServerAS400();
			cs = conn.prepareCall(sbSQL.toString());

			cs.setLong(1, idUsuario);
			cs.setInt(2, flgEstado);
			cs.executeUpdate();
			respuesta = true;

		} catch (Exception ex) {
			beanLog.setDescripcionMensaje(ex.getMessage());
			beanLog.setCausa(ex.getCause() != null ? ex.getCause().getMessage() : "");
			beanLog.setTipoMensaje(UtilLogLevel.ERROR.name());
			utilLog.printInfo(logger, beanLog);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (cs != null)
					cs.close();
				if (conn != null)
					conn.close();
			} catch (SQLException ex) {
			}
		}

		return respuesta;
	}
	
	@Override
	public Boolean actualizarFlgBloqueo(Long idUsuario, Integer flgBloqueo, String identificador) {

		BeanLog beanLog = new BeanLog();
		beanLog.setIdentificador(identificador);
		beanLog.setMetodo(new Object(){}.getClass().getEnclosingMethod().getName());
		
		boolean respuesta = false;
		Connection conn = null;
		CallableStatement cs = null;
		ResultSet rs = null;
		StringBuilder sbSQL = new StringBuilder();

		try {
			
			sbSQL.append(Globales.CALL_SP).append(Globales.ESQUEMA_PROC);
			sbSQL.append(".").append(Globales.SP_WSC_ACTUALIZARFLGBLOQUEOUSUARIO).append("(?,?)}");
			
			conn = ConnectionDB.getConnectionServerAS400();
			cs = conn.prepareCall(sbSQL.toString());

			cs.setLong(1, idUsuario);
			cs.setInt(2, flgBloqueo);
			cs.executeUpdate();
			respuesta = true;

		} catch (Exception ex) {
			beanLog.setDescripcionMensaje(ex.getMessage());
			beanLog.setCausa(ex.getCause() != null ? ex.getCause().getMessage() : "");
			beanLog.setTipoMensaje(UtilLogLevel.ERROR.name());
			utilLog.printInfo(logger, beanLog);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (cs != null)
					cs.close();
				if (conn != null)
					conn.close();
			} catch (SQLException ex) {
			}
		}

		return respuesta;
	}
	
	@Override
	public Boolean actualizarAccesosFallidos(Long idUsuario, Integer cantidadIntentosFallidos, String identificador) {

		BeanLog beanLog = new BeanLog();
		beanLog.setIdentificador(identificador);
		beanLog.setMetodo(new Object(){}.getClass().getEnclosingMethod().getName());
		
		boolean respuesta = false;
		Connection conn = null;
		CallableStatement cs = null;
		ResultSet rs = null;
		StringBuilder sbSQL = new StringBuilder();

		try {
			
			sbSQL.append(Globales.CALL_SP).append(Globales.ESQUEMA_PROC);
			sbSQL.append(".").append(Globales.SP_WSC_ACTUALIZARACCESOSFALLIDOS).append("(?,?)}");
			
			conn = ConnectionDB.getConnectionServerAS400();
			cs = conn.prepareCall(sbSQL.toString());

			cs.setLong(1, idUsuario);
			cs.setInt(2, cantidadIntentosFallidos);
			cs.executeUpdate();
			respuesta = true;

		} catch (Exception ex) {
			beanLog.setDescripcionMensaje(ex.getMessage());
			beanLog.setCausa(ex.getCause() != null ? ex.getCause().getMessage() : "");
			beanLog.setTipoMensaje(UtilLogLevel.ERROR.name());
			utilLog.printInfo(logger, beanLog);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (cs != null)
					cs.close();
				if (conn != null)
					conn.close();
			} catch (SQLException ex) {
			}
		}

		return respuesta;
	}

	@Override
	public List<UsuarioOpcionResponse> obtenerOpcionesDeUsuario(String identificador, String idUsuario) {

		BeanLog beanLog = new BeanLog();
		beanLog.setIdentificador(identificador);
		beanLog.setMetodo(new Object(){}.getClass().getEnclosingMethod().getName());

		List<UsuarioOpcionResponse> opcionesDeMenu = new ArrayList<UsuarioOpcionResponse>();
		UsuarioOpcionResponse opcion = null;

		Connection conn = null;
		CallableStatement cs = null;
		ResultSet rs = null;
		StringBuilder sbSQL = new StringBuilder();

		try {
			sbSQL.append(Globales.CALL_SP).append(Globales.ESQUEMA_PROC);
			sbSQL.append(".").append(Globales.SP_WSC_OBTENEROPCIONESDEMENU).append("(?)}");

			conn = ConnectionDB.getConnectionServerAS400();
			cs = conn.prepareCall(sbSQL.toString());

			cs.setString(1, idUsuario);
			cs.execute();

			rs = cs.getResultSet();

			while (rs.next()) {
				opcion = new UsuarioOpcionResponse();
				opcion.setCodigo(rs.getString(1).trim());
				opcion.setNombreOpcion(rs.getString(2).trim());
				opcion.setIsConsulta((rs.getString(3).trim().equals("1")) ? true : false);
				opcion.setIsTransaccional((rs.getString(4).trim().equals("1")) ? true : false);
				opcionesDeMenu.add(opcion);
			}

		} catch (Exception ex) {
			beanLog.setDescripcionMensaje(ex.getMessage());
			beanLog.setCausa(ex.getCause() != null ? ex.getCause().getMessage() : "");
			beanLog.setTipoMensaje(UtilLogLevel.ERROR.name());
			utilLog.printInfo(logger, beanLog);

		} finally {
			try {
				if (rs != null)
					rs.close();
				if (cs != null)
					cs.close();
				if (conn != null)
					conn.close();
			} catch (SQLException ex) {
			}
		}

		return opcionesDeMenu;

	}

	@Override
	public UsuarioDatosResponse obtenerNombresUsuarioYEmpresa(String identificador, String idUsuario) {

		BeanLog beanLog = new BeanLog();
		beanLog.setIdentificador(identificador);
		beanLog.setMetodo(new Object(){}.getClass().getEnclosingMethod().getName());

		UsuarioDatosResponse nombresUsuarioEmpresa = null;

		Connection conn = null;
		CallableStatement cs = null;
		ResultSet rs = null;
		StringBuilder sbSQL = new StringBuilder();

		try {
			sbSQL.append(Globales.CALL_SP).append(Globales.ESQUEMA_PROC);
			sbSQL.append(".").append(Globales.SP_WSC_OBTENERDATOSUSUARIOEMPRESA).append("(?)}");

			conn = ConnectionDB.getConnectionServerAS400();
			cs = conn.prepareCall(sbSQL.toString());

			cs.setString(1, idUsuario);
			cs.execute();

			rs = cs.getResultSet();

			while (rs.next()) {
				nombresUsuarioEmpresa = new UsuarioDatosResponse();
				nombresUsuarioEmpresa.setNombresUsuario(rs.getString(1).trim());
				nombresUsuarioEmpresa.setRucEmpresa(rs.getLong(2));
				nombresUsuarioEmpresa.setRazonSocial(rs.getString(3).trim());
			}

		} catch (Exception ex) {
			beanLog.setDescripcionMensaje(ex.getMessage());
			beanLog.setCausa(ex.getCause() != null ? ex.getCause().getMessage() : "");
			beanLog.setTipoMensaje(UtilLogLevel.ERROR.name());
			utilLog.printInfo(logger, beanLog);

		} finally {
			try {
				if (rs != null)
					rs.close();
				if (cs != null)
					cs.close();
				if (conn != null)
					conn.close();
			} catch (SQLException ex) {
			}
		}

		return nombresUsuarioEmpresa;

	}

	@Override
	public Map<Long, String> obtenerComerciosPorUsuario(String identificador, String idUsuario) {

		BeanLog beanLog = new BeanLog();
		beanLog.setIdentificador(identificador);
		beanLog.setMetodo(new Object(){}.getClass().getEnclosingMethod().getName());

		Map<Long, String> comercios = new HashMap<Long, String>();

		Connection conn = null;
		CallableStatement cs = null;
		ResultSet rs = null;
		StringBuilder sbSQL = new StringBuilder();

		try {
			sbSQL.append(Globales.CALL_SP).append(Globales.ESQUEMA_PROC);
			sbSQL.append(".").append(Globales.SP_WSC_OBTENERCOMERCIOSXUSUARIO).append("(?)}");

			conn = ConnectionDB.getConnectionServerAS400();
			cs = conn.prepareCall(sbSQL.toString());

			cs.setString(1, idUsuario);
			cs.execute();

			rs = cs.getResultSet();

			while (rs.next()) {
				comercios.put(rs.getLong(1), rs.getString(2).trim());
			}

		} catch (Exception ex) {
			beanLog.setDescripcionMensaje(ex.getMessage());
			beanLog.setCausa(ex.getCause() != null ? ex.getCause().getMessage() : "");
			beanLog.setTipoMensaje(UtilLogLevel.ERROR.name());
			utilLog.printInfo(logger, beanLog);

		} finally {
			try {
				if (rs != null)
					rs.close();
				if (cs != null)
					cs.close();
				if (conn != null)
					conn.close();
			} catch (SQLException ex) {
			}
		}

		return comercios;

	}
}
