package pe.dinersclub.wscomercios.security.service;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import pe.dinersclub.wscomercios.dao.UsuarioDAO;
import pe.dinersclub.wscomercios.dto.usuario.Usuario;
import pe.dinersclub.wscomercios.log.BeanLog;
import pe.dinersclub.wscomercios.log.UtilLog;
import pe.dinersclub.wscomercios.log.UtilLogLevel;
import pe.dinersclub.wscomercios.security.bean.UsuarioAuthentication;
import pe.dinersclub.wscomercios.util.Globales;
import pe.dinersclub.wscomercios.util.UtilString;

@Service
public class JpaUserDetailService implements UserDetailsService {

	@Autowired
	private UsuarioDAO usuarioDaoInterface;

	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private UtilLog utilLog;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {

		BeanLog beanLog = new BeanLog();
		beanLog.setIdentificador(UtilString.obtenerIdentificadorUnico());
		beanLog.setMetodo(new Object() {
		}.getClass().getEnclosingMethod().getName());

		Usuario usuario = usuarioDaoInterface.findByUsername(username.toUpperCase(), beanLog.getIdentificador());

		if (usuario == null) {
			throw new UsernameNotFoundException(String.format("Usuario no existe", username));
		}

		List<GrantedAuthority> roles = new ArrayList<>();

		usuario.getRoles().forEach(rol -> {
			roles.add(new SimpleGrantedAuthority(rol.getNombreRol()));
		});

		if (roles.isEmpty()) {
			
			beanLog.setCodigoMensaje(Globales.USUARIO_SIN_ROLES_ASIGNADOS);
			beanLog.setDescripcionMensaje("USUARIO_SIN_ROLES_ASIGNADOS. Usuario: "+ username);
			beanLog.setTipoMensaje(UtilLogLevel.INFO.name());
			utilLog.printInfo(logger, beanLog);
			
			//throw new ModeloNotFountException("Error en el Login: usuario '" + username + "' no tiene roles asignados!",null);
		}

		//logger.info(roles.toString());
		UserDetails ud = new UsuarioAuthentication(usuario.getIdUsuario(), usuario.getRucEmpresa(),
				usuario.getUsername(), usuario.getPassword(), usuario.isEstado(), usuario.isAccesoCambioPassword(),
				true, true, usuario.isNoBloqueado(), roles);

		return ud;
	}

}
