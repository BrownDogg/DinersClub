package pe.dinersclub.wscomercios.dao;

import java.util.List;
import java.util.Map;

import pe.dinersclub.wscomercios.domain.usuario.UsuarioDatosResponse;
import pe.dinersclub.wscomercios.domain.usuario.UsuarioOpcionResponse;
import pe.dinersclub.wscomercios.dto.usuario.Usuario;

public interface UsuarioDAO {

	public Usuario findByUsername(String username, String identificador);

	public Usuario findByIdUsuario(String idUsuario, String identificador);

	public Boolean actualizarPassword(Long idUsuario, String password, String identificador);
	
	public Boolean actualizarFlgAcceso(Long idUsuario, Integer flgAcceso, String identificador);
	
	public Boolean actualizarFlgEstado(Long idUsuario, Integer flgAcceso, String identificador);
	
	public Boolean actualizarFlgBloqueo(Long idUsuario, Integer flgAcceso, String identificador);
	
	public Boolean actualizarAccesosFallidos(Long idUsuario, Integer cantidad, String identificador);
	
	public List<UsuarioOpcionResponse> obtenerOpcionesDeUsuario(String identificador, String idUsuario);
	
	public UsuarioDatosResponse obtenerNombresUsuarioYEmpresa(String identificador, String idUsuario);
	
	public Map<Long,String> obtenerComerciosPorUsuario(String identificador, String idUsuario);
	

	
}
