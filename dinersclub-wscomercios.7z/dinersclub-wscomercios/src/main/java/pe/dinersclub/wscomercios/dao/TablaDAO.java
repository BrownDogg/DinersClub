package pe.dinersclub.wscomercios.dao;

import java.util.List;

import pe.dinersclub.wscomercios.dto.filtros.Tabla;

public interface TablaDAO {

	public List<Tabla> obtenerFiltro(String identificador, String codigoTabla);
	
	public Tabla obtenerDatoPorCodigoAndItem(String identificador, String codigoTabla, String idItemTabla);
	
	public Tabla obtenerDatoPorCodigoAndItemDCP(String identificador, String codigoTabla, String idItemDCP);
	
}
