package pe.dinersclub.wscomercios.util;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.UUID;

public class UtilString {

	public static String rellenaIzquierda(String cadena, char relleno, int longitud) {
		if (cadena == null) {
			return null;
		}
		if (cadena.length() == longitud) {
			return cadena;
		}
		if (cadena.length() > longitud) {
			return cadena.substring(0, longitud);
		}
		StringBuffer resultado = new StringBuffer();
		int pad = longitud - cadena.length();
		for (int i = 1; i <= pad; i++) {
			resultado.append(relleno);
		}

		resultado.append(cadena);
		return resultado.toString();
	}

	public static String rellenaDerecha(String cadena, char relleno, int longitud) {
		if (cadena == null) {
			return null;
		}
		if (cadena.length() == longitud) {
			return cadena;
		}
		if (cadena.length() > longitud) {
			return cadena.substring(0, longitud);
		}
		StringBuffer resultado = new StringBuffer();
		resultado.append(cadena);
		int pad = longitud - cadena.length();
		for (int i = 1; i <= pad; i++) {
			resultado.append(relleno);
		}

		return resultado.toString();
	}

	public static String generaEspaciosBlancos(Integer i) {
		StringBuilder sb = new StringBuilder();
		for (int j = 0; j < i; j++) {
			sb.append(" ");
		}
		return sb.toString();
	}

	public static String parseNumeroDocumento(String numeroDocumento) {
		return rellenaIzquierda(numeroDocumento, '0', 12);
	}

	public static boolean validarEsAlfanumerico(String cadena) {
		return cadena.matches("[A-Za-z0-9]+");
	}

	public static boolean validarPassword(String cadena) {
		return cadena.matches("^(?=.*[A-Z].*[A-Z])(?=.*[!@#$&*])(?=.*[0-9].*[0-9])(?=.*[a-z].*[a-z].*[a-z]).{8}$");
	}

	public static boolean validarEsNumerico(String cadena) {
		return cadena.matches("[0-9]+");
	}

	public static boolean validarEsNumericoDecimal(String valor) {
		try {
			Double.parseDouble(valor);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	public static boolean validarEsCorreoElectronico(String cadena) {
		return cadena.matches("[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}");
	}

	public static boolean validarEsNuloOVacio(String cadena) {
		if (cadena == null || cadena.isEmpty()) {
			return true;
		} else {
			return false;
		}
	}

	public static String convertirANombreCompleto(final String primerNombre, final String segundoNombre,
			final String apellidoPaterno, final String apellidoMaterno) {
		return primerNombre + (UtilString.validarEsNuloOVacio(segundoNombre) ? "" : " " + segundoNombre) + " "
				+ apellidoPaterno + (UtilString.validarEsNuloOVacio(apellidoPaterno) ? "" : " " + apellidoMaterno);
	}

	public static String formatoNumeroTarjetaOfuscado(String ultDigitosTarjeta) {
		String formatoAsterisco = "**** ****** ";
		if (ultDigitosTarjeta != null) {
			if (ultDigitosTarjeta.length() < 5) {
				return formatoAsterisco + ultDigitosTarjeta;
			} else {
				return formatoAsterisco
						+ ultDigitosTarjeta.substring(ultDigitosTarjeta.length() - 4, ultDigitosTarjeta.length());
			}
		} else {
			return formatoAsterisco;
		}
	}

	public static String formatoCorreoOfuscado(String correo) {

		String[] separada = correo.split("@");
		int inicio = 1; // Caracteres al inicio de la cadena que dejamos visibles
		int fin = 3; // Caracteres al final de la cadena que dejamos visibles

		char[] nombre_char = separada[0].toCharArray();
		char[] dominio_char = separada[1].toCharArray();

		if (nombre_char.length > inicio + fin) {
			for (int i = inicio; i < nombre_char.length - fin; i++) {
				nombre_char[i] = '*';
			}
		} else {
			for (int j = inicio; j < nombre_char.length - 1; j++) {
				nombre_char[j] = '*';
			}
		}

		if (dominio_char.length > inicio + fin) {
			for (int i = inicio + 1; i < dominio_char.length - fin; i++) {
				dominio_char[i] = '*';
			}
		} else {
			for (int j = inicio; j < dominio_char.length - 1; j++) {
				dominio_char[j] = '*';
			}
		}

		String nombre = new String(nombre_char);
		String dominio = new String(dominio_char);

		return nombre + "@" + dominio;
	}

	public static String obtenerNombreArchivoSolicitudDescargaPdf(String idUsuario, String fecha) {
		return idUsuario + "_" + fecha + ".pdf";
	}

	public static String obtenerIdentificadorUnico() {
		return UUID.randomUUID().toString();
	}

	public static String convertDoubletoString(Double numberDouble) {

		String numberString = null;
		try {
			int numberInt = (int) Math.round(numberDouble * 100);
			numberString = String.valueOf(numberInt);
		} catch (NumberFormatException e) {
		} catch (Exception e) {
		}

		return numberString;
	}

	public static String convertBigDecimaltoString(BigDecimal number) {

		String numberString = null;
		try {
			BigDecimal numberEntero = number.multiply(new BigDecimal(100)).setScale(0, RoundingMode.FLOOR);
			numberString = numberEntero.toString();
		} catch (NumberFormatException e) {
		} catch (Exception e) {
		}

		return numberString;
	}

	public static String getDireccionComercio(String via, String direc, String nroDir, String codPostal,
			String departamento, String provincia, String distrito) {

		return via.trim() + " " + direc.trim() + " " + nroDir.trim() + " - " + splitString(departamento.trim(), "  ")
				+ " " + splitString(provincia.trim(), " ") + " " + splitString(distrito.trim(), "  ") + " - "
				+ codPostal.trim();
	}

	public static String splitString(String valor, String simbolo) {
		String result = "";
		try {
			String[] parts = valor.split(simbolo);
			result = parts[0];
		} catch (Exception e) {
			e.printStackTrace();
			return valor;
		}
		return result;
	}
	
	public static String valorMoneda(String idMoneda) {
		if(idMoneda.equals("604")) 	return Globales.TIPO_MONEDA_SOLES_VALUE;
		else if(idMoneda.equals("840")) return Globales.TIPO_MONEDA_DOLARES_VALUE;
		else return null;
	}
	
	public static String valorTipoDevolucion(String tipoDevolucion) {
		
		if(tipoDevolucion.equals(Globales.TIPO_DEVOLUCION_TOTAL_KEY)) return Globales.TIPO_DEVOLUCION_TOTAL_VALUE;
		else if (tipoDevolucion.equals(Globales.TIPO_DEVOLUCION_PARCIAL_KEY)) return Globales.TIPO_DEVOLUCION_PARCIAL_VALUE;
		else return null;
		
	}

}
