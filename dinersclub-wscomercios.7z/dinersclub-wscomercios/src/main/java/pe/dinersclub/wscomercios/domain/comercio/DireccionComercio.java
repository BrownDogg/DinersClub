package pe.dinersclub.wscomercios.domain.comercio;

public class DireccionComercio {
	
	private String tipoDireccion;
	private String via;
	private String direccionComercio;
	private String nroDireccion;
	private String codigoPostal;
	private String departamento;
	private String provincia;
	private String distrito;
	
	public String getTipoDireccion() {
		return tipoDireccion;
	}
	public void setTipoDireccion(String tipoDireccion) {
		this.tipoDireccion = tipoDireccion;
	}
	public String getVia() {
		return via;
	}
	public void setVia(String via) {
		this.via = via;
	}
	public String getDireccionComercio() {
		return direccionComercio;
	}
	public void setDireccionComercio(String direccionComercio) {
		this.direccionComercio = direccionComercio;
	}
	public String getNroDireccion() {
		return nroDireccion;
	}
	public void setNroDireccion(String nroDireccion) {
		this.nroDireccion = nroDireccion;
	}
	public String getCodigoPostal() {
		return codigoPostal;
	}
	public void setCodigoPostal(String codigoPostal) {
		this.codigoPostal = codigoPostal;
	}
	public String getDepartamento() {
		return departamento;
	}
	public void setDepartamento(String departamento) {
		this.departamento = departamento;
	}
	public String getProvincia() {
		return provincia;
	}
	public void setProvincia(String provincia) {
		this.provincia = provincia;
	}
	public String getDistrito() {
		return distrito;
	}
	public void setDistrito(String distrito) {
		this.distrito = distrito;
	}
	@Override
	public String toString() {
		return "DireccionComercio [tipoDireccion=" + tipoDireccion + ", via=" + via + ", direccionComercio="
				+ direccionComercio + ", nroDireccion=" + nroDireccion + ", codigoPostal=" + codigoPostal
				+ ", departamento=" + departamento + ", provincia=" + provincia + ", distrito=" + distrito + "]";
	}
	
}
