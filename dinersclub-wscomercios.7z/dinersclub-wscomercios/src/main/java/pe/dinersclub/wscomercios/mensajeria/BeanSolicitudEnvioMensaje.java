package pe.dinersclub.wscomercios.mensajeria;

import java.util.concurrent.ConcurrentHashMap;

public class BeanSolicitudEnvioMensaje {

	// KEY=NOMBREARCHIVO
	// VALUE=OBJECTO DE SOLICITUD
	private ConcurrentHashMap<String, String> mapSolicitudEnvioMensaje;

	public ConcurrentHashMap<String, String> getMapSolicitudEnvioMensaje() {
		return mapSolicitudEnvioMensaje;
	}

	public void setMapSolicitudEnvioMensaje(ConcurrentHashMap<String, String> mapSolicitudEnvioMensaje) {
		this.mapSolicitudEnvioMensaje = mapSolicitudEnvioMensaje;
	}

	public BeanSolicitudEnvioMensaje() {
		if (mapSolicitudEnvioMensaje == null) {
			mapSolicitudEnvioMensaje = new ConcurrentHashMap<>();
		}
	}
}
