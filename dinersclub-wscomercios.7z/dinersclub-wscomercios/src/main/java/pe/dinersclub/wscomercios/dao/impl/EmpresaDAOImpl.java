package pe.dinersclub.wscomercios.dao.impl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import pe.dinersclub.wscomercios.dao.EmpresaDAO;
import pe.dinersclub.wscomercios.dto.comercio.ComercioDTO;
import pe.dinersclub.wscomercios.dto.empresa.EmpresaDTO;
import pe.dinersclub.wscomercios.log.BeanLog;
import pe.dinersclub.wscomercios.util.ConnectionDB;
import pe.dinersclub.wscomercios.util.Globales;
import pe.dinersclub.wscomercios.util.UtilAuditoria;
import pe.dinersclub.wscomercios.util.UtilDate;

@Repository
public class EmpresaDAOImpl implements EmpresaDAO {

	@Autowired
	private UtilAuditoria utilAudit;

	@Override
	public EmpresaDTO obtenerDatosEmpresa(String idTransaccion, String idEmpresa) {

		BeanLog beanLog = new BeanLog();
		long fechaInicio = UtilDate.getCurrentDateTime();
		String metodo = new Object() {
		}.getClass().getEnclosingMethod().getName();
		beanLog = utilAudit.initLog(idTransaccion, null, metodo, true, "Obtener Datos Empresa DAO");
		EmpresaDTO empresa = null;
		Connection conn = null;
		CallableStatement cs = null;
		ResultSet rs = null;
		StringBuilder sbSQLConsulta = new StringBuilder();

		try {

			sbSQLConsulta.append(Globales.CALL_SP).append(Globales.ESQUEMA_PROC);
			sbSQLConsulta.append(".").append("SP_WSC_OBTENER_EMPRESA").append("(?)}");
			conn = ConnectionDB.getConnectionServerAS400();
			cs = conn.prepareCall(sbSQLConsulta.toString());
			cs.setString(1, idEmpresa);
			cs.execute();
			rs = cs.getResultSet();
			while (rs.next()) {
				empresa = new EmpresaDTO();
				empresa.setRucEmpresa(rs.getString("RUC").trim());
				empresa.setRazonSocial(rs.getString("RZNSOC").trim());
				empresa.setRepLegal(rs.getString("REPLEGAL").trim());
			}

		} catch (Exception e) {
			utilAudit.errorExceptionLog(beanLog, e.getMessage(), e.getCause().getMessage());
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (cs != null)
					cs.close();
				if (conn != null)
					conn.close();
			} catch (SQLException ex) {
			}
			utilAudit.endLog(beanLog, fechaInicio);
		}
		return empresa;
	}

	@Override
	public List<ComercioDTO> listarComercios(String idTransaccion, String idEmpresa) {

		BeanLog beanLog = new BeanLog();
		long fechaInicio = UtilDate.getCurrentDateTime();
		String metodo = new Object() {
		}.getClass().getEnclosingMethod().getName();
		beanLog = utilAudit.initLog(idTransaccion, null, metodo, true, "listarComercio por Empresa DAO");
		ComercioDTO comercio = null;
		List<ComercioDTO> listaComercios = null;
		Connection conn = null;
		CallableStatement cs = null;
		ResultSet rs = null;
		StringBuilder sbSQLConsulta = new StringBuilder();

		try {

			sbSQLConsulta.append(Globales.CALL_SP).append(Globales.ESQUEMA_PROC);
			sbSQLConsulta.append(".").append("SP_WSC_LISTARCOMERCIO_X_EMPRESA").append("(?)}");
			conn = ConnectionDB.getConnectionServerAS400();
			cs = conn.prepareCall(sbSQLConsulta.toString());
			cs.setString(1, idEmpresa);
			cs.execute();
			rs = cs.getResultSet();

			if (rs != null) {
				listaComercios = new LinkedList<>();
				while (rs.next()) {
					comercio = new ComercioDTO();
					comercio.setCodigoComercio(rs.getString("CODCOMERCIO"));
					comercio.setNombreComercio(rs.getString("DESCCOMERCIO").trim());
					comercio.setPaginaWeb(rs.getString("WEBCOMERCIO").trim());
					comercio.setCorreoCorporativo(rs.getString("CORPMAIL").trim());
					comercio.setCorreoComercial(rs.getString("COMERCIALMAIL").trim());
					comercio.setEjecutivoComercio(rs.getString("EJECUTIVO").trim());
					listaComercios.add(comercio);
				}
			}
		} catch (Exception e) {
			utilAudit.errorExceptionLog(beanLog, e.getMessage(), e.getCause().getMessage());
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (cs != null)
					cs.close();
				if (conn != null)
					conn.close();
			} catch (SQLException ex) {
			}
			utilAudit.endLog(beanLog, fechaInicio);
		}
		return listaComercios;
	}

}
