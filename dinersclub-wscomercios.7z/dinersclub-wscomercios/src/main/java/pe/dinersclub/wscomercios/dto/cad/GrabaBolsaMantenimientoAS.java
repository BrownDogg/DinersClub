package pe.dinersclub.wscomercios.dto.cad;

public class GrabaBolsaMantenimientoAS {

	private String tramaGrabaBolsa;
	private String tramaRespuestaBolsa;

	public String getTramaGrabaBolsa() {
		return tramaGrabaBolsa;
	}

	public void setTramaGrabaBolsa(String tramaGrabaBolsa) {
		this.tramaGrabaBolsa = tramaGrabaBolsa;
	}

	public String getTramaRespuestaBolsa() {
		return tramaRespuestaBolsa;
	}

	public void setTramaRespuestaBolsa(String tramaRespuestaBolsa) {
		this.tramaRespuestaBolsa = tramaRespuestaBolsa;
	}

}
