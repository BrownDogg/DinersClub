package pe.dinersclub.wscomercios.domain.liquidaciones;

public class LiquidacionesResponse {

	private String idLiquidacion;
	private String codigoComercio;
	private String nombreComercio;
	private String fechaPago;
	private String monedaPago;
	private Double importeConsumo;
	private Double importeComision;
	private Double igv;
	private Double cargo;
	private Double importeNetoLiquidacion;
	private String documentoAautorizado;
	private String formaPago;
	private String banco;
	private String tipoCuenta;
	private String numeroCuentaBancaria;
	private String numeroCheque;

	public Double getImporteConsumo() {
		return importeConsumo;
	}

	public void setImporteConsumo(Double importeConsumo) {
		this.importeConsumo = importeConsumo;
	}

	public Double getImporteComision() {
		return importeComision;
	}

	public void setImporteComision(Double importeComision) {
		this.importeComision = importeComision;
	}

	public Double getIgv() {
		return igv;
	}

	public void setIgv(Double igv) {
		this.igv = igv;
	}

	public Double getCargo() {
		return cargo;
	}

	public void setCargo(Double cargo) {
		this.cargo = cargo;
	}

	public Double getImporteNetoLiquidacion() {
		return importeNetoLiquidacion;
	}

	public void setImporteNetoLiquidacion(Double importeNetoLiquidacion) {
		this.importeNetoLiquidacion = importeNetoLiquidacion;
	}

	public String getIdLiquidacion() {
		return idLiquidacion;
	}

	public void setIdLiquidacion(String idLiquidacion) {
		this.idLiquidacion = idLiquidacion;
	}

	public String getCodigoComercio() {
		return codigoComercio;
	}

	public void setCodigoComercio(String codigoComercio) {
		this.codigoComercio = codigoComercio;
	}

	public String getNombreComercio() {
		return nombreComercio;
	}

	public void setNombreComercio(String nombreComercio) {
		this.nombreComercio = nombreComercio;
	}

	public String getFechaPago() {
		return fechaPago;
	}

	public void setFechaPago(String fechaPago) {
		this.fechaPago = fechaPago;
	}

	public String getMonedaPago() {
		return monedaPago;
	}

	public void setMonedaPago(String monedaPago) {
		this.monedaPago = monedaPago;
	}

	public String getDocumentoAautorizado() {
		return documentoAautorizado;
	}

	public void setDocumentoAautorizado(String documentoAautorizado) {
		this.documentoAautorizado = documentoAautorizado;
	}

	public String getFormaPago() {
		return formaPago;
	}

	public void setFormaPago(String formaPago) {
		this.formaPago = formaPago;
	}

	public String getBanco() {
		return banco;
	}

	public void setBanco(String banco) {
		this.banco = banco;
	}

	public String getTipoCuenta() {
		return tipoCuenta;
	}

	public void setTipoCuenta(String tipoCuenta) {
		this.tipoCuenta = tipoCuenta;
	}

	public String getNumeroCuentaBancaria() {
		return numeroCuentaBancaria;
	}

	public void setNumeroCuentaBancaria(String numeroCuentaBancaria) {
		this.numeroCuentaBancaria = numeroCuentaBancaria;
	}

	public String getNumeroCheque() {
		return numeroCheque;
	}

	public void setNumeroCheque(String numeroCheque) {
		this.numeroCheque = numeroCheque;
	}

	public LiquidacionesResponse(String idLiquidacion, String codigoComercio, String nombreComercio, String fechaPago,
			String monedaPago, Double importeConsumo, Double importeComision, Double igv, Double cargo,
			Double importeNetoLiquidacion, String documentoAautorizado, String formaPago, String banco,
			String tipoCuenta, String numeroCuentaBancaria, String numeroCheque) {
		super();
		this.idLiquidacion = idLiquidacion;
		this.codigoComercio = codigoComercio;
		this.nombreComercio = nombreComercio;
		this.fechaPago = fechaPago;
		this.monedaPago = monedaPago;
		this.importeConsumo = importeConsumo;
		this.importeComision = importeComision;
		this.igv = igv;
		this.cargo = cargo;
		this.importeNetoLiquidacion = importeNetoLiquidacion;
		this.documentoAautorizado = documentoAautorizado;
		this.formaPago = formaPago;
		this.banco = banco;
		this.tipoCuenta = tipoCuenta;
		this.numeroCuentaBancaria = numeroCuentaBancaria;
		this.numeroCheque = numeroCheque;
	}
	
	public LiquidacionesResponse() {
		super();
	}

}
