package pe.dinersclub.wscomercios.service.impl;

import java.util.LinkedHashMap;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pe.dinersclub.wscomercios.dao.TablaDAO;
import pe.dinersclub.wscomercios.dto.filtros.Tabla;
import pe.dinersclub.wscomercios.log.BeanLog;
import pe.dinersclub.wscomercios.log.UtilLog;
import pe.dinersclub.wscomercios.log.UtilLogLevel;
import pe.dinersclub.wscomercios.service.TablaService;

@Service
public class TablaServiceImpl implements TablaService {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private UtilLog utilLog;

	@Autowired
	private TablaDAO tablaDaoInterface;

	@Override
	public LinkedHashMap<String,String> obtenerFiltro(String identificador, String codigoFiltro) {

		BeanLog beanLog = new BeanLog();
		beanLog.setIdentificador(identificador);
		beanLog.setMetodo(new Object() {
		}.getClass().getEnclosingMethod().getName());

		List<Tabla> datosTabla = tablaDaoInterface.obtenerFiltro(identificador, codigoFiltro);
		LinkedHashMap<String,String> datosFiltro = new LinkedHashMap<String,String>();
		
		
		if (datosTabla != null) {
			for (Tabla dato : datosTabla) {
				datosFiltro.put(dato.getIdItemTabla(), dato.getDescripcion());
			}
		} else {
			beanLog.setDescripcionMensaje("No se obtuvieron resultados para la solicitud.");
			beanLog.setTipoMensaje(UtilLogLevel.INFO.name());
			utilLog.printInfo(logger, beanLog);
		}

		return datosFiltro;
	}

}
