package pe.dinersclub.wscomercios.controller;

import java.util.LinkedHashMap;
import javax.servlet.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.annotations.Api;
import pe.dinersclub.wscomercios.domain.BodyResponse;
import pe.dinersclub.wscomercios.exception.ModeloNotFountException;
import pe.dinersclub.wscomercios.log.BeanLog;
import pe.dinersclub.wscomercios.log.UtilLog;
import pe.dinersclub.wscomercios.service.TablaService;
import pe.dinersclub.wscomercios.util.Globales;
import pe.dinersclub.wscomercios.util.UtilDate;
import pe.dinersclub.wscomercios.util.UtilString;

@RestController
@RequestMapping("/filtros")
@Api(tags = { "Filtros" })
public class FiltroController {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private HttpServletRequest request;
	@Autowired
	private UtilLog utilLog;
	@Autowired
	private TablaService tablaServiceInterface;

	@GetMapping(path = "/{idFiltro}", produces = "application/json")
	public ResponseEntity<Object> listarVentas(@PathVariable(value = "idFiltro") String idFiltro, Authentication auth)
			 {

		long fechaInicio = UtilDate.getCurrentDateTime();
		BeanLog beanLog = new BeanLog();
		beanLog.setIdentificador(UtilString.obtenerIdentificadorUnico());
		beanLog.setSolicitud(request.getRequestURI());
		beanLog.setMetodo(new Object(){}.getClass().getEnclosingMethod().getName());
		beanLog.setEsPadre(true);
		beanLog.setNombreOperacion("Consulta Filtro");

		try {

			LinkedHashMap<String,String> datosFiltro = tablaServiceInterface.obtenerFiltro(beanLog.getIdentificador(), idFiltro);
			if (!datosFiltro.isEmpty()) {
				beanLog.setDescripcionMensaje("Solicitud procesada correctamente");
				return new ResponseEntity<>(
						new BodyResponse<LinkedHashMap<String,String>>(datosFiltro, Globales.RESPUESTA_EXITO), HttpStatus.OK);
			} else {
				beanLog.setDescripcionMensaje(Globales.CONSULTA_SIN_RESULTADO);
				throw new ModeloNotFountException(Globales.SOLICITUD_SIN_RESULTADOS, beanLog.getIdentificador());
			}
		} finally {
			long fechafinal = UtilDate.getCurrentDateTime();
			beanLog.setDuracion(fechafinal - fechaInicio);
			utilLog.printInfo(logger, beanLog);
		}
	}

}
