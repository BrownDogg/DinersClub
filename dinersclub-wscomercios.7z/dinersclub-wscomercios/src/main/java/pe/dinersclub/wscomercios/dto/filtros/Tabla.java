package pe.dinersclub.wscomercios.dto.filtros;

public class Tabla {

	private String codigoTabla;
	private String idItemTabla;
	private String descripcion;
	private String idItemDCP;

	public String getCodigoTabla() {
		return codigoTabla;
	}

	public void setCodigoTabla(String codigoTabla) {
		this.codigoTabla = codigoTabla;
	}

	public String getIdItemTabla() {
		return idItemTabla;
	}

	public void setIdItemTabla(String idItemTabla) {
		this.idItemTabla = idItemTabla;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public String getIdItemDCP() {
		return idItemDCP;
	}

	public void setIdItemDCP(String idItemDCP) {
		this.idItemDCP = idItemDCP;
	}

}
