package pe.dinersclub.wscomercios.domain;

public class ConsumosRequest {

	private String idEmpresa;
	private String idComercio;
	private String idMoneda;
	private String idEstadoConsumo;
	private String fechaInicio;
	private String fechaFin;
	private Integer page;
	private Integer xpage;
	
	public String getIdEmpresa() {
		return idEmpresa;
	}
	public void setIdEmpresa(String idEmpresa) {
		this.idEmpresa = idEmpresa;
	}
	public String getIdComercio() {
		return idComercio;
	}
	public void setIdComercio(String idComercio) {
		this.idComercio = idComercio;
	}
	public String getIdMoneda() {
		return idMoneda;
	}
	public void setIdMoneda(String idMoneda) {
		this.idMoneda = idMoneda;
	}
	public String getIdEstadoConsumo() {
		return idEstadoConsumo;
	}
	public void setIdEstadoConsumo(String idEstadoConsumo) {
		this.idEstadoConsumo = idEstadoConsumo;
	}
	public String getFechaInicio() {
		return fechaInicio;
	}
	public void setFechaInicio(String fechaInicio) {
		this.fechaInicio = fechaInicio;
	}
	public String getFechaFin() {
		return fechaFin;
	}
	public void setFechaFin(String fechaFin) {
		this.fechaFin = fechaFin;
	}
	public Integer getPage() {
		return page;
	}
	public void setPage(Integer page) {
		this.page = page;
	}
	public Integer getXpage() {
		return xpage;
	}
	public void setXpage(Integer xpage) {
		this.xpage = xpage;
	}
	
}
