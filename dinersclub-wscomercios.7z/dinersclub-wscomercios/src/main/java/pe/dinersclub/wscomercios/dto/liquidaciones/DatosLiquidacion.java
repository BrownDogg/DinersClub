package pe.dinersclub.wscomercios.dto.liquidaciones;

public class DatosLiquidacion {

	private String idLiquidacion;
	private String codigoComercio;
	private String nombreComercio;
	private String fechaPago;
	private String monedaPago;
	private Double importeConsumo;
	private Double importeComision;
	private Double igv;
	private Double cargo;
	private Double importeNetoLiquidacion;
	private String documentoAautorizado;
	private String formaPago;
	private String banco;
	private String tipoCuenta;
	private String nroCtaBancaria;
	private String nroCheque;
	
	
	public String getIdLiquidacion() {
		return idLiquidacion;
	}
	public void setIdLiquidacion(String idLiquidacion) {
		this.idLiquidacion = idLiquidacion;
	}
	public String getCodigoComercio() {
		return codigoComercio;
	}
	public void setCodigoComercio(String codigoComercio) {
		this.codigoComercio = codigoComercio;
	}
	public String getNombreComercio() {
		return nombreComercio;
	}
	public void setNombreComercio(String nombreComercio) {
		this.nombreComercio = nombreComercio;
	}
	public String getFechaPago() {
		return fechaPago;
	}
	public void setFechaPago(String fechaPago) {
		this.fechaPago = fechaPago;
	}
	public String getMonedaPago() {
		return monedaPago;
	}
	public void setMonedaPago(String monedaPago) {
		this.monedaPago = monedaPago;
	}
	public String getDocumentoAautorizado() {
		return documentoAautorizado;
	}
	public void setDocumentoAautorizado(String documentoAautorizado) {
		this.documentoAautorizado = documentoAautorizado;
	}
	public String getFormaPago() {
		return formaPago;
	}
	public void setFormaPago(String formaPago) {
		this.formaPago = formaPago;
	}
	public String getBanco() {
		return banco;
	}
	public void setBanco(String banco) {
		this.banco = banco;
	}
	public String getTipoCuenta() {
		return tipoCuenta;
	}
	public void setTipoCuenta(String tipoCuenta) {
		this.tipoCuenta = tipoCuenta;
	}
	public String getNroCtaBancaria() {
		return nroCtaBancaria;
	}
	public void setNroCtaBancaria(String nroCtaBancaria) {
		this.nroCtaBancaria = nroCtaBancaria;
	}
	public String getNroCheque() {
		return nroCheque;
	}
	public void setNroCheque(String nroCheque) {
		this.nroCheque = nroCheque;
	}
	public Double getImporteConsumo() {
		return importeConsumo;
	}
	public void setImporteConsumo(Double importeConsumo) {
		this.importeConsumo = importeConsumo;
	}
	public Double getImporteComision() {
		return importeComision;
	}
	public void setImporteComision(Double importeComision) {
		this.importeComision = importeComision;
	}
	public Double getIgv() {
		return igv;
	}
	public void setIgv(Double igv) {
		this.igv = igv;
	}
	public Double getCargo() {
		return cargo;
	}
	public void setCargo(Double cargo) {
		this.cargo = cargo;
	}
	public Double getImporteNetoLiquidacion() {
		return importeNetoLiquidacion;
	}
	public void setImporteNetoLiquidacion(Double importeNetoLiquidacion) {
		this.importeNetoLiquidacion = importeNetoLiquidacion;
	}
	
}
