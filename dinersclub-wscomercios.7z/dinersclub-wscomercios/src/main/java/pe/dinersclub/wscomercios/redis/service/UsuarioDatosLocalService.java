package pe.dinersclub.wscomercios.redis.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.type.TypeReference;

import pe.dinersclub.wscomercios.domain.usuario.UsuarioDatosResponse;
import pe.dinersclub.wscomercios.dto.usuario.RedisUsuarioDatosRequest;
import pe.dinersclub.wscomercios.log.BeanLog;
import pe.dinersclub.wscomercios.log.UtilLog;
import pe.dinersclub.wscomercios.log.UtilLogLevel;
import pe.dinersclub.wscomercios.util.UtilDate;
import pe.dinersclub.wscomercios.util.UtilObjectMapper;

@EnableAsync
@Service
public class UsuarioDatosLocalService {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private UtilLog utilLog;

	@Autowired
	private UsuarioDatosCacheService usuarioDatosCacheService;
	
	@Async
	public void deleteAll(String identificador) {
		usuarioDatosCacheService.deleteAllRedis(identificador);
	}
	
	public UsuarioDatosResponse findById(String identificador, String idUsuario) {
		BeanLog beanLog = new BeanLog();
		beanLog.setIdentificador(identificador);
		beanLog.setMetodo(new Object() {
		}.getClass().getEnclosingMethod().getName());
		try {
			RedisUsuarioDatosRequest redisUsuarioDatosRequest= UtilObjectMapper.getObjectMapper().readValue(
					usuarioDatosCacheService.findByIdRedis(identificador, idUsuario), new TypeReference<RedisUsuarioDatosRequest>() {
					});
			if (redisUsuarioDatosRequest == null) {
				// ENTRA AQUI CUANDO NO HAY CONEXION A REDIS
				// EXTRAEMOS LA DATA DE LA BD
				return usuarioDatosCacheService.findByIdLocal(identificador, idUsuario).getRespuesta();
			} else {
				if (redisUsuarioDatosRequest.getFechaConsulta() == null) {
					// SI LA FECHA CONSULTA ES NULA ES PORQUE TRAJO LA DATA DE LA BD
					return redisUsuarioDatosRequest.getRespuesta();
				} else {
					if (UtilDate.vencioFechaAlmacenamientoCache(redisUsuarioDatosRequest.getFechaConsulta())) {
						// REQUIERE VOLVER A CONSULTAR LA INFORMACION DE LA BD
						redisUsuarioDatosRequest = UtilObjectMapper.getObjectMapper().readValue(
								usuarioDatosCacheService.addRedis(identificador, idUsuario),
								new TypeReference<RedisUsuarioDatosRequest>() {
								});
						return redisUsuarioDatosRequest.getRespuesta();
					} else {
						// RETORNA LA INFORMACION DEL SERVIDOR DE CACHE
						return redisUsuarioDatosRequest.getRespuesta();
					}
				}
			}
		} catch(InternalError ex) {
			// SI NO RETORNO DATOS LA CONSULTA
			return null;
		} catch (Exception ex) {
			beanLog.setDescripcionMensaje(ex.getMessage());
			beanLog.setCausa(ex.getCause() != null ? ex.getCause().getMessage() : "");
			beanLog.setTipoMensaje(UtilLogLevel.ERROR.name());
			utilLog.printInfo(logger, beanLog);
			return usuarioDatosCacheService.findByIdLocal(identificador, idUsuario).getRespuesta();
		}
	}
	
}
