package pe.dinersclub.wscomercios.domain.transaccion;

public class DevolucionDomRequest {

	private String rucEmpresa;
	private String codigoComercio;
	private String idMoneda;
	private String idEstadoDevolucion;
	private String idTipoTransaccion;
	private String idTipoDocumento;
	private String fechaInicio;
	private String fechaFin;
	private int page;
	private int xpage;
	
	
	public String getRucEmpresa() {
		return rucEmpresa;
	}
	public void setRucEmpresa(String rucEmpresa) {
		this.rucEmpresa = rucEmpresa;
	}
	public String getCodigoComercio() {
		if(codigoComercio.isEmpty()) {
			return null;
		}else {
			return codigoComercio;
		}
	}
	public void setCodigoComercio(String codigoComercio) {
		this.codigoComercio = codigoComercio;
	}
	public String getIdMoneda() {
		if(idMoneda.isEmpty()) {
			return null;
		}else {
			return idMoneda;
		}
	}
	public void setIdMoneda(String idMoneda) {
		this.idMoneda = idMoneda;
	}
	public String getIdEstadoDevolucion() {
		if(idEstadoDevolucion.isEmpty()) {
			return null;
		}else {
			return idEstadoDevolucion;
		}
	}
	public void setIdEstadoDevolucion(String idEstadoDevolucion) {
		this.idEstadoDevolucion = idEstadoDevolucion;
	}
	public String getIdTipoTransaccion() {
		if(idTipoTransaccion.isEmpty()) {
			return null;
		}else {
			return idTipoTransaccion;
		}
	}
	public void setIdTipoTransaccion(String idTipoTransaccion) {
		this.idTipoTransaccion = idTipoTransaccion;
	}
	public String getIdTipoDocumento() {
		if(idTipoDocumento.isEmpty()) {
			return null;
		}else {
			return idTipoDocumento;
		}
	}
	public void setIdTipoDocumento(String idTipoDocumento) {
		this.idTipoDocumento = idTipoDocumento;
	}
	public String getFechaInicio() {
		return fechaInicio;
	}
	public void setFechaInicio(String fechaInicio) {
		this.fechaInicio = fechaInicio;
	}
	public String getFechaFin() {
		return fechaFin;
	}
	public void setFechaFin(String fechaFin) {
		this.fechaFin = fechaFin;
	}
	public int getPage() {
		return page;
	}
	public void setPage(int page) {
		this.page = page;
	}
	public int getXpage() {
		return xpage;
	}
	public void setXpage(int xpage) {
		this.xpage = xpage;
	}
	
}
