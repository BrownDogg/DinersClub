package pe.dinersclub.wscomercios.domain.liquidaciones;

public class LiquidacionesRequest {

	private String idEmpresa;
	private String codComercio;
	private String idMoneda;
	private String idFormaPago;
	private String idEstadoPago;
	private String fechaInicio;
	private String fechaFin;
	private String documentoAutorizado;
	private int page;
	private int xpage;
	
	public String getIdEmpresa() {
		return idEmpresa;
	}
	public void setIdEmpresa(String idEmpresa) {
		this.idEmpresa = idEmpresa;
	}
	public String getCodComercio() {
		return codComercio;
	}
	public void setCodComercio(String codComercio) {
		this.codComercio = codComercio;
	}
	public String getIdMoneda() {
		return idMoneda;
	}
	public void setIdMoneda(String idMoneda) {
		this.idMoneda = idMoneda;
	}
	public String getIdFormaPago() {
		return idFormaPago;
	}
	public void setIdFormaPago(String idFormaPago) {
		this.idFormaPago = idFormaPago;
	}
	public String getIdEstadoPago() {
		return idEstadoPago;
	}
	public void setIdEstadoPago(String idEstadoPago) {
		this.idEstadoPago = idEstadoPago;
	}
	public String getFechaInicio() {
		return fechaInicio;
	}
	public void setFechaInicio(String fechaInicio) {
		this.fechaInicio = fechaInicio;
	}
	public String getFechaFin() {
		return fechaFin;
	}
	public void setFechaFin(String fechaFin) {
		this.fechaFin = fechaFin;
	}
	public String getDocumentoAutorizado() {
		return documentoAutorizado;
	}
	public void setDocumentoAutorizado(String documentoAutorizado) {
		this.documentoAutorizado = documentoAutorizado;
	}
	public int getPage() {
		return page;
	}
	public void setPage(int page) {
		this.page = page;
	}
	public int getXpage() {
		return xpage;
	}
	public void setXpage(int xpage) {
		this.xpage = xpage;
	}
	
}
