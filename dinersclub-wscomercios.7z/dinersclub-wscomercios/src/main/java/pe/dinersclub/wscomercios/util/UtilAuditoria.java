package pe.dinersclub.wscomercios.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import pe.dinersclub.wscomercios.exception.ModeloNotFountException;
import pe.dinersclub.wscomercios.log.BeanLog;
import pe.dinersclub.wscomercios.log.UtilLog;
import pe.dinersclub.wscomercios.log.UtilLogLevel;

@Component
public class UtilAuditoria {

	@Autowired
	private UtilLog utilLog;

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	public BeanLog initLog(String identificador, String solicitud, String metodo, boolean padre,
			String nombreOperacion) {
		BeanLog beanLog = new BeanLog();
		beanLog.setIdentificador(identificador);
		beanLog.setSolicitud(solicitud);
		beanLog.setMetodo(metodo);
		beanLog.setEsPadre(padre);
		beanLog.setNombreOperacion(nombreOperacion);
		return beanLog;
	}

	public void endLog(BeanLog beanLog, Long fechaInicio) {
		long fechafinal = UtilDate.getCurrentDateTime();
		beanLog.setDuracion(fechafinal - fechaInicio);
		utilLog.printInfo(logger, beanLog);
	}
	
	public void errorMessageLog(BeanLog beanLog, String codMensaje, String tipoMensaje, String descripcionMensaje) {
		beanLog.setCodigoMensaje(codMensaje);
		beanLog.setTipoMensaje(tipoMensaje);
		beanLog.setDescripcionMensaje(descripcionMensaje);
		throw new ModeloNotFountException(beanLog.getCodigoMensaje(), beanLog.getIdentificador());
	}

	public void errorExceptionLog(BeanLog beanLog, String descripcionMensaje, String causa) {
		beanLog.setDescripcionMensaje(descripcionMensaje);
		beanLog.setCausa(causa);
		beanLog.setTipoMensaje(UtilLogLevel.ERROR.name());
		utilLog.printInfo(logger, beanLog);
		
	}
	
}
