package pe.dinersclub.wscomercios.util;

import pe.dinersclub.wscomercios.domain.CadAfiliacionIndividualRequest;

import java.math.BigDecimal;
import java.math.RoundingMode;

import pe.dinersclub.wscomercios.domain.BuscarTarjetaResponse;
import pe.dinersclub.wscomercios.dto.cad.CadDatosTarjeta;
import pe.dinersclub.wscomercios.dto.cad.CadMasivaRegistroCarga;
import pe.dinersclub.wscomercios.dto.cad.CadMasivaRegistroRespuesta;
import pe.dinersclub.wscomercios.dto.cad.CadServicio;

public class Util {

	public static CadServicio passAfiliacionIndividualRequestToCadServicio(
			CadAfiliacionIndividualRequest afiliarCadIndividualRequest) {

		CadServicio cadServicio = new CadServicio();

		cadServicio.setCodigoComercio(afiliarCadIndividualRequest.getCodigoComercio());
		cadServicio.setCodigoServicio(afiliarCadIndividualRequest.getCodigoServicio());
		cadServicio.setNumeroTarjeta(afiliarCadIndividualRequest.getNumeroTarjeta());
		cadServicio.setMontoTope(afiliarCadIndividualRequest.getMontoTope());
		cadServicio.setAnioVencimientoTarjeta(afiliarCadIndividualRequest.getAnioVencimientoTarjeta());
		cadServicio.setMesVencimientoTarjeta(afiliarCadIndividualRequest.getMesVencimientoTarjeta());
		cadServicio.setNombreUsuarioServicio(afiliarCadIndividualRequest.getUsuarioServicio());
		cadServicio.setTipoDocumentoIdentidadUsuarioServicio(afiliarCadIndividualRequest.getTipoDocumentoIdentidad());
		cadServicio
				.setNumeroDocumentoIdentidadUsuarioServicio(afiliarCadIndividualRequest.getNumeroDocumentoIdentidad());
		cadServicio.setTelefono(afiliarCadIndividualRequest.getTelefono());
		cadServicio.setEmail(afiliarCadIndividualRequest.getEmail());

		return cadServicio;
	}

	public static BuscarTarjetaResponse passCadDatosTarjetaToBuscarTarjetaResponse(CadDatosTarjeta cadDatosTarjeta) {

		BuscarTarjetaResponse tarjetaResponse = new BuscarTarjetaResponse();

		tarjetaResponse.setNombreSocio(cadDatosTarjeta.getNombreSocio());
		tarjetaResponse.setAnioVencimiento(cadDatosTarjeta.getAnioVencimiento());
		tarjetaResponse.setMesVencimiento(cadDatosTarjeta.getMesVencimiento());

		return tarjetaResponse;
	}

	public static CadMasivaRegistroRespuesta passCadMasivaRegistroCargaToCadMasivaRegistroRespuesta(
			CadMasivaRegistroCarga cadMasivaRegistroCarga) {

		CadMasivaRegistroRespuesta cadMasivaRegistroRespuesta = new CadMasivaRegistroRespuesta();

		cadMasivaRegistroRespuesta.setNumeroTarjeta(cadMasivaRegistroCarga.getNumeroTarjeta());
		cadMasivaRegistroRespuesta.setVencimientoTarjeta(
				cadMasivaRegistroCarga.getAnioVencimientoTarjeta() + cadMasivaRegistroCarga.getMesVencimientoTarjeta());
		cadMasivaRegistroRespuesta.setCodigoServicio(cadMasivaRegistroCarga.getCodigoServicio());
		cadMasivaRegistroRespuesta.setNumeroDocumentoIdentidadUsuarioServicio(
				cadMasivaRegistroCarga.getNumeroDocumentoIdentidadUsuarioServicio());
		cadMasivaRegistroRespuesta.setNombreUsuarioServicio(cadMasivaRegistroCarga.getCodigoServicio());
		cadMasivaRegistroRespuesta.setTelefono(cadMasivaRegistroCarga.getTelefono());
		cadMasivaRegistroRespuesta.setEmail(cadMasivaRegistroCarga.getEmail());
		cadMasivaRegistroRespuesta.setTipoMantenimiento(cadMasivaRegistroCarga.getTipoMantenimiento());
		cadMasivaRegistroRespuesta.setFechaEnvio(cadMasivaRegistroCarga.getFechaEnvio());
		cadMasivaRegistroRespuesta.setMontoTope(new BigDecimal(cadMasivaRegistroCarga.getMontoTope())
				.divide(new BigDecimal(100)).setScale(2, RoundingMode.FLOOR));
		cadMasivaRegistroRespuesta.setCodigoError(cadMasivaRegistroCarga.getCodigoError());
		cadMasivaRegistroRespuesta.setDescripcionError(cadMasivaRegistroCarga.getDescripcionError());

		return cadMasivaRegistroRespuesta;
	}

	static void test() {
		//prueba de sincronización
		//prueba 2
		//PRUEBA 3
	}
	
}
