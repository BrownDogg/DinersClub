package pe.dinersclub.wscomercios.security.filter;

import java.io.IOException;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.ProviderNotFoundException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

import com.fasterxml.jackson.databind.ObjectMapper;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import pe.dinersclub.wscomercios.dto.usuario.TokenDTO;
import pe.dinersclub.wscomercios.log.BeanLog;
import pe.dinersclub.wscomercios.log.UtilLog;
import pe.dinersclub.wscomercios.log.UtilLogLevel;
import pe.dinersclub.wscomercios.security.bean.UserCredentials;
import pe.dinersclub.wscomercios.security.bean.UsuarioAuthentication;
import pe.dinersclub.wscomercios.security.config.JwtConfig;
import pe.dinersclub.wscomercios.security.service.JWTService;
import pe.dinersclub.wscomercios.util.Globales;
import pe.dinersclub.wscomercios.util.UtilLanguages;
import pe.dinersclub.wscomercios.util.UtilString;

public class JWTAuthenticationFilter extends UsernamePasswordAuthenticationFilter {

	private Logger logger = LoggerFactory.getLogger(this.getClass());
	private AuthenticationManager authManager;
	private final JwtConfig jwtConfig;
	private UtilLog utilLog;

	@Autowired
	private JWTService jwtService;

	// Variable global que permitirá registrar el intento de acceso fallido
	protected String usuarioIntentoAcceso;

	public JWTAuthenticationFilter(AuthenticationManager authenticationManager, JwtConfig jwtConfig,
			JWTService jwtService, UtilLog utilLog) {
		this.authManager = authenticationManager;
		this.jwtConfig = jwtConfig;
		this.jwtService = jwtService;
		this.utilLog = utilLog;
		this.setRequiresAuthenticationRequestMatcher(new AntPathRequestMatcher(jwtConfig.getUri(), "POST"));
	}

	@Override
	public Authentication attemptAuthentication(HttpServletRequest request, HttpServletResponse response)
			throws AuthenticationException {

		try {

			// 1. obteniendo datos del request
			UserCredentials creds = new ObjectMapper().readValue(request.getInputStream(), UserCredentials.class);

			/* INICIO VALIDACION CAPTCHA */
			/*
			 * String parametersGoogleRecaptcha = "secret=" + Globales.GoogleRecaptchaApiKey
			 * + "&response=" + creds.getTokenCaptcha();
			 * 
			 * String responseHttp = UtilHttp.sendMessage(Globales.GoogleRecaptchaURL,
			 * HttpMethod.POST.name(), parametersGoogleRecaptcha,
			 * "application/x-www-form-urlencoded", null); if (responseHttp == null ||
			 * responseHttp.isEmpty()) { throw new
			 * ProviderNotFoundException(UtilLanguages.invalidCaptcha); }
			 * 
			 * BeanGoogleRecaptchaResponse beanGoogleRecaptchaResponse =
			 * UtilObjectMapper.getObjectMapper() .readValue(responseHttp,
			 * BeanGoogleRecaptchaResponse.class);
			 * 
			 * if (!beanGoogleRecaptchaResponse.isSuccess()) { throw new
			 * ProviderNotFoundException(UtilLanguages.invalidCaptcha); }
			 */

			/* FIN VALIDACION CAPTCHA */

			// 2. Creando un Objeto user que serÃƒÆ’Ã‚Â¡ usado por autmanager
			UsernamePasswordAuthenticationToken authToken = new UsernamePasswordAuthenticationToken(creds.getUsername(),
					creds.getPassword());

			// Dato de usuario asignadoa una variable para usarlo en caso falle la
			// autenticación
			usuarioIntentoAcceso = creds.getUsername().toUpperCase();

			// authToken.setDetails(UtilObjectMapper.getObjectMapper().writeValueAsString(creds));

			return authManager.authenticate(authToken);

		} catch (IOException ex) {
			throw new ProviderNotFoundException(Globales.OCURRIO_UN_PROBLEMA_AL_PROCESAR);
		}

	}

	/*** PASO FINAL DE GENERACION DE TOKEN ***/
	@Override
	protected void successfulAuthentication(HttpServletRequest request, HttpServletResponse response, FilterChain chain,
			Authentication authResult) throws IOException, ServletException {

		BeanLog beanLog = new BeanLog();
		beanLog.setSolicitud(request.getRequestURI());
		beanLog.setMetodo(new Object() {
		}.getClass().getEnclosingMethod().getName());

		try {
			UsuarioAuthentication usuario = (UsuarioAuthentication) authResult.getPrincipal();
			String identificador = UtilString.obtenerIdentificadorUnico();
			Collection<? extends GrantedAuthority> roles = authResult.getAuthorities();
			Long now = System.currentTimeMillis();

			Date issued = new Date(now);
			Date expires = new Date(now + jwtConfig.getExpiration() * 1000);

			// Armamos el token
			Claims claims = Jwts.claims();
			claims.put("authorities", new ObjectMapper().writeValueAsString(roles));
			claims.put("empresa", usuario.getEmpresa());
			claims.put("enabled", usuario.isEnabled());
			claims.put("access", usuario.isAcceso());

			String token = Jwts.builder().setClaims(claims).setSubject(usuario.getIdUsuario().toString())
					.signWith(SignatureAlgorithm.HS512, jwtConfig.getSecret().getBytes()).setIssuedAt(issued)
					.setExpiration(expires).compact();

			// GUARDAMOS EL TOKEN ASOCIADO AL CODIGO DE USUARIO

			TokenDTO tokenDTO = new TokenDTO(usuario.getIdUsuario().toString(), token, new Date());

			jwtService.addToken(identificador, tokenDTO);

			// tokenLocalService.add(identificador, tokenDTO);

			// Respuesta del servicio
			response.addHeader(jwtConfig.getHeader(), "Bearer " + token);
			Map<String, Object> body = new HashMap<String, Object>();
			body.put("token", token);
			body.put("token_type", jwtConfig.getPrefix());
			body.put("acces", usuario.isAcceso());
			body.put(".issued", issued.toString());
			body.put(".expires", expires.toString());

			response.getWriter().write(new ObjectMapper().writeValueAsString(body));
			response.setStatus(HttpServletResponse.SC_OK);
			response.setContentType("application/json");

			// limpiamos la variable global
			usuarioIntentoAcceso = null;

			beanLog.setDescripcionMensaje("LOGIN PROCESADO SATISFACTORIAMENTE PARA EL USUARIO: "
					+ tokenDTO.getIdUsuario() + " - LA SOLICITUD SE REALIZÓ DESDE: " + request.getRemoteAddr().toString());
			beanLog.setTipoMensaje(UtilLogLevel.INFO.name());
			utilLog.printInfo(logger, beanLog);

		} catch (Exception ex) {
			beanLog.setDescripcionMensaje("ERROR AL RESPONDER SOLICITUD DE GENERACION DE TOKEN");
			utilLog.printInfo(logger, beanLog);
			throw new IOException(UtilLanguages.getString(UtilLanguages.invalidProcess));
		}
	}

	@Override
	protected void unsuccessfulAuthentication(HttpServletRequest request, HttpServletResponse response,
			AuthenticationException failed) throws IOException, ServletException {

		Map<String, Object> body = new HashMap<String, Object>();

		// se proecesa el intento de acceso fallido
		Boolean usuarioNoBloqueado = jwtService.procesarAccesosFallidos(usuarioIntentoAcceso,
				request.getRemoteAddr().toString());

		String codigoRespuesta = (usuarioNoBloqueado) ? Globales.USUARIO_PASSWORD_CAPTCHA_INCORRECTO
				: Globales.USUARIO_BLOQUEADO;

		body.put("codigoRespuesta", codigoRespuesta);
		body.put("detalle", failed.getMessage());

		response.getWriter().write(new ObjectMapper().writeValueAsString(body));
		response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
		response.setContentType("application/json");

		usuarioIntentoAcceso = null;

	}

}
