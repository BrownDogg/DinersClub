package pe.dinersclub.wscomercios.dto.empresa;

import java.util.List;

import pe.dinersclub.wscomercios.dto.comercio.ComercioDTO;

public class EmpresaDTO {
	
	private String rucEmpresa;
	private String razonSocial;
	private String repLegal;
	
	private List<ComercioDTO> comercios;
	
	public String getRucEmpresa() {
		return rucEmpresa;
	}
	public void setRucEmpresa(String rucEmpresa) {
		this.rucEmpresa = rucEmpresa;
	}
	public String getRazonSocial() {
		return razonSocial;
	}
	public void setRazonSocial(String razonSocial) {
		this.razonSocial = razonSocial;
	}
	public String getRepLegal() {
		return repLegal;
	}
	public void setRepLegal(String repLegal) {
		this.repLegal = repLegal;
	}
	public List<ComercioDTO> getComercios() {
		return comercios;
	}
	public void setComercios(List<ComercioDTO> comercios) {
		this.comercios = comercios;
	}
	
	public EmpresaDTO(String rucEmpresa, String razonSocial, String repLegal) {
		super();
		this.rucEmpresa = rucEmpresa;
		this.razonSocial = razonSocial;
		this.repLegal = repLegal;
	}
	
	public EmpresaDTO() {
		super();
	}
	@Override
	public String toString() {
		return "EmpresaDTO [rucEmpresa=" + rucEmpresa + ", razonSocial=" + razonSocial + ", repLegal=" + repLegal
				+ ", comercios=" + comercios + "]";
	}
	
}
