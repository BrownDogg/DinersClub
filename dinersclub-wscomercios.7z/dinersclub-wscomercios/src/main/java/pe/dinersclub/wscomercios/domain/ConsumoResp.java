package pe.dinersclub.wscomercios.domain;

public class ConsumoResp {
	
	private String codigoComercio;
	private String nombreComercio;
	private String origenTransaccion;
	private String fechaProceso;
	private String tarjeta;
	private String tipoTarjeta;
	private String codAutorizacion;
	private String fechaTicket;
	private String numeroTicket;
	private String moneda;
	private String importe;
	private String numeroCuotas;
	private String estadoTicket;
	private String plazoPago;
	private String fechaPago;
	private String comision;
	private String igv;
	private String importeNeto;
	
	public String getCodigoComercio() {
		return codigoComercio;
	}
	public void setCodigoComercio(String codigoComercio) {
		this.codigoComercio = codigoComercio;
	}
	public String getNombreComercio() {
		return nombreComercio;
	}
	public void setNombreComercio(String nombreComercio) {
		this.nombreComercio = nombreComercio;
	}
	public String getOrigenTransaccion() {
		return origenTransaccion;
	}
	public void setOrigenTransaccion(String origenTransaccion) {
		this.origenTransaccion = origenTransaccion;
	}
	public String getFechaProceso() {
		return fechaProceso;
	}
	public void setFechaProceso(String fechaProceso) {
		this.fechaProceso = fechaProceso;
	}
	public String getTarjeta() {
		return tarjeta;
	}
	public void setTarjeta(String tarjeta) {
		this.tarjeta = tarjeta;
	}
	public String getTipoTarjeta() {
		return tipoTarjeta;
	}
	public void setTipoTarjeta(String tipoTarjeta) {
		this.tipoTarjeta = tipoTarjeta;
	}
	public String getCodAutorizacion() {
		return codAutorizacion;
	}
	public void setCodAutorizacion(String codAutorizacion) {
		this.codAutorizacion = codAutorizacion;
	}
	public String getFechaTicket() {
		return fechaTicket;
	}
	public void setFechaTicket(String fechaTicket) {
		this.fechaTicket = fechaTicket;
	}
	public String getNumeroTicket() {
		return numeroTicket;
	}
	public void setNumeroTicket(String numeroTicket) {
		this.numeroTicket = numeroTicket;
	}
	public String getMoneda() {
		return moneda;
	}
	public void setMoneda(String moneda) {
		this.moneda = moneda;
	}
	public String getImporte() {
		return importe;
	}
	public void setImporte(String importe) {
		this.importe = importe;
	}
	public String getNumeroCuotas() {
		return numeroCuotas;
	}
	public void setNumeroCuotas(String numeroCuotas) {
		this.numeroCuotas = numeroCuotas;
	}
	public String getEstadoTicket() {
		return estadoTicket;
	}
	public void setEstadoTicket(String estadoTicket) {
		this.estadoTicket = estadoTicket;
	}
	public String getPlazoPago() {
		return plazoPago;
	}
	public void setPlazoPago(String plazoPago) {
		this.plazoPago = plazoPago;
	}
	public String getFechaPago() {
		return fechaPago;
	}
	public void setFechaPago(String fechaPago) {
		this.fechaPago = fechaPago;
	}
	public String getComision() {
		return comision;
	}
	public void setComision(String comision) {
		this.comision = comision;
	}
	public String getIgv() {
		return igv;
	}
	public void setIgv(String igv) {
		this.igv = igv;
	}
	public String getImporteNeto() {
		return importeNeto;
	}
	public void setImporteNeto(String importeNeto) {
		this.importeNeto = importeNeto;
	}
	
	@Override
	public String toString() {
		return "ConsumoResp [nombreComercio=" + nombreComercio + ", origenTransaccion=" + origenTransaccion
				+ ", fechaProceso=" + fechaProceso + ", tarjeta=" + tarjeta + ", tipoTarjeta=" + tipoTarjeta
				+ ", codAutorizacion=" + codAutorizacion + ", fechaTicket=" + fechaTicket + ", numeroTicket="
				+ numeroTicket + ", moneda=" + moneda + ", importe=" + importe + ", numeroCuotas=" + numeroCuotas
				+ ", estadoTicket=" + estadoTicket + ", plazoPago=" + plazoPago + ", fechaPago=" + fechaPago
				+ ", comision=" + comision + ", igv=" + igv + ", importeNeto=" + importeNeto + "]";
	}

}
