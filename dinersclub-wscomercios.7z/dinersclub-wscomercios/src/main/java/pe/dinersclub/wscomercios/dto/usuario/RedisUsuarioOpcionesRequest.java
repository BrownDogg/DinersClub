package pe.dinersclub.wscomercios.dto.usuario;

import java.util.Date;
import java.util.List;

import pe.dinersclub.wscomercios.domain.usuario.UsuarioOpcionResponse;

public class RedisUsuarioOpcionesRequest {

	private List<UsuarioOpcionResponse> respuesta;
	private Date fechaConsulta;

	public List<UsuarioOpcionResponse> getRespuesta() {
		return respuesta;
	}

	public void setRespuesta(List<UsuarioOpcionResponse> respuesta) {
		this.respuesta = respuesta;
	}

	public Date getFechaConsulta() {
		return fechaConsulta;
	}

	public void setFechaConsulta(Date fechaConsulta) {
		this.fechaConsulta = fechaConsulta;
	}

}
