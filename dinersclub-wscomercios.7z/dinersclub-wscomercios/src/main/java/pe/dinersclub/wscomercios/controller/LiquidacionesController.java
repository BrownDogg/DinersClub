package pe.dinersclub.wscomercios.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.annotations.Api;
import pe.dinersclub.wscomercios.domain.BodyResponse;
import pe.dinersclub.wscomercios.domain.liquidaciones.LiquidacionDetalleResponse;
import pe.dinersclub.wscomercios.domain.liquidaciones.LiquidacionesRequest;
import pe.dinersclub.wscomercios.dto.liquidaciones.DatosLiquidacion;
import pe.dinersclub.wscomercios.log.BeanLog;
import pe.dinersclub.wscomercios.service.LiquidacionesService;
import pe.dinersclub.wscomercios.util.Globales;
import pe.dinersclub.wscomercios.util.UtilAuditoria;
import pe.dinersclub.wscomercios.util.UtilDate;
import pe.dinersclub.wscomercios.util.UtilString;

@RestController
@Api(tags = { "Módulo Liquidaciones" })
@RequestMapping("/liquidaciones")
public class LiquidacionesController {

	@Autowired
	private HttpServletRequest request;
	@Autowired
	private UtilAuditoria utilAudit;
	@Autowired
	LiquidacionesService liquidacionesService;

	@GetMapping(value = "/listarLiquidaciones", produces = "application/json")
	public ResponseEntity<Object> listarLiquidaciones(LiquidacionesRequest liquidacionesRequest) {
		BeanLog beanLog = new BeanLog();
		long fechaInicio = UtilDate.getCurrentDateTime();
		String idTransaccion = UtilString.obtenerIdentificadorUnico();
		String metodo = new Object(){}.getClass().getEnclosingMethod().getName();
		beanLog = utilAudit.initLog(idTransaccion, request.getRequestURI(), metodo, true, "Listar Liquidaciones");
		
		try {
			List<DatosLiquidacion> lista = liquidacionesService.listarLiquidaciones(idTransaccion, liquidacionesRequest);

			if (!lista.isEmpty()) {
				return new ResponseEntity<>(new BodyResponse<List<DatosLiquidacion>>(lista, Globales.RESPUESTA_EXITO),
						HttpStatus.OK);
			} else {
				return new ResponseEntity<>(new BodyResponse<List<DatosLiquidacion>>(lista,
						Globales.ModuloLiquidaciones.LIQUIDACIONES_NO_ENCONTRADAS), HttpStatus.BAD_REQUEST);
			} 
		} catch (Exception e) {
			return new ResponseEntity<>(
					new BodyResponse<String>("Ocurrió un error genérico: " + e.getMessage(), Globales.RESPUESTA_EXITO),
					HttpStatus.BAD_REQUEST);
		}finally {
			utilAudit.endLog(beanLog, fechaInicio);
		}
	}

	@GetMapping(path = "/{codigoPago}", produces = "application/json")
	public ResponseEntity<Object> listarLiquidacionesDetalle(@PathVariable("codigoPago") String codigoPago) {
		
		BeanLog beanLog = new BeanLog();
		long fechaInicio = UtilDate.getCurrentDateTime();
		String idTransaccion = UtilString.obtenerIdentificadorUnico();
		String metodo = new Object(){}.getClass().getEnclosingMethod().getName();
		beanLog = utilAudit.initLog(idTransaccion, request.getRequestURI(), metodo, true, "Listar Liquidaciones Detalle");
		
		try {
			List<LiquidacionDetalleResponse> lista = liquidacionesService.listarLiquidacionesDetalle(idTransaccion,
					codigoPago);

			if (!lista.isEmpty()) {
				return new ResponseEntity<>(
						new BodyResponse<List<LiquidacionDetalleResponse>>(lista, Globales.RESPUESTA_EXITO),
						HttpStatus.OK);
			} else {
				return new ResponseEntity<>(
						new BodyResponse<List<LiquidacionDetalleResponse>>(lista,
								Globales.ModuloLiquidaciones.LIQUIDACIONES_DETALLE_NO_ENCONTRADAS),
						HttpStatus.BAD_REQUEST);
			} 
		} catch (Exception e) {
			return new ResponseEntity<>(
					new BodyResponse<String>("Ocurrió un error genérico: " + e.getMessage(), Globales.RESPUESTA_EXITO),
					HttpStatus.BAD_REQUEST);
		}finally {
			utilAudit.endLog(beanLog, fechaInicio);
		}
	}

}
