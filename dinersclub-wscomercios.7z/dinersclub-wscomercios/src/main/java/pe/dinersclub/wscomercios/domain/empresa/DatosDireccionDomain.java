package pe.dinersclub.wscomercios.domain.empresa;

public class DatosDireccionDomain {

	private String tipoDireccion;
	private String direccionComercio;

	public DatosDireccionDomain() {
		super();
	}

	public DatosDireccionDomain(String tipoDireccion, String direccionComercio) {
		super();
		this.tipoDireccion = tipoDireccion;
		this.direccionComercio = direccionComercio;
	}

	public String getTipoDireccion() {
		return tipoDireccion;
	}

	public void setTipoDireccion(String tipoDireccion) {
		this.tipoDireccion = tipoDireccion;
	}

	public String getDireccionComercio() {
		return direccionComercio;
	}

	public void setDireccionComercio(String direccionComercio) {
		this.direccionComercio = direccionComercio;
	}

}
