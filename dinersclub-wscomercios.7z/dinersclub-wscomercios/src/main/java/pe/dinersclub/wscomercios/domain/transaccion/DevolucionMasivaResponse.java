package pe.dinersclub.wscomercios.domain.transaccion;

import java.util.List;

public class DevolucionMasivaResponse {

	private String codigoDevolucion;
	private List<DevolucionDetalle> listaDetalleDevolucion;
	
	public String getCodigoDevolucion() {
		return codigoDevolucion;
	}
	public void setCodigoDevolucion(String codigoDevolucion) {
		this.codigoDevolucion = codigoDevolucion;
	}
	public List<DevolucionDetalle> getListaDetalleDevolucion() {
		return listaDetalleDevolucion;
	}
	public void setListaDetalleDevolucion(List<DevolucionDetalle> listaDevolucion) {
		this.listaDetalleDevolucion = listaDevolucion;
	}
	
}