package pe.dinersclub.wscomercios.dao;

import java.util.List;

import pe.dinersclub.wscomercios.dto.comercio.ComercioDTO;
import pe.dinersclub.wscomercios.dto.comercio.DatosCuentasDTO;
import pe.dinersclub.wscomercios.dto.comercio.DatosDireccionDTO;
import pe.dinersclub.wscomercios.dto.comercio.DatosTelefonoDTO;

public interface ComercioDAO {

	
	public boolean actualizarDatosComercio(String idTransaccion, ComercioDTO comercio);
	public boolean actualizarTelefonoComercio(String idTransaccion, DatosTelefonoDTO telefono);
	public boolean actualizarDireccionComercio(String idTransaccion, DatosDireccionDTO direccion);
	public List<DatosCuentasDTO> listarCuentas (String idTransaccion, String idEmpresa, String codigoComercio);
	public List<DatosTelefonoDTO> listarTelefonos (String idTransaccion, String idEmpresa, String codigoComercio);
	public List<DatosDireccionDTO> listarDirecciones (String idTransaccion, String idEmpresa, String codigoComercio);
	
	public ComercioDTO obtenerComercio(String idTransaccion, String codigoComercio);
	
}
