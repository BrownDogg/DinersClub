package pe.dinersclub.wscomercios.redis.service;

import java.util.Date;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;

import pe.dinersclub.wscomercios.dao.UsuarioDAO;
import pe.dinersclub.wscomercios.domain.usuario.UsuarioDatosResponse;
import pe.dinersclub.wscomercios.dto.usuario.RedisUsuarioDatosRequest;
import pe.dinersclub.wscomercios.util.UtilObjectMapper;

/*
 * SE AGREGA EL SCOPE PARA SOLUCIONAR EL PROBLEMA DE CONSULTA DE OTRO METODO DEL MISMO BEAN
 * PORQUE SINO, NO SE GUARDA EN CACHE
 */
@Service
@Scope(proxyMode = ScopedProxyMode.TARGET_CLASS)
public class UsuarioDatosCacheService {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	public final String cacheNames = "UsuarioDatos";

	@Autowired
	private UsuarioDAO usuarioDao;

	public RedisUsuarioDatosRequest findByIdLocal(String identificador, String idUsuario) {

		RedisUsuarioDatosRequest redisUsuarioDatosRequest = new RedisUsuarioDatosRequest();
		try {
			UsuarioDatosResponse datosIniciales = usuarioDao.obtenerNombresUsuarioYEmpresa(identificador, idUsuario);
			datosIniciales.setComercios(usuarioDao.obtenerComerciosPorUsuario(identificador, idUsuario));

			redisUsuarioDatosRequest.setRespuesta(datosIniciales);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return redisUsuarioDatosRequest;
	}

	@CachePut(cacheNames = cacheNames, key = "(#root.target.cacheNames).concat('_').concat(#idUsuario)", unless = "#result == null")
	public String addRedis(String identificador, String idUsuario) {
		String json = null;
		try {
			RedisUsuarioDatosRequest redisUsuarioDatosRequest = findByIdLocal(identificador, idUsuario);
			if (!(redisUsuarioDatosRequest.getRespuesta() == null)) {
				redisUsuarioDatosRequest.setFechaConsulta(new Date());
				json = UtilObjectMapper.getObjectMapper().writeValueAsString(redisUsuarioDatosRequest);
			} else {
				throw new InternalError();
			}
		} catch (JsonProcessingException ex) {
			ex.printStackTrace();
		} finally {
			if (json != null)
				logger.info("Se agrego al cache a {} con id: {}", cacheNames, idUsuario);
		}
		return json;
	}

	@Cacheable(cacheNames = cacheNames, key = "(#root.target.cacheNames).concat('_').concat(#id)", unless = "#result == null")
	public String findByIdRedis(String identificador, String id) {
		String json = null;
		try {
			RedisUsuarioDatosRequest redisUsuarioDatosRequest = findByIdLocal(identificador, id);
			if (redisUsuarioDatosRequest != null) {
				redisUsuarioDatosRequest.setFechaConsulta(new Date());
				json = UtilObjectMapper.getObjectMapper().writeValueAsString(redisUsuarioDatosRequest);
			} else {
				throw new InternalError();
			}
		} catch (JsonProcessingException ex) {
			ex.printStackTrace();
		} finally {
			if (json != null)
				logger.info("Se agrego al cache a {} con id: {}", cacheNames, id);
		}
		return json;
	}

	@CacheEvict(cacheNames = cacheNames, key = "(#root.target.cacheNames).concat('_').concat(#id)")
	public void deleteRedis(String identificador, String id) {
		logger.info("Se quito del cache a {} con id: {}", cacheNames, id);
	}

	@CacheEvict(cacheNames = cacheNames, allEntries = true)
	public void deleteAllRedis(String identificador) {
		logger.info("Se elimino del cache a todo {}", cacheNames);
	}

}
