package pe.dinersclub.wscomercios.dao.impl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import pe.dinersclub.wscomercios.dao.LiquidacionesDAO;
import pe.dinersclub.wscomercios.dto.liquidaciones.DatosLiquidacion;
import pe.dinersclub.wscomercios.dto.liquidaciones.LiquidacionDTO;
import pe.dinersclub.wscomercios.dto.liquidaciones.LiquidacionDetalleDTO;
import pe.dinersclub.wscomercios.log.BeanLog;
import pe.dinersclub.wscomercios.util.ConnectionDB;
import pe.dinersclub.wscomercios.util.Globales;
import pe.dinersclub.wscomercios.util.UtilAuditoria;
import pe.dinersclub.wscomercios.util.UtilDate;

@Repository
public class LiquidacionesDAOImpl implements LiquidacionesDAO {

	@Autowired
	private UtilAuditoria utilAudit;

	@Override
	public List<DatosLiquidacion> listarLiquidaciones(String idTransaccion, LiquidacionDTO liquidacion) {

		BeanLog beanLog = new BeanLog();
		long fechaInicio = UtilDate.getCurrentDateTime();
		String metodo = new Object() {
		}.getClass().getEnclosingMethod().getName();
		beanLog = utilAudit.initLog(idTransaccion, null, metodo, false, "Listar Liquidaciones DAO");
		DatosLiquidacion datosLiquidacion = null;
		Connection conn = null;
		CallableStatement cs = null;
		ResultSet rs = null;
		StringBuilder sbSQLConsulta = new StringBuilder();
		List<DatosLiquidacion> listaLiquidacion = null;

		try {

			sbSQLConsulta.append(Globales.CALL_SP).append(Globales.ESQUEMA_PROC);
			sbSQLConsulta.append(".").append("SP_WSC_LISTAR_LIQUIDACIONES").append("(?,?,?,?,?,?,?,?,?,?)}");
			conn = ConnectionDB.getConnectionServerAS400();
			cs = conn.prepareCall(sbSQLConsulta.toString());
			cs.setString(1, liquidacion.getIdEmpresa());
			cs.setString(2, liquidacion.getCodComercio());
			cs.setString(3, liquidacion.getIdMoneda());
			cs.setString(4, liquidacion.getIdFormaPago());
			cs.setString(5, liquidacion.getIdEstadoPago());
			cs.setString(6, liquidacion.getDocumentoAutorizado());
			cs.setString(7, liquidacion.getFechaInicio());
			cs.setString(8, liquidacion.getFechaFin());
			cs.setInt(9, liquidacion.getPage());
			cs.setInt(10, liquidacion.getXpage());

			cs.execute();
			rs = cs.getResultSet();

			if (rs != null) {
				listaLiquidacion = new LinkedList<>();
				while (rs.next()) {
					datosLiquidacion = new DatosLiquidacion();
					datosLiquidacion.setIdLiquidacion(rs.getString("IDLIQIDACION"));
					datosLiquidacion.setCodigoComercio(rs.getString("IDCOMERCIO"));
					datosLiquidacion.setNombreComercio(rs.getString("NOMCOMERCIO").trim());
					datosLiquidacion.setFechaPago(rs.getString("FECPAGO"));
					datosLiquidacion.setMonedaPago(rs.getString("TIPMONEDA"));
					datosLiquidacion.setImporteConsumo(rs.getDouble("IMPORTE_TCK"));
					datosLiquidacion.setImporteComision(rs.getDouble("IMPORTE_COMISION"));
					datosLiquidacion.setIgv(rs.getDouble("IMP_IGV_COMISION"));
					datosLiquidacion.setCargo(rs.getDouble("CARGO"));
					datosLiquidacion.setImporteNetoLiquidacion(rs.getDouble("IMPNETOLIQ"));
					datosLiquidacion.setDocumentoAautorizado(rs.getString("DOCAUT"));
					datosLiquidacion.setFormaPago(rs.getString("FORMAPAGO").trim());
					datosLiquidacion.setBanco(rs.getString("BANCO").trim());
					datosLiquidacion.setTipoCuenta(rs.getString("TIPOCTA"));
					datosLiquidacion.setNroCtaBancaria(rs.getString("NROCTA").trim());
					datosLiquidacion.setNroCheque(rs.getString("NROCHEQUE").trim());
					listaLiquidacion.add(datosLiquidacion);
				}
			}
		} catch (Exception e) {
			utilAudit.errorExceptionLog(beanLog, e.getMessage(), e.getCause().getMessage());
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (cs != null)
					cs.close();
				if (conn != null)
					conn.close();
			} catch (SQLException ex) {
			}
			utilAudit.endLog(beanLog, fechaInicio);
		}
		return listaLiquidacion;
	}

	@Override
	public List<LiquidacionDetalleDTO> listarLiquidacionesDetalle(String idTransaccion, String codPago) {

		BeanLog beanLog = new BeanLog();
		long fechaInicio = UtilDate.getCurrentDateTime();
		String metodo = new Object() {}.getClass().getEnclosingMethod().getName();
		beanLog = utilAudit.initLog(idTransaccion, null, metodo, false, "Listar Liquidaciones Detalle DAO");
		
		List<LiquidacionDetalleDTO> lista = null;
		LiquidacionDetalleDTO detalle = null;
		Connection conn = null;
		CallableStatement cs = null;
		ResultSet rs = null;
		StringBuilder sbSQLConsulta = new StringBuilder();

		try {

			sbSQLConsulta.append(Globales.CALL_SP).append(Globales.ESQUEMA_PROC);
			sbSQLConsulta.append(".").append("SP_WSC_LISTAR_LIQUIDACIONES_DETALLE").append("(?,?,?)}");
			conn = ConnectionDB.getConnectionServerAS400();
			cs = conn.prepareCall(sbSQLConsulta.toString());
			cs.setString(1, codPago);
			cs.setString(2, "20");
			cs.setString(3, "1");

			cs.execute();
			rs = cs.getResultSet();
			if (rs != null) {
				lista = new LinkedList<>();
				while (rs.next()) {
					detalle = new LiquidacionDetalleDTO();
					detalle.setCodAntiguo(rs.getString("CODANTIGUO"));
					detalle.setFecRecep(rs.getString("FEC_RECEP"));
					detalle.setCodComercio(rs.getString("CODCOMERCIO"));
					detalle.setCodRecap(rs.getString("CODRECAP"));
					detalle.setNroTicket(rs.getString("NROTICKET"));
					detalle.setTarjetaSocio(rs.getString("TARJETA"));
					detalle.setFecTicket(rs.getString("FECTICKET"));
					detalle.setImpTicket(rs.getString("IMP_TICKET"));
					detalle.setImpComTicket(rs.getString("IMP_COM_TICKET"));
					detalle.setMoneda(rs.getString("MONEDA"));
					detalle.setNroAut(rs.getString("NRO_AUT"));
					detalle.setCorrelativo(rs.getString("CORRELATIVO"));
					detalle.setEstado(rs.getString("ESTADO"));
					detalle.setImpIgvTicket(rs.getString("IMP_IGV_TICKET"));
					detalle.setImpComiTicket(rs.getString("IMP_COMI_TICKET"));
					detalle.setImpNoComiTicket(rs.getString("IMP_NO_COM_TICKET"));
					detalle.setDocAut(rs.getString("DOC_AUT"));
					detalle.setCuenta(rs.getString("CUENTA"));
					detalle.setFecPagoEfect(rs.getString("FECPAGO_EFEC"));
					detalle.setFormaPago(rs.getString("FORMA_PAGO"));
					detalle.setBanco(rs.getString("BANCO"));
					detalle.setImpAjuste(rs.getString("IMP_AJUSTE"));
					detalle.setNroComprobante(rs.getString("NRO_COMPROBANTE"));
					lista.add(detalle);
				}
			}
		} catch (Exception e) {
			utilAudit.errorExceptionLog(beanLog, e.getMessage(), e.getCause().getMessage());
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (cs != null)
					cs.close();
				if (conn != null)
					conn.close();
			} catch (SQLException ex) {
			}
			utilAudit.endLog(beanLog, fechaInicio);
		}
		return lista;
	}

}
