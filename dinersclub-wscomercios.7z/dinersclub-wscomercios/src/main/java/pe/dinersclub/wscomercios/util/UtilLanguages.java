package pe.dinersclub.wscomercios.util;

import java.util.HashMap;
import java.util.Map;

public class UtilLanguages {

	private static Map<String, String> mapLanguage = new HashMap<String, String>();
	public static final String invalidGrant_0 = "invalid_grant_0";
	public static final String invalidGrant_1 = "invalid_grant_1";
	public static final String invalidGrant_2 = "invalid_grant_2";
	public static final String invalidGrant_3 = "invalid_grant_3";
	public static final String invalidGrant_4 = "invalid_grant_4";
	public static final String invalidGrant_5 = "invalid_grant_5";
	public static final String invalidGrant_6 = "invalid_grant_6";
	public static final String invalidGrant_7 = "invalid_grant_7";
	public static final String invalidGrant_8 = "invalid_grant_8";
	public static final String invalidScope = "invalid_scope";
	public static final String invalidCaptcha = "invalid_captcha";
	public static final String invalidProcess = "invalid_process";

	static {
		mapLanguage.put(invalidGrant_0,
				"Número de documento o clave digital incorrecta. Por favor vuelva a intentarlo.");
		mapLanguage.put(invalidGrant_1,
				"Estimado socio, ha superado el número de intentos permitidos para esta opción, por favor vuelva a intentar dentro de una hora.");
		mapLanguage.put(invalidGrant_2, "Su tarjeta está inactiva");
		mapLanguage.put(invalidGrant_3, "Los datos ingresados son incorrectos. Por favor vuelva a intentarlo");
		mapLanguage.put(invalidGrant_4, "Su tarjeta está inactiva o bloqueada");
		mapLanguage.put(invalidGrant_5, "Los datos ingresados son incorrectos. Por favor vuelva a intentarlo");
		mapLanguage.put(invalidGrant_6,
				"Usted ya cuenta con clave digital, si no la recuerda ingrese a Olvidé mi clave");
		mapLanguage.put(invalidGrant_7,
				"Usted no cuenta con clave digital. Por favor ingresar a la opción generar clave digital");
		mapLanguage.put(invalidGrant_8, "tipoConsulta inválido");
		mapLanguage.put(invalidScope, "El valor del atributo scope es inválido");
		mapLanguage.put(invalidCaptcha, "La validación captcha no se pudo completar.");
		mapLanguage.put(invalidProcess, "Error en proceso interno");
	}

	public static String getString(String field) {
		return mapLanguage.get(field);
	}
}
