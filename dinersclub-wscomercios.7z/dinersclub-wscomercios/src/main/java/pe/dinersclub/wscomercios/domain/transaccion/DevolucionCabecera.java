package pe.dinersclub.wscomercios.domain.transaccion;

public class DevolucionCabecera {
	
	private String codigoComercio;
	private String origenTranx;
	private String nroRegistros;
	private String fechaReg;
	private String horaReg;
	private String usuarioReg;
	public String getCodigoComercio() {
		return codigoComercio;
	}
	public void setCodigoComercio(String codigoComercio) {
		this.codigoComercio = codigoComercio;
	}
	public String getOrigenTranx() {
		return origenTranx;
	}
	public void setOrigenTranx(String origenTranx) {
		this.origenTranx = origenTranx;
	}
	public String getNroRegistros() {
		return nroRegistros;
	}
	public void setNroRegistros(String nroRegistros) {
		this.nroRegistros = nroRegistros;
	}
	public String getFechaReg() {
		return fechaReg;
	}
	public void setFechaReg(String fechaReg) {
		this.fechaReg = fechaReg;
	}
	public String getHoraReg() {
		return horaReg;
	}
	public void setHoraReg(String horaReg) {
		this.horaReg = horaReg;
	}
	public String getUsuarioReg() {
		return usuarioReg;
	}
	public void setUsuarioReg(String usuarioReg) {
		this.usuarioReg = usuarioReg;
	}
	public DevolucionCabecera() {
		super();
	}

}
