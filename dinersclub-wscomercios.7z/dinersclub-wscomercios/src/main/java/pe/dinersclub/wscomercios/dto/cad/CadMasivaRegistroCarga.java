package pe.dinersclub.wscomercios.dto.cad;

public class CadMasivaRegistroCarga {

	private String codigoComercio;
	private String numeroTarjeta;
	private String anioVencimientoTarjeta;
	private String mesVencimientoTarjeta;
	private String codigoServicio;
	private String nombreUsuarioServicio;
	// private String tipoDocumentoIdentidadUsuarioServicio;
	private String numeroDocumentoIdentidadUsuarioServicio;
	private String telefono;
	private String email;
	private String tipoMantenimiento;
	private String codigoError;
	private String descripcionError;
	private String numeroRegistrosTotales;
	private String numeroRegistrosAfiliacion;
	private String numeroRegistrosDesafiliacion;
	private String fechaEnvio;
	private String montoTope;

	public String getCodigoComercio() {
		return codigoComercio;
	}

	public void setCodigoComercio(String codigoComercio) {
		this.codigoComercio = codigoComercio;
	}

	public String getNumeroTarjeta() {
		return numeroTarjeta;
	}

	public void setNumeroTarjeta(String numeroTarjeta) {
		this.numeroTarjeta = numeroTarjeta;
	}

	public String getAnioVencimientoTarjeta() {
		return anioVencimientoTarjeta;
	}

	public void setAnioVencimientoTarjeta(String anioVencimientoTarjeta) {
		this.anioVencimientoTarjeta = anioVencimientoTarjeta;
	}

	public String getMesVencimientoTarjeta() {
		return mesVencimientoTarjeta;
	}

	public void setMesVencimientoTarjeta(String mesVencimientoTarjeta) {
		this.mesVencimientoTarjeta = mesVencimientoTarjeta;
	}

	public String getCodigoServicio() {
		return codigoServicio;
	}

	public void setCodigoServicio(String codigoServicio) {
		this.codigoServicio = codigoServicio;
	}

	public String getNombreUsuarioServicio() {
		return nombreUsuarioServicio;
	}

	public void setNombreUsuarioServicio(String nombreUsuarioServicio) {
		this.nombreUsuarioServicio = nombreUsuarioServicio;
	}

	public String getNumeroDocumentoIdentidadUsuarioServicio() {
		return numeroDocumentoIdentidadUsuarioServicio;
	}

	public void setNumeroDocumentoIdentidadUsuarioServicio(String numeroDocumentoIdentidadUsuarioServicio) {
		this.numeroDocumentoIdentidadUsuarioServicio = numeroDocumentoIdentidadUsuarioServicio;
	}

	public String getTelefono() {
		return telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getTipoMantenimiento() {
		return tipoMantenimiento;
	}

	public void setTipoMantenimiento(String tipoMantenimiento) {
		this.tipoMantenimiento = tipoMantenimiento;
	}

	public String getCodigoError() {
		return codigoError;
	}

	public void setCodigoError(String codigoError) {
		this.codigoError = codigoError;
	}

	public String getDescripcionError() {
		return descripcionError;
	}

	public void setDescripcionError(String descripcionError) {
		this.descripcionError = descripcionError;
	}

	public String getNumeroRegistrosTotales() {
		return numeroRegistrosTotales;
	}

	public void setNumeroRegistrosTotales(String numeroRegistrosTotales) {
		this.numeroRegistrosTotales = numeroRegistrosTotales;
	}

	public String getNumeroRegistrosAfiliacion() {
		return numeroRegistrosAfiliacion;
	}

	public void setNumeroRegistrosAfiliacion(String numeroRegistrosAfiliacion) {
		this.numeroRegistrosAfiliacion = numeroRegistrosAfiliacion;
	}

	public String getNumeroRegistrosDesafiliacion() {
		return numeroRegistrosDesafiliacion;
	}

	public void setNumeroRegistrosDesafiliacion(String numeroRegistrosDesafiliacion) {
		this.numeroRegistrosDesafiliacion = numeroRegistrosDesafiliacion;
	}

	public String getFechaEnvio() {
		return fechaEnvio;
	}

	public void setFechaEnvio(String fechaEnvio) {
		this.fechaEnvio = fechaEnvio;
	}

	public String getMontoTope() {
		return montoTope;
	}

	public void setMontoTope(String montoTope) {
		this.montoTope = montoTope;
	}

}
