package pe.dinersclub.wscomercios.dto.cad;

import java.util.List;

public class CadSolicitudesDinersDescarga {

	private Integer cantidadRegistros;
	private Integer cantidadSolicitudesAfiliacion;
	private Integer cantidadSolicitudesDesafiliacion;
	private List<CadSolicitudDiners> cadSolicitudesDiners;

	public Integer getCantidadRegistros() {
		return cantidadRegistros;
	}

	public void setCantidadRegistros(Integer cantidadRegistros) {
		this.cantidadRegistros = cantidadRegistros;
	}

	public Integer getCantidadSolicitudesAfiliacion() {
		return cantidadSolicitudesAfiliacion;
	}

	public void setCantidadSolicitudesAfiliacion(Integer cantidadSolicitudesAfiliacion) {
		this.cantidadSolicitudesAfiliacion = cantidadSolicitudesAfiliacion;
	}

	public Integer getCantidadSolicitudesDesafiliacion() {
		return cantidadSolicitudesDesafiliacion;
	}

	public void setCantidadSolicitudesDesafiliacion(Integer cantidadSolicitudesDesafiliacion) {
		this.cantidadSolicitudesDesafiliacion = cantidadSolicitudesDesafiliacion;
	}

	public List<CadSolicitudDiners> getCadSolicitudesDiners() {
		return cadSolicitudesDiners;
	}

	public void setCadSolicitudesDiners(List<CadSolicitudDiners> cadSolicitudesDiners) {
		this.cadSolicitudesDiners = cadSolicitudesDiners;
	}

}
