package pe.dinersclub.wscomercios.domain;

import java.util.List;

public class ConsumosResponse {

	private List<ConsumoResp> listaConsumos;

	public List<ConsumoResp> getListaConsumos() {
		return listaConsumos;
	}

	public void setListaConsumos(List<ConsumoResp> listaConsumos) {
		this.listaConsumos = listaConsumos;
	}
	
}
