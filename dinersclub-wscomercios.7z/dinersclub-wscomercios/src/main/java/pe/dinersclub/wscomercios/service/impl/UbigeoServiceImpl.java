package pe.dinersclub.wscomercios.service.impl;

import java.util.LinkedHashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pe.dinersclub.wscomercios.dao.UbigeoDAO;
import pe.dinersclub.wscomercios.service.UbigeoService;

@Service
public class UbigeoServiceImpl implements UbigeoService {

	@Autowired
	UbigeoDAO ubigeoDAO;
	
	
	@Override
	public LinkedHashMap<String, String> listarDepartamentos() {
		return (LinkedHashMap<String, String>) ubigeoDAO.listarDepartamentos();
	}

	@Override
	public LinkedHashMap<String, String> listarProvincias(String idDepartamento) {
		return (LinkedHashMap<String, String>) ubigeoDAO.listarProvincias(idDepartamento);
	}

	@Override
	public LinkedHashMap<String, String> listarDistritos(String idDepartamento, String idProvincia) {
		return (LinkedHashMap<String, String>) ubigeoDAO.listarDistritos(idDepartamento, idProvincia);
	}
	
}
