package pe.dinersclub.wscomercios.domain;

public class CadListarAfiliacionesRequest {

	private Long codigoComercio;
	private String codigoServicio;
	private Long numeroTarjeta;
	private String idEstadoServicio;
	private String usuarioServicio;
	private String idTipoDocumentoIdentidad;
	private String numeroDocumentoIdentidad;
	private String fechaInicio;
	private String fechaFin;
	private Integer page;
	private Integer xpage;

	public Long getCodigoComercio() {
		return codigoComercio;
	}

	public void setCodigoComercio(Long codigoComercio) {
		this.codigoComercio = codigoComercio;
	}

	public String getCodigoServicio() {
		return codigoServicio;
	}

	public void setCodigoServicio(String codigoServicio) {
		this.codigoServicio = codigoServicio;
	}

	public Long getNumeroTarjeta() {
		return numeroTarjeta;
	}

	public void setNumeroTarjeta(Long numeroTarjeta) {
		this.numeroTarjeta = numeroTarjeta;
	}

	public String getIdEstadoServicio() {
		return idEstadoServicio;
	}

	public void setIdEstadoServicio(String idEstadoServicio) {
		this.idEstadoServicio = idEstadoServicio;
	}

	public String getUsuarioServicio() {
		return usuarioServicio;
	}

	public void setUsuarioServicio(String usuarioServicio) {
		this.usuarioServicio = usuarioServicio;
	}

	public String getIdTipoDocumentoIdentidad() {
		return idTipoDocumentoIdentidad;
	}

	public void setIdTipoDocumentoIdentidad(String idTipoDocumentoIdentidad) {
		this.idTipoDocumentoIdentidad = idTipoDocumentoIdentidad;
	}

	public String getNumeroDocumentoIdentidad() {
		return numeroDocumentoIdentidad;
	}

	public void setNumeroDocumentoIdentidad(String numeroDocumentoIdentidad) {
		this.numeroDocumentoIdentidad = numeroDocumentoIdentidad;
	}

	public String getFechaInicio() {
		return fechaInicio;
	}

	public void setFechaInicio(String fechaInicio) {
		this.fechaInicio = fechaInicio;
	}

	public String getFechaFin() {
		return fechaFin;
	}

	public void setFechaFin(String fechaFin) {
		this.fechaFin = fechaFin;
	}

	public Integer getPage() {
		return page;
	}

	public void setPage(Integer page) {
		this.page = page;
	}

	public Integer getXpage() {
		return xpage;
	}

	public void setXpage(Integer xpage) {
		this.xpage = xpage;
	}

}
