package pe.dinersclub.wscomercios.util;

public class Test {

	public static void main(String[] args) {
		
	}

}
