package pe.dinersclub.wscomercios.domain;

public class CadDesafiliacionIndividualRequest {

	private Integer correlativoSolicitud;
	private Long codigoComercio;
	private String codigoServicio;
	private Long numeroTarjeta;

	public Integer getCorrelativoSolicitud() {
		return correlativoSolicitud;
	}

	public void setCorrelativoSolicitud(Integer correlativoSolicitud) {
		this.correlativoSolicitud = correlativoSolicitud;
	}

	public Long getCodigoComercio() {
		return codigoComercio;
	}

	public void setCodigoComercio(Long codigoComercio) {
		this.codigoComercio = codigoComercio;
	}

	public String getCodigoServicio() {
		return codigoServicio;
	}

	public void setCodigoServicio(String codigoServicio) {
		this.codigoServicio = codigoServicio;
	}

	public Long getNumeroTarjeta() {
		return numeroTarjeta;
	}

	public void setNumeroTarjeta(Long numeroTarjeta) {
		this.numeroTarjeta = numeroTarjeta;
	}

}
