package pe.dinersclub.wscomercios.service.impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pe.dinersclub.wscomercios.dao.CadDAO;
import pe.dinersclub.wscomercios.domain.BuscarTarjetaResponse;
import pe.dinersclub.wscomercios.domain.CadAfiliacionIndividualRequest;
import pe.dinersclub.wscomercios.domain.CadCargaMasivaResponse;
import pe.dinersclub.wscomercios.domain.CadDesafiliacionIndividualRequest;
import pe.dinersclub.wscomercios.domain.CadDescargaSolicitudesDinersRequest;
import pe.dinersclub.wscomercios.domain.CadListarAfiliacionesRequest;
import pe.dinersclub.wscomercios.domain.CadListarAfiliacionesResponse;
import pe.dinersclub.wscomercios.domain.CadSolicitudesDinersRequest;
import pe.dinersclub.wscomercios.domain.CadSolicitudesDinersResponse;
import pe.dinersclub.wscomercios.dto.cad.CadDatosTarjeta;
import pe.dinersclub.wscomercios.dto.cad.CadMasivaRegistroCarga;
import pe.dinersclub.wscomercios.dto.cad.CadMasivaRegistroRespuesta;
import pe.dinersclub.wscomercios.dto.cad.CadServicio;
import pe.dinersclub.wscomercios.dto.cad.CadSolicitudDiners;
import pe.dinersclub.wscomercios.dto.cad.CadSolicitudesDinersDescarga;
import pe.dinersclub.wscomercios.dto.cad.GrabaBolsaMantenimientoAS;
import pe.dinersclub.wscomercios.exception.ModeloNotFountException;
import pe.dinersclub.wscomercios.log.BeanLog;
import pe.dinersclub.wscomercios.log.UtilLog;
import pe.dinersclub.wscomercios.log.UtilLogLevel;
import pe.dinersclub.wscomercios.service.CadService;
import pe.dinersclub.wscomercios.service.FileStorageService;
import pe.dinersclub.wscomercios.util.Globales;
import pe.dinersclub.wscomercios.util.Util;
import pe.dinersclub.wscomercios.util.UtilDate;
import pe.dinersclub.wscomercios.util.UtilString;

@Service
public class CadServiceImpl implements CadService {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private UtilLog utilLog;

	@Autowired
	private CadDAO cadDao;

	@Autowired
	private FileStorageService fileStorageService;

	@Override
	public CadSolicitudesDinersResponse listarCadSolicitudesDiners(String identificador,
			CadSolicitudesDinersRequest cadSolicitudesDinersRequest) {

		CadSolicitudesDinersResponse cadSolicitudesDinersResponse = null;
		BeanLog beanLog = new BeanLog();
		beanLog.setIdentificador(identificador);
		beanLog.setMetodo(new Object() {
		}.getClass().getEnclosingMethod().getName());

		try {
			cadSolicitudesDinersResponse = cadDao.listarCadSolicitudesDiners(beanLog.getIdentificador(),
					cadSolicitudesDinersRequest);

			if (cadSolicitudesDinersResponse == null) {
				beanLog.setDescripcionMensaje(
						"No se obtuvieron resultados en la consulta de Solicitudes de Afiliacion Diners.");
				beanLog.setTipoMensaje(UtilLogLevel.INFO.name());
				utilLog.printInfo(logger, beanLog);
			}
		} catch (RuntimeException ex) {
			// asdasd
			throw ex;
		} catch (Exception ex) {
			// asdasd
		}

		return cadSolicitudesDinersResponse;
	}

	@Override
	public byte[] descargarCadSolicitudesDinersFormatoAfiliacionMasivaTxt(String identificador,
			CadDescargaSolicitudesDinersRequest cadDescargaSolicitudesDinersRequest) throws Exception {

		BeanLog beanLog = new BeanLog();
		beanLog.setIdentificador(identificador);
		beanLog.setMetodo(new Object() {
		}.getClass().getEnclosingMethod().getName());

		// File file = new File("C:\\sistemas\\pdf\\doc.txt");
		File file = File.createTempFile(UtilString.obtenerIdentificadorUnico(), ".txt");

		byte[] archivo = null;
		byte[] data = null;

		CadSolicitudesDinersDescarga cadSolicitudesDinersDescarga = cadDao
				.listarCadSolicitudesDinersDescarga(beanLog.getIdentificador(), cadDescargaSolicitudesDinersRequest);

		if (cadSolicitudesDinersDescarga != null) {
			// Se invoca al metodo que arma la estructura del archivo
			StringBuffer dataArchivo = obtenerDatosAfiliacionMasivaTxt(
					cadDescargaSolicitudesDinersRequest.getCodigoComercio(), cadSolicitudesDinersDescarga);

			if (dataArchivo.length() > 0) {

				data = dataArchivo.toString().getBytes(StandardCharsets.UTF_8);

				try (RandomAccessFile stream = new RandomAccessFile(file, "rw");
						FileChannel channel = stream.getChannel()) {
					ByteBuffer buffer = ByteBuffer.allocate(data.length);
					buffer.put(data);
					buffer.flip();
					channel.write(buffer);

					archivo = Files.readAllBytes(file.toPath());

				} catch (IOException ex) {
					beanLog.setDescripcionMensaje(ex.getMessage());
					beanLog.setCausa(ex.getCause() != null ? ex.getCause().getMessage() : "");
					beanLog.setTipoMensaje(UtilLogLevel.ERROR.name());
				}
			}
		}
		return archivo;

	}

	@Override
	public BuscarTarjetaResponse buscarTarjeta(String identificador, Long numeroTarjeta) {
		BeanLog beanLog = new BeanLog();
		beanLog.setIdentificador(identificador);
		beanLog.setMetodo(new Object() {
		}.getClass().getEnclosingMethod().getName());

		BuscarTarjetaResponse tarjetaResponse = null;

		CadDatosTarjeta datosTarjeta = cadDao.obtenerDatosTarjeta(beanLog.getIdentificador(), numeroTarjeta);

		if (datosTarjeta == null) {
			beanLog.setDescripcionMensaje("La consulta no devolvió resultados");
			beanLog.setTipoMensaje(UtilLogLevel.ERROR.name());
		}

		tarjetaResponse = Util.passCadDatosTarjetaToBuscarTarjetaResponse(datosTarjeta);

		return tarjetaResponse;
	}

	/*
	 * 
	 * Método privado que arma la estrutura del archivo de Solicitudes de Inscrión
	 * al CAD generado por dinerss El formato del archivo correspinde al de
	 * afiliación masiva
	 * 
	 */
	private StringBuffer obtenerDatosAfiliacionMasivaTxt(Long codigoComercio,
			CadSolicitudesDinersDescarga cadSolicitudesDinersDescarga) {

		StringBuffer dataArchivoAfiliacionMasiva = new StringBuffer();
		List<CadSolicitudDiners> cadSolicitudesDiners = cadSolicitudesDinersDescarga.getCadSolicitudesDiners();

		for (CadSolicitudDiners cadSolicitudDiners : cadSolicitudesDiners) {

			String numeroDocumento = (cadSolicitudDiners.getTipoDocumentoIdentidad().equals("1"))
					? cadSolicitudDiners.getNumeroDocumentoIdentidad().substring(4, 12)
					: cadSolicitudDiners.getNumeroDocumentoIdentidad().substring(1);

			String montoTope = UtilString.convertBigDecimaltoString(cadSolicitudDiners.getMontoTope());

			String linea = UtilString.rellenaDerecha(codigoComercio.toString(), ' ', 10)
					+ UtilString.rellenaDerecha(cadSolicitudDiners.getNumeroTarjeta().toString(), ' ', 14)
					+ UtilString.rellenaDerecha(cadSolicitudDiners.getAnioVencimiento(), ' ', 4)
					+ UtilString.rellenaDerecha(cadSolicitudDiners.getMesVencimiento(), ' ', 2)
					+ UtilString.rellenaDerecha(cadSolicitudDiners.getCodigoServicio(), ' ', 20)
					+ UtilString.rellenaDerecha(cadSolicitudDiners.getSocio(), ' ', 60)
					+ UtilString.rellenaDerecha(numeroDocumento, ' ', 11) + UtilString.rellenaDerecha("", ' ', 15)
					+ UtilString.rellenaDerecha("", ' ', 50)
					+ UtilString.rellenaDerecha(cadSolicitudDiners.getTipoSolicitud(), ' ', 1)
					+ UtilString.rellenaDerecha("", ' ', 3) + UtilString.rellenaDerecha("", ' ', 60)
					+ UtilString.rellenaIzquierda(cadSolicitudesDinersDescarga.getCantidadRegistros().toString(), '0',
							3)
					+ UtilString.rellenaIzquierda(
							cadSolicitudesDinersDescarga.getCantidadSolicitudesAfiliacion().toString(), '0', 3)
					+ UtilString.rellenaIzquierda(
							cadSolicitudesDinersDescarga.getCantidadSolicitudesDesafiliacion().toString(), '0', 3)
					+ UtilString.rellenaDerecha(UtilDate.fechaHoyYYYYMMDD(), '0', 8)
					+ UtilString.rellenaIzquierda(montoTope, '0', 10);

			dataArchivoAfiliacionMasiva.append(linea + "\n");
		}

		return dataArchivoAfiliacionMasiva;
	}

	@Override
	public String afiliarCadIndividual(String identificador,
			CadAfiliacionIndividualRequest cadAfiliacionIndividualRequest) {

		BeanLog beanLog = new BeanLog();
		beanLog.setIdentificador(identificador);
		beanLog.setMetodo(new Object() {
		}.getClass().getEnclosingMethod().getName());

		String respuestaAfiliacion = "";

		CadServicio cadServicio = null;

		cadServicio = cadDao.obtenerServicioCad(identificador, cadAfiliacionIndividualRequest.getCodigoComercio(),
				cadAfiliacionIndividualRequest.getCodigoServicio(), null);

		if (cadServicio != null) {
			throw new ModeloNotFountException(Globales.SERVICIO_SE_ENCUENTRA_AFILIADO, identificador);
		}

		cadServicio = cadDao.obtenerServicioCad(identificador, cadAfiliacionIndividualRequest.getCodigoComercio(),
				cadAfiliacionIndividualRequest.getCodigoServicio(), cadAfiliacionIndividualRequest.getNumeroTarjeta());

		if (cadServicio != null) {
			throw new ModeloNotFountException(Globales.SERVICIO_EN_ESTADO_DESAFILIADO, identificador);
		}

		CadDatosTarjeta datosTarjeta = cadDao.obtenerDatosTarjeta(identificador, cadAfiliacionIndividualRequest.getNumeroTarjeta());

		if (datosTarjeta == null) {
			throw new ModeloNotFountException(Globales.TARJETA_NO_EXISTE, identificador);
		}

		cadServicio= new CadServicio();
		cadServicio.setNumeroCuenta(datosTarjeta.getNumeroCuenta());
		cadServicio.setFlagCargoAutomatico(Globales.CAD_SERVICIO_NO_ES_PROCESO_EN_AUTOMATICO);
		cadServicio.setFechaAfiliacion(UtilDate.fechaHoyYYYYMMDD());
		cadServicio.setOrigenAfiliacion("E");
		cadServicio.setEstadoAfiliacion("0");

		try {
			String trama = UtilString.rellenaIzquierda(
					cadServicio.getNumeroCuenta() == null ? "" : cadServicio.getNumeroCuenta().toString(), ' ', 19)
					+ UtilString.rellenaIzquierda(cadServicio.getCodigoComercio().toString(), ' ', 10)
					+ UtilString.rellenaDerecha(cadServicio.getCodigoServicio(), ' ', 20)
					+ UtilString.rellenaIzquierda(cadServicio.getItem() == null ? "" : cadServicio.getItem().toString(),
							' ', 3)
					+ UtilString.rellenaIzquierda(cadServicio.getNumeroTarjeta().toString(), ' ', 19)
					+ UtilString.rellenaIzquierda(cadServicio.getAnioVencimientoTarjeta(), ' ', 4)
					+ UtilString.rellenaIzquierda(cadServicio.getMesVencimientoTarjeta(), ' ', 2)
					+ UtilString.rellenaDerecha(cadServicio.getNombreUsuarioServicio().toUpperCase(), ' ', 60)
					+ UtilString.rellenaIzquierda(cadServicio.getTipoDocumentoIdentidadUsuarioServicio(), ' ', 2)
					+ UtilString.rellenaDerecha(cadServicio.getNumeroDocumentoIdentidadUsuarioServicio(), ' ', 11)
					+ UtilString.rellenaDerecha(cadServicio.getTelefono(), ' ', 15)
					+ UtilString.rellenaDerecha(cadServicio.getEmail(), ' ', 60)
					+ UtilString.rellenaIzquierda(
							cadServicio.getFechaAfiliacion() == null ? "" : cadServicio.getFechaAfiliacion(), ' ', 8)
					+ UtilString.rellenaIzquierda(
							cadServicio.getFechaDesafiliacion() == null ? "" : cadServicio.getFechaDesafiliacion(), ' ',
							8)
					+ UtilString.rellenaIzquierda(cadServicio.getFlagCargoAutomatico(), ' ', 1)
					+ UtilString.rellenaIzquierda(
							cadServicio.getFechaPrimerCargo() == null ? "" : cadServicio.getFechaPrimerCargo(), ' ', 8)
					+ UtilString.rellenaIzquierda(
							cadServicio.getFechaProximoCargo() == null ? "" : cadServicio.getFechaProximoCargo(), ' ',
							8)
					+ UtilString.rellenaIzquierda(
							cadServicio.getFechaFinCargo() == null ? "" : cadServicio.getFechaFinCargo(), ' ', 8)
					+ UtilString.rellenaIzquierda(cadServicio.getMoneda() == null ? "" : cadServicio.getMoneda(), ' ',
							1)
					+ UtilString
							.rellenaIzquierda(
									cadServicio.getImporteCargoAutomatico() == null ? ""
											: UtilString
													.convertBigDecimaltoString(cadServicio.getImporteCargoAutomatico()),
									' ', 9)
					+ UtilString.rellenaIzquierda(cadServicio.getOrigenAfiliacion(), ' ', 1)
					+ UtilString.rellenaIzquierda(cadServicio.getEstadoAfiliacion(), ' ', 1)
					+ UtilString.rellenaDerecha("", ' ', 20) + UtilString.rellenaDerecha("WEBCAD", ' ', 10)
					+ UtilString.rellenaIzquierda(UtilString.convertBigDecimaltoString(cadServicio.getMontoTope()), ' ',
							10);

			respuestaAfiliacion = cadDao.guardarAfiliacionIndividual(identificador, trama, "");

		} catch (Exception ex) {
			beanLog.setDescripcionMensaje(ex.getMessage());
			beanLog.setCausa(ex.getCause() != null ? ex.getCause().getMessage() : "");
			beanLog.setTipoMensaje(UtilLogLevel.ERROR.name());
		}

		return respuestaAfiliacion;
	}

	@Override
	public String desafiliarCadIndividual(String identificador,
			CadDesafiliacionIndividualRequest cadDesafiliacionIndividualRequest) {

		BeanLog beanLog = new BeanLog();
		beanLog.setIdentificador(identificador);
		beanLog.setMetodo(new Object() {
		}.getClass().getEnclosingMethod().getName());

		String respuestaDesafiliacion = "";

		CadServicio cadServicio = null;

		cadServicio = cadDao.obtenerServicioCad(identificador, cadDesafiliacionIndividualRequest.getCodigoComercio(),
				cadDesafiliacionIndividualRequest.getCodigoServicio(), null);

		if (cadServicio == null) {
			respuestaDesafiliacion = Globales.SERVICIO_NO_SE_ENCUENTRA_AFILIADO_AL_CAD;
			return respuestaDesafiliacion;
		}
		if (!cadServicio.getNumeroTarjeta().equals(cadDesafiliacionIndividualRequest.getNumeroTarjeta())) {
			respuestaDesafiliacion = Globales.TARJETA_NO_CORRESPONDE_AL_SERVICIO;
			return respuestaDesafiliacion;
		}

		CadDatosTarjeta datosTarjeta = cadDao.obtenerDatosTarjeta(identificador, cadServicio.getNumeroTarjeta());

		if (datosTarjeta == null) {
			respuestaDesafiliacion = Globales.TARJETA_NO_EXISTE;
			return respuestaDesafiliacion;
		}

		cadServicio.setNumeroCuenta(datosTarjeta.getNumeroCuenta());

		try {
			String trama = UtilString.rellenaIzquierda(
					cadServicio.getNumeroCuenta() == null ? "" : cadServicio.getNumeroCuenta().toString(), ' ', 19)
					+ UtilString.rellenaIzquierda(cadServicio.getCodigoComercio().toString(), ' ', 10)
					+ UtilString.rellenaDerecha(cadServicio.getCodigoServicio(), ' ', 20)
					+ UtilString.rellenaIzquierda(cadServicio.getItem() == null ? "" : cadServicio.getItem().toString(),
							' ', 3)
					+ UtilString.rellenaIzquierda(cadServicio.getNumeroTarjeta().toString(), ' ', 19)
					+ UtilString.rellenaIzquierda(cadServicio.getAnioVencimientoTarjeta(), ' ', 4)
					+ UtilString.rellenaIzquierda(cadServicio.getMesVencimientoTarjeta(), ' ', 2)
					+ UtilString.rellenaDerecha(cadServicio.getNombreUsuarioServicio().toUpperCase(), ' ', 60)
					+ UtilString.rellenaIzquierda(cadServicio.getTipoDocumentoIdentidadUsuarioServicio(), ' ', 2)
					+ UtilString.rellenaDerecha(cadServicio.getNumeroDocumentoIdentidadUsuarioServicio(), ' ', 11)
					+ UtilString.rellenaDerecha(cadServicio.getTelefono(), ' ', 15)
					+ UtilString.rellenaDerecha(cadServicio.getEmail(), ' ', 60)
					+ UtilString.rellenaIzquierda(
							cadServicio.getFechaAfiliacion() == null ? "" : cadServicio.getFechaAfiliacion(), ' ', 8)
					+ UtilString.rellenaIzquierda(
							cadServicio.getFechaDesafiliacion() == null ? "" : cadServicio.getFechaDesafiliacion(), ' ',
							8)
					+ UtilString.rellenaIzquierda(cadServicio.getFlagCargoAutomatico(), ' ', 1)
					+ UtilString.rellenaIzquierda(
							cadServicio.getFechaPrimerCargo() == null ? "" : cadServicio.getFechaPrimerCargo(), ' ', 8)
					+ UtilString.rellenaIzquierda(
							cadServicio.getFechaProximoCargo() == null ? "" : cadServicio.getFechaProximoCargo(), ' ',
							8)
					+ UtilString.rellenaIzquierda(
							cadServicio.getFechaFinCargo() == null ? "" : cadServicio.getFechaFinCargo(), ' ', 8)
					+ UtilString.rellenaIzquierda(cadServicio.getMoneda() == null ? "" : cadServicio.getMoneda(), ' ',
							1)
					+ UtilString
							.rellenaIzquierda(
									cadServicio.getImporteCargoAutomatico() == null ? ""
											: UtilString
													.convertBigDecimaltoString(cadServicio.getImporteCargoAutomatico()),
									' ', 9)
					+ UtilString.rellenaIzquierda(cadServicio.getOrigenAfiliacion(), ' ', 1)
					+ UtilString.rellenaIzquierda(Globales.CAD_ESTADO_DESAFILIADO, ' ', 1)
					+ UtilString.rellenaDerecha("", ' ', 20) + UtilString.rellenaDerecha("WEBCAD", ' ', 10)
					+ UtilString.rellenaIzquierda(UtilString.convertBigDecimaltoString(cadServicio.getMontoTope()), ' ',
							10);

			respuestaDesafiliacion = cadDao.guardarAfiliacionIndividual(identificador, trama, "");

		} catch (Exception ex) {
			beanLog.setDescripcionMensaje(ex.getMessage());
			beanLog.setCausa(ex.getCause() != null ? ex.getCause().getMessage() : "");
			beanLog.setTipoMensaje(UtilLogLevel.ERROR.name());
		}

		return respuestaDesafiliacion;
	}

	@Override
	public CadListarAfiliacionesResponse listarCadAfiliaciones(String identificador,
			CadListarAfiliacionesRequest cadListarAfiliacionesRequest) {

		CadListarAfiliacionesResponse cadListarAfiliacionesResponse = null;
		BeanLog beanLog = new BeanLog();
		beanLog.setIdentificador(identificador);
		beanLog.setMetodo(new Object() {
		}.getClass().getEnclosingMethod().getName());

		cadListarAfiliacionesResponse = cadDao.listarCadAfiliaciones(identificador, cadListarAfiliacionesRequest);

		if (cadListarAfiliacionesResponse == null) {
			beanLog.setDescripcionMensaje("No se obtuvieron resultados en la consulta de Afiliaciones.");
			beanLog.setTipoMensaje(UtilLogLevel.INFO.name());
			utilLog.printInfo(logger, beanLog);
		}

		return cadListarAfiliacionesResponse;
	}

	@Override
	public String obtenerCorrelativoArchivoBolsaMantenimiento(String identificador, String tipoBolsa) {
		String correlativo = null;
		BeanLog beanLog = new BeanLog();
		beanLog.setIdentificador(identificador);
		beanLog.setMetodo(new Object() {
		}.getClass().getEnclosingMethod().getName());

		correlativo = cadDao.obtenerCorrelativoBolsa(identificador, tipoBolsa);

		if (correlativo == null) {
			beanLog.setDescripcionMensaje("Ocurrió un problema al obtener el correlativo.");
			beanLog.setTipoMensaje(UtilLogLevel.INFO.name());
			utilLog.printInfo(logger, beanLog);
		}

		return correlativo;

	}

	@Override
	public CadCargaMasivaResponse PrecargaMasiva(Long codigoComercio, String tipoMantenimiento, String nombreArchivo,
			String identificador) {

		CadCargaMasivaResponse cadCargaMasivaResponse = new CadCargaMasivaResponse();
		BeanLog beanLog = new BeanLog();
		beanLog.setIdentificador(identificador);
		beanLog.setMetodo(new Object() {
		}.getClass().getEnclosingMethod().getName());

		int totalRegistros = 0;
		int totalAfiliaciones = 0;
		int totalDesafiliaciones = 0;
		int registrosCorrectos = 0;
		int registrosFallidos = 0;

		List<CadMasivaRegistroCarga> registrosCarga = null;
		List<CadMasivaRegistroRespuesta> registrosRespuesta = new ArrayList<CadMasivaRegistroRespuesta>();

		CadMasivaRegistroRespuesta registroRespuesta = null;
		GrabaBolsaMantenimientoAS grabaBolsaMantenimientoAS = null;

		String extension = "";
		int i = nombreArchivo.lastIndexOf('.');
		if (i >= 0) {
			extension = nombreArchivo.substring(i + 1);
		}

		if (extension.equals("txt")) {
			registrosCarga = obtenerDatosArchivoTxt(codigoComercio, tipoMantenimiento, nombreArchivo, identificador);
		} else {
			registrosCarga = obtenerDatosArchivoExcel(codigoComercio, tipoMantenimiento, nombreArchivo, identificador);
		}

		int nLinea = 1;
		for (CadMasivaRegistroCarga registroCarga : registrosCarga) {

			// 1. se realizan las validaciones
			validaEstructuraDatosCadMasiva(registroCarga, identificador, nLinea, tipoMantenimiento, codigoComercio,
					registrosCarga.size());

			/*
			 * 2. Validaciónes de datos *
			 */

			// 2.1 Validar la existencia del servicio

			CadServicio cadServicioAfil = cadDao.obtenerServicioCad(identificador, codigoComercio,
					registroCarga.getCodigoServicio(), null);

			CadServicio cadServicioDesafil = cadDao.obtenerServicioCad(identificador, codigoComercio,
					registroCarga.getCodigoServicio(), Long.valueOf(registroCarga.getNumeroTarjeta()));

			if (cadServicioAfil != null && registroCarga.getTipoMantenimiento().equals("A")) {
				registroCarga.setCodigoError(Globales.SERVICIO_SE_ENCUENTRA_AFILIADO);
				registroCarga.setDescripcionError("SERVICIO SE ENCUENTRA AFILIADO AL CAD");
			} else if (cadServicioDesafil != null && registroCarga.getTipoMantenimiento().equals("D")) {
				registroCarga.setCodigoError(Globales.SERVICIO_EN_ESTADO_DESAFILIADO);
				registroCarga.setDescripcionError("SERVICIO SE ENCUENTRA DESAFILIADO ");
			}

			// 2.2 Validar la existencia de la tarjeta

			CadDatosTarjeta datosTarjeta = cadDao.obtenerDatosTarjeta(identificador,
					Long.valueOf(registroCarga.getNumeroTarjeta()));

			if (registroCarga.getCodigoError().trim().equals("000") && datosTarjeta == null) {
				registroCarga.setCodigoError(Globales.TARJETA_NO_EXISTE);
				registroCarga.setDescripcionError("TARJETA NO EXISTE");
			}

			// 2.3 Validar el estado de la tarjeta

			if (registroCarga.getCodigoError().trim().equals("000") && !datosTarjeta.isActivo()) {
				registroCarga.setCodigoError(Globales.TARJETA_NO_ACTIVA);
				registroCarga.setDescripcionError("TARJETA NO ACTIVA");
			}

			// 2.4 Validar vencimiento enviado

			if (registroCarga.getCodigoError().trim().equals("000")
					&& !registroCarga.getAnioVencimientoTarjeta().equals(datosTarjeta.getAnioVencimiento())
					&& !registroCarga.getMesVencimientoTarjeta().equals(datosTarjeta.getMesVencimiento())) {
				registroCarga.setCodigoError(Globales.VENCIMIENTO_TARJETA_NO_VALIDO);
				registroCarga.setDescripcionError("VENCIMIENTO DE TARJETA INCORRECTO");
			}

			if (registroCarga.getCodigoError().trim().equals("000")
					&& UtilDate.convertStringToDate(datosTarjeta.getFechaVencimiento(), "yyyyMMdd")
							.before(UtilDate.convertStringToDate(UtilDate.fechaHoyYYYYMMDD(), "yyyyMMdd"))) {
				registroCarga.setCodigoError(Globales.TARJETA_VENCIDA);
				registroCarga.setDescripcionError("TARJETA VENCIDA");
			}

			if (registroCarga.getCodigoError().trim().equals("000")) {
				registrosCorrectos++;
			} else {
				registrosFallidos++;
			}

			if (registroCarga.getTipoMantenimiento().equals(Globales.CAD_FLAG_SOLICITUD_AFILIACION)) {
				totalAfiliaciones++;
			} else {
				totalDesafiliaciones++;
			}

			totalRegistros++;
			nLinea++;
			// registrosCarga.add(registroCarga);

			// llenamos los valores de retorno

			registroRespuesta = Util.passCadMasivaRegistroCargaToCadMasivaRegistroRespuesta(registroCarga);
			registrosRespuesta.add(registroRespuesta);

		}

		cadCargaMasivaResponse.setNumeroRegistros(totalRegistros);
		cadCargaMasivaResponse.setRegistrosCorrectos(registrosCorrectos);
		cadCargaMasivaResponse.setRegistrosFallidos(registrosFallidos);
		cadCargaMasivaResponse.setRegistrosDetalle(registrosRespuesta);

		/*
		 * Si hay registros fallidos se asigna el correlativo que se asignó al nombre
		 * del archivo
		 */

		String[] correlativoError = nombreArchivo.replace(".", "-").split("-");
		if (registrosFallidos > 0) {
			cadCargaMasivaResponse.setCodigoPrecarga(new Integer(correlativoError[0]));
		}

		/*
		 * Si todas las validaciones son correctas se procede a guardar la precarga
		 */

		if (totalRegistros == registrosCorrectos) {
			String tramaBolsaMantenimiento = "00000" + UtilString.rellenaIzquierda("" + totalRegistros, '0', 3)
					+ UtilString.rellenaIzquierda("" + totalAfiliaciones, '0', 3)
					+ UtilString.rellenaIzquierda("" + totalDesafiliaciones, '0', 3) + UtilDate.fechaHoyYYYYMMDD()
					+ UtilDate.horaActualHHMMSS() + codigoComercio;

			grabaBolsaMantenimientoAS = cadDao.grabarBolsaMantemiento(identificador, tramaBolsaMantenimiento);

			cadCargaMasivaResponse
					.setCodigoPrecarga(new Integer(grabaBolsaMantenimientoAS.getTramaGrabaBolsa().substring(0, 5)));

			if (grabaBolsaMantenimientoAS != null) {

				for (CadMasivaRegistroCarga detalle : registrosCarga) {

					String tramaDetalleBolsa = grabaBolsaMantenimientoAS.getTramaGrabaBolsa().substring(0, 5)
							+ UtilString.generaEspaciosBlancos(3) + UtilString.generaEspaciosBlancos(5)
							+ detalle.getNumeroTarjeta() + detalle.getAnioVencimientoTarjeta()
							+ detalle.getMesVencimientoTarjeta()
							+ UtilString.rellenaDerecha(detalle.getNombreUsuarioServicio(), ' ', 60)
							+ UtilString.generaEspaciosBlancos(2)
							+ UtilString.rellenaDerecha(detalle.getNumeroDocumentoIdentidadUsuarioServicio(), ' ', 11)
							+ UtilString.rellenaDerecha((detalle.getTelefono() == null) ? "" : detalle.getTelefono(),
									' ', 15)
							+ UtilString.rellenaDerecha((detalle.getEmail() == null) ? "" : detalle.getEmail(), ' ', 50)
							+ detalle.getTipoMantenimiento() + UtilString.generaEspaciosBlancos(3)
							+ UtilString.generaEspaciosBlancos(19)
							+ UtilString.rellenaDerecha(detalle.getCodigoServicio(), ' ', 20)
							+ UtilString.rellenaIzquierda(detalle.getMontoTope(), ' ', 10);

					String tramaDetalleRespuesta = cadDao.grabarDetalleBolsaMantenimiento(identificador,
							tramaDetalleBolsa);

					if (!tramaDetalleRespuesta.equals("00000")) {
						registroRespuesta.setCodigoError(tramaDetalleRespuesta.substring(3, 5));
					}

				}
			}
		}

		return cadCargaMasivaResponse;
	}

	/**
	 * 
	 * 
	 * METODOS CON PROPÓSITO GENERAL
	 * 
	 * 
	 */

	private List<CadMasivaRegistroCarga> obtenerDatosArchivoTxt(Long codigoComercio, String tipoMantenimiento,
			String nombreArchivo, String identificador) {

		BeanLog beanLog = new BeanLog();
		beanLog.setIdentificador(identificador);
		beanLog.setMetodo(new Object() {
		}.getClass().getEnclosingMethod().getName());

		List<CadMasivaRegistroCarga> registrosCarga = new ArrayList<CadMasivaRegistroCarga>();
		CadMasivaRegistroCarga registroCarga = null;

		Path filePath = fileStorageService.loadFileAsPath(nombreArchivo, identificador);

		List<String> lineas = new ArrayList<>();
		try {
			lineas = Files.readAllLines(filePath);
		} catch (IOException e) {
			beanLog.setCodigoMensaje(Globales.PROBLEMA_AL_PROCESAR_EL_ARCHIVO);
			beanLog.setDescripcionMensaje("PROBLEMA_AL_PROCESAR_EL_ARCHIVO.");
			beanLog.setTipoMensaje(UtilLogLevel.INFO.name());
			utilLog.printInfo(logger, beanLog);
			throw new ModeloNotFountException(beanLog.getCodigoMensaje(), identificador);
		}

		// Validamos si al menos existe una línea en el archivo.
		if (lineas.size() == 0) {
			beanLog.setCodigoMensaje(Globales.ARCHIVO_SIN_REGISTROS);
			beanLog.setDescripcionMensaje("ARCHIVO_SIN_REGISTROS.");
			beanLog.setTipoMensaje(UtilLogLevel.INFO.name());
			utilLog.printInfo(logger, beanLog);
			throw new ModeloNotFountException(beanLog.getCodigoMensaje(), identificador);
		}

		int nLinea = 1;

		for (String linea : lineas) {

			/*
			 * Valdiación deL ARCHIVO
			 */

			registroCarga = new CadMasivaRegistroCarga();
			// Se valida la longitud del registro
			if (linea.length() < 267) {
				beanLog.setCodigoMensaje(Globales.ARCHIVO_CON_ERROR_DE_ESTRUCTURA);
				beanLog.setDescripcionMensaje("ARCHIVO_CON_ERROR_DE_ESTRUCTURA. " + "Error en línea: " + nLinea);
				beanLog.setTipoMensaje(UtilLogLevel.INFO.name());
				utilLog.printInfo(logger, beanLog);
				throw new ModeloNotFountException(beanLog.getCodigoMensaje(), identificador);
			}

			// 1.3 llenamos los datos para el objeto registroCarga

			registroCarga.setCodigoComercio(linea.substring(0, 10).trim());
			registroCarga.setNumeroTarjeta(linea.substring(10, 24).trim());
			registroCarga.setAnioVencimientoTarjeta(linea.substring(24, 28).trim());
			registroCarga.setMesVencimientoTarjeta(linea.substring(28, 30).trim());
			registroCarga.setCodigoServicio(linea.substring(30, 50).trim());
			registroCarga.setNombreUsuarioServicio(linea.substring(50, 110).trim());
			registroCarga.setNumeroDocumentoIdentidadUsuarioServicio(linea.substring(110, 121).trim());
			registroCarga.setTelefono(linea.substring(121, 136).trim());
			registroCarga.setEmail(linea.substring(136, 186).trim());
			registroCarga.setTipoMantenimiento(linea.substring(186, 187).trim());
			registroCarga.setNumeroRegistrosTotales(linea.substring(250, 253).trim());
			registroCarga.setNumeroRegistrosAfiliacion(linea.substring(253, 256).trim());
			registroCarga.setNumeroRegistrosDesafiliacion(linea.substring(257, 259).trim());
			registroCarga.setFechaEnvio(linea.substring(259, 267).trim());
			registroCarga.setCodigoError(Globales.RESPUESTA_EXITO);
			registroCarga.setDescripcionError("");

			if (linea.length() == 267) {
				registroCarga.setMontoTope(Globales.MONTO_TOPE_DEFECTO);
			} else {
				registroCarga.setMontoTope(linea.substring(267, 277).trim());
			}

			registrosCarga.add(registroCarga);
		}

		return registrosCarga;
	}

	private List<CadMasivaRegistroCarga> obtenerDatosArchivoExcel(Long codigoComercio, String tipoMantenimiento,
			String nombreArchivo, String identificador) {

		BeanLog beanLog = new BeanLog();
		beanLog.setIdentificador(identificador);
		beanLog.setMetodo(new Object() {
		}.getClass().getEnclosingMethod().getName());

		List<CadMasivaRegistroCarga> registrosCarga = new ArrayList<CadMasivaRegistroCarga>();
		CadMasivaRegistroCarga registroCarga = null;
		FileInputStream fis = null;
		XSSFWorkbook wb = null;

		Path filePath = fileStorageService.loadFileAsPath(nombreArchivo, identificador);

		try {
			fis = new FileInputStream(filePath.toFile());
			wb = new XSSFWorkbook(fis);

			Sheet firstSheet = wb.getSheetAt(0);
			Iterator<Row> iterator = firstSheet.iterator();
			iterator.next();
			
			while (iterator.hasNext()) {
				Row nextRow = iterator.next();
				Iterator<Cell> cellIterator = nextRow.cellIterator();

				registroCarga = new CadMasivaRegistroCarga();

				while (cellIterator.hasNext()) {
					Cell nextCell = cellIterator.next();
					int columnIndex = nextCell.getColumnIndex();
					switch (columnIndex) {
					case 0:
						registroCarga.setCodigoComercio(nextCell.getStringCellValue());
						break;
					case 1:
						registroCarga.setNumeroTarjeta(nextCell.getStringCellValue());
						break;
					case 2:
						registroCarga.setAnioVencimientoTarjeta(nextCell.getStringCellValue());
						break;
					case 3:
						registroCarga.setMesVencimientoTarjeta(nextCell.getStringCellValue());
						break;
					case 4:
						registroCarga.setCodigoServicio(nextCell.getStringCellValue());
						break;
					case 5:
						registroCarga.setNombreUsuarioServicio(nextCell.getStringCellValue());
						break;
					case 6:
						registroCarga.setNumeroDocumentoIdentidadUsuarioServicio(nextCell.getStringCellValue());
						break;
					case 7:
						registroCarga.setTelefono(nextCell.getStringCellValue());
						break;
					case 8:
						registroCarga.setEmail(nextCell.getStringCellValue());
						break;
					case 9:
						registroCarga.setTipoMantenimiento(nextCell.getStringCellValue());
						break;
					case 10:
						break;
					case 11:
						break;
					case 12:
						registroCarga.setNumeroRegistrosTotales(nextCell.getStringCellValue());
						break;
					case 13:
						registroCarga.setNumeroRegistrosAfiliacion(nextCell.getStringCellValue());
						break;
					case 14:
						registroCarga.setNumeroRegistrosDesafiliacion(nextCell.getStringCellValue());
						break;
					case 15:
						registroCarga.setFechaEnvio(nextCell.getStringCellValue());
						break;
					case 16:
						registroCarga.setMontoTope(nextCell.getStringCellValue());
						break;
					}
					registroCarga.setCodigoError(Globales.RESPUESTA_EXITO);
					registroCarga.setDescripcionError("");
					if (registroCarga.getMontoTope() == null) {
						registroCarga.setMontoTope(Globales.MONTO_TOPE_DEFECTO);
					} 

				}
				registrosCarga.add(registroCarga);
			}

		} catch (FileNotFoundException e) {
			beanLog.setCodigoMensaje(Globales.PROBLEMA_AL_PROCESAR_EL_ARCHIVO);
			beanLog.setDescripcionMensaje("PROBLEMA_AL_PROCESAR_EL_ARCHIVO.");
			beanLog.setTipoMensaje(UtilLogLevel.INFO.name());
			utilLog.printInfo(logger, beanLog);
			throw new ModeloNotFountException(beanLog.getCodigoMensaje(), identificador);
		} catch (IOException e) {
			beanLog.setCodigoMensaje(Globales.PROBLEMA_AL_PROCESAR_EL_ARCHIVO);
			beanLog.setDescripcionMensaje("PROBLEMA_AL_PROCESAR_EL_ARCHIVO.");
			beanLog.setTipoMensaje(UtilLogLevel.INFO.name());
			utilLog.printInfo(logger, beanLog);
			throw new ModeloNotFountException(beanLog.getCodigoMensaje(), identificador);
		} finally {
			try {
				wb.close();
				fis.close();
			} catch (IOException e) {
				beanLog.setCodigoMensaje(Globales.PROBLEMA_AL_PROCESAR_EL_ARCHIVO);
				beanLog.setDescripcionMensaje("PROBLEMA_AL_PROCESAR_EL_ARCHIVO.");
				beanLog.setTipoMensaje(UtilLogLevel.INFO.name());
				utilLog.printInfo(logger, beanLog);
				throw new ModeloNotFountException(beanLog.getCodigoMensaje(), identificador);
			}

		}

		if (registrosCarga.size() == 0) {
			beanLog.setCodigoMensaje(Globales.ARCHIVO_SIN_REGISTROS);
			beanLog.setDescripcionMensaje("ARCHIVO_SIN_REGISTROS.");
			beanLog.setTipoMensaje(UtilLogLevel.INFO.name());
			utilLog.printInfo(logger, beanLog);
			throw new ModeloNotFountException(beanLog.getCodigoMensaje(), identificador);
		}

		return registrosCarga;
	}

	private void validaEstructuraDatosCadMasiva(CadMasivaRegistroCarga registroCarga, String identificador,
			Integer nLinea, String tipoMantenimiento, Long codigoComercio, Integer totalRegistros) {
		BeanLog beanLog = new BeanLog();
		beanLog.setIdentificador(identificador);
		beanLog.setMetodo(new Object() {
		}.getClass().getEnclosingMethod().getName());

		// 1 Se valida el tipo de Mantenimiento del registro con el solicitado

		if (!registroCarga.getTipoMantenimiento().equals(tipoMantenimiento)) {
			beanLog.setCodigoMensaje(Globales.TIPO_DE_MANTENIMIENTO_NO_CORRESPONDE_AL_SOLICITADO);
			beanLog.setDescripcionMensaje(
					"TIPO_DE_MANTENIMIENTO_NO_CORRESPONDE_AL_SOLICITADO. " + "Error en línea: " + nLinea);
			beanLog.setTipoMensaje(UtilLogLevel.INFO.name());
			utilLog.printInfo(logger, beanLog);
			throw new ModeloNotFountException(beanLog.getCodigoMensaje(), identificador);
		}

		// 2 validamos el código de comercio
		if (!registroCarga.getCodigoComercio().equals(codigoComercio.toString())) {
			beanLog.setCodigoMensaje(Globales.CODIGO_DE_COMERCIO_INCORRECTO);
			beanLog.setDescripcionMensaje("CODIGO_DE_COMERCIO_INCORRECTO. " + "Error en línea: " + nLinea);
			beanLog.setTipoMensaje(UtilLogLevel.INFO.name());
			utilLog.printInfo(logger, beanLog);
			throw new ModeloNotFountException(beanLog.getCodigoMensaje(), identificador);
		}

		// 3 Número de Tarjeta Numérico

		if (!UtilString.validarEsNumerico(registroCarga.getNumeroTarjeta())) {
			beanLog.setCodigoMensaje(Globales.NUMERO_DE_TARJETA_DEBE_SER_NUMERICO);
			beanLog.setDescripcionMensaje("NUMERO_DE_TARJETA_DEBE_SER_NUMERICO. " + "Error en línea: " + nLinea);
			beanLog.setTipoMensaje(UtilLogLevel.INFO.name());
			utilLog.printInfo(logger, beanLog);
			throw new ModeloNotFountException(beanLog.getCodigoMensaje(), identificador);
		}

		// 4 Código de servicio no debe ser enblanco

		if (UtilString.validarEsNuloOVacio(registroCarga.getCodigoServicio())) {
			beanLog.setCodigoMensaje(Globales.CODIGO_DE_SERVICIO_ES_BLANCO);
			beanLog.setDescripcionMensaje("CODIGO_DE_SERVICIO_ES_BLANCO. " + "Error en línea: " + nLinea);
			beanLog.setTipoMensaje(UtilLogLevel.INFO.name());
			utilLog.printInfo(logger, beanLog);
			throw new ModeloNotFountException(beanLog.getCodigoMensaje(), identificador);
		}

		// 5 Nombre de usuario de servicio no debe ser enblanco

		if (UtilString.validarEsNuloOVacio(registroCarga.getNombreUsuarioServicio())) {
			beanLog.setCodigoMensaje(Globales.NOMBRE_USUARIO_DE_SERVICIO_EN_BLANCO);
			beanLog.setDescripcionMensaje("NOMBRE_USUARIO_DE_SERVICIO_EN_BLANCO. " + "Error en línea: " + nLinea);
			beanLog.setTipoMensaje(UtilLogLevel.INFO.name());
			utilLog.printInfo(logger, beanLog);
			throw new ModeloNotFountException(beanLog.getCodigoMensaje(), identificador);
		}

		// 6 Número de documento debe ser de 8 a más dígitos

		if (registroCarga.getNumeroDocumentoIdentidadUsuarioServicio().length() < 8) {
			beanLog.setCodigoMensaje(Globales.LONGITUD_DOCUMENTO_MENOR_8_DIGITOS);
			beanLog.setDescripcionMensaje("LONGITUD_DOCUMENTO_MENOR_8_DIGITOS. " + "Error en línea: " + nLinea);
			beanLog.setTipoMensaje(UtilLogLevel.INFO.name());
			utilLog.printInfo(logger, beanLog);
			throw new ModeloNotFountException(beanLog.getCodigoMensaje(), identificador);
		}

		// 7 Validamos que el total de registros sea igual al indicado en la línea

		int rTotal = Integer.parseInt(registroCarga.getNumeroRegistrosTotales());

		if (rTotal != totalRegistros) {
			beanLog.setCodigoMensaje(Globales.NO_COINCIDE_NUMERO_DE_REGISTROS);
			beanLog.setDescripcionMensaje("NO_COINCIDE_NUMERO_DE_REGISTROS. " + "Error en línea: " + nLinea);
			beanLog.setTipoMensaje(UtilLogLevel.INFO.name());
			utilLog.printInfo(logger, beanLog);
			throw new ModeloNotFountException(beanLog.getCodigoMensaje(), identificador);
		}

		int rAfil = Integer.parseInt(registroCarga.getNumeroRegistrosTotales());

		if (tipoMantenimiento.equals("A") && rAfil != totalRegistros) {
			beanLog.setCodigoMensaje(Globales.NO_COINCIDE_NUMERO_DE_REGISTROS);
			beanLog.setDescripcionMensaje("NO_COINCIDE_NUMERO_DE_REGISTROS. " + "Error en línea: " + nLinea);
			beanLog.setTipoMensaje(UtilLogLevel.INFO.name());
			utilLog.printInfo(logger, beanLog);
			throw new ModeloNotFountException(beanLog.getCodigoMensaje(), identificador);
		}

		int rDesafil = Integer.parseInt(registroCarga.getNumeroRegistrosTotales());

		if (tipoMantenimiento.equals("D") && rDesafil != totalRegistros) {
			beanLog.setCodigoMensaje(Globales.NO_COINCIDE_NUMERO_DE_REGISTROS);
			beanLog.setDescripcionMensaje("NO_COINCIDE_NUMERO_DE_REGISTROS. " + "Error en línea: " + nLinea);
			beanLog.setTipoMensaje(UtilLogLevel.INFO.name());
			utilLog.printInfo(logger, beanLog);
			throw new ModeloNotFountException(beanLog.getCodigoMensaje(), identificador);
		}

		// 8 Monto Tope debe ser numérico

		if (!UtilString.validarEsNumerico(registroCarga.getMontoTope())) {
			beanLog.setCodigoMensaje(Globales.MONTO_TOPE_DEBE_SER_NUMERICO);
			beanLog.setDescripcionMensaje("MONTO_TOPE_DEBE_SER_NUMERICO. " + "Error en línea: " + nLinea);
			beanLog.setTipoMensaje(UtilLogLevel.INFO.name());
			utilLog.printInfo(logger, beanLog);
			throw new ModeloNotFountException(beanLog.getCodigoMensaje(), identificador);
		}

		// 9 Fecha de envío no debe ser mayor a hoy

		if (UtilDate.convertStringToDate(registroCarga.getFechaEnvio(), "yyyyMMdd")
				.after(UtilDate.convertStringToDate(UtilDate.fechaHoyYYYYMMDD(), "yyyyMMdd"))) {
			beanLog.setCodigoMensaje(Globales.FECHA_ENVIO_MAYOR_QUE_HOY);
			beanLog.setDescripcionMensaje("FECHA_ENVIO_MAYOR_QUE_HOY. " + "Error en línea: " + nLinea);
			beanLog.setTipoMensaje(UtilLogLevel.INFO.name());
			utilLog.printInfo(logger, beanLog);
			throw new ModeloNotFountException(beanLog.getCodigoMensaje(), identificador);
		}

	}

}
