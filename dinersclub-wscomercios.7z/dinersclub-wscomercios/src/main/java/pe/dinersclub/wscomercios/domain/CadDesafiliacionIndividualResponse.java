package pe.dinersclub.wscomercios.domain;

public class CadDesafiliacionIndividualResponse {

	private Integer correlativoSolicitud;
	private String codigoRespuesta;

	public Integer getCorrelativoSolicitud() {
		return correlativoSolicitud;
	}

	public void setCorrelativoSolicitud(Integer correlativoSolicitud) {
		this.correlativoSolicitud = correlativoSolicitud;
	}

	public String getCodigoRespuesta() {
		return codigoRespuesta;
	}

	public void setCodigoRespuesta(String codigoRespuesta) {
		this.codigoRespuesta = codigoRespuesta;
	}

}
