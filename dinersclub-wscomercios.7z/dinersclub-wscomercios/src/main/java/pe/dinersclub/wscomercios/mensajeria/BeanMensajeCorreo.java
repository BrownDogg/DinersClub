package pe.dinersclub.wscomercios.mensajeria;

import java.util.List;
import java.util.Map;

public class BeanMensajeCorreo {

	private String codigoMensaje;
	private Map<String, Object> parametros;
	private List<BeanCorreo> correos;

	public String getCodigoMensaje() {
		return codigoMensaje;
	}

	public void setCodigoMensaje(String codigoMensaje) {
		this.codigoMensaje = codigoMensaje;
	}

	public Map<String, Object> getParametros() {
		return parametros;
	}

	public void setParametros(Map<String, Object> parametros) {
		this.parametros = parametros;
	}

	public List<BeanCorreo> getCorreos() {
		return correos;
	}

	public void setCorreos(List<BeanCorreo> correos) {
		this.correos = correos;
	}

}
