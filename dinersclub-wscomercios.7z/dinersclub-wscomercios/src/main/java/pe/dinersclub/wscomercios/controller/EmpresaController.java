package pe.dinersclub.wscomercios.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.annotations.Api;
import pe.dinersclub.wscomercios.domain.BodyResponse;
import pe.dinersclub.wscomercios.domain.comercio.ComercioDomain;
import pe.dinersclub.wscomercios.domain.empresa.EmpresaDomain;
import pe.dinersclub.wscomercios.log.BeanLog;
import pe.dinersclub.wscomercios.service.EmpresaService;
import pe.dinersclub.wscomercios.util.Globales;
import pe.dinersclub.wscomercios.util.UtilAuditoria;
import pe.dinersclub.wscomercios.util.UtilDate;
import pe.dinersclub.wscomercios.util.UtilString;

@RestController
@Api(tags = { "Módulo Empresas" })
@RequestMapping("/empresas")
public class EmpresaController {

	@Autowired
	private HttpServletRequest request;
	@Autowired
	EmpresaService empresaService;
	@Autowired
	private UtilAuditoria utilAudit;

	@GetMapping(path = "", produces = "application/json")
	public ResponseEntity<Object> obtenerEmpresa(String rucEmpresa) {
		BeanLog beanLog = new BeanLog();
		long fechaInicio = UtilDate.getCurrentDateTime();
		String idTransaccion = UtilString.obtenerIdentificadorUnico();
		String metodo = new Object(){}.getClass().getEnclosingMethod().getName();
		beanLog = utilAudit.initLog(idTransaccion, request.getRequestURI(), metodo, true, "Obtener Empresa");
		EmpresaDomain empresa = null;
		
		try {
			empresa = empresaService.obtenerEmpresa(idTransaccion, rucEmpresa);
			if (empresa != null) {
				return new ResponseEntity<>(new BodyResponse<EmpresaDomain>(empresa, Globales.RESPUESTA_EXITO),
						HttpStatus.OK);
			} else {
				return new ResponseEntity<>(new BodyResponse<String>("No se encontró la empresa",
						Globales.ModuloEmpresa.EMPRESA_NO_ENCONTRADA), HttpStatus.BAD_REQUEST);
			}
		} catch (Exception e) {
			return new ResponseEntity<>(
					new BodyResponse<String>("Ocurrió un error en el proceso: " + e.getMessage(),
							Globales.RESPUESTA_ERROR_GENERICO),
					HttpStatus.EXPECTATION_FAILED);
		}finally {
			utilAudit.endLog(beanLog, fechaInicio);
		}
	}

	@GetMapping(value = "/{idEmpresa}", produces = "application/json")
	public ResponseEntity<Object> listarComerciosPorEmpresa(@PathVariable("idEmpresa") String idEmpresa) {
		BeanLog beanLog = new BeanLog();
		long fechaInicio = UtilDate.getCurrentDateTime();
		String idTransaccion = UtilString.obtenerIdentificadorUnico();
		String metodo = new Object(){}.getClass().getEnclosingMethod().getName();
		beanLog = utilAudit.initLog(idTransaccion, request.getRequestURI(), metodo, true, "Listar Comercios por Empresa");
		EmpresaDomain empresaDom = null;

		try {

			empresaDom = empresaService.listarDatosComercios(idTransaccion, idEmpresa);

			if (empresaDom != null && !empresaDom.getListaComercio().isEmpty()) {
				return new ResponseEntity<>(new BodyResponse<EmpresaDomain>(empresaDom, Globales.RESPUESTA_EXITO),
						HttpStatus.OK);
			} else if (empresaDom != null && empresaDom.getListaComercio().isEmpty()) {
				return new ResponseEntity<>(new BodyResponse<String>("No se encontraron Comercios",
						Globales.ModuloEmpresa.EMPRESA_NO_ENCONTRADA), HttpStatus.BAD_REQUEST);
			} else {
				return new ResponseEntity<>(new BodyResponse<String>("No se encontró la empresa",
						Globales.ModuloEmpresa.EMPRESA_NO_ENCONTRADA), HttpStatus.BAD_REQUEST);
			}

		} catch (Exception e) {
			return new ResponseEntity<>(
					new BodyResponse<String>("Ocurrió un error en el proceso: " + e.getMessage(),
							Globales.RESPUESTA_ERROR_GENERICO),
					HttpStatus.EXPECTATION_FAILED);
		}finally {
			utilAudit.endLog(beanLog, fechaInicio);
		}
	}

	@GetMapping(value = "/{rucEmpresa}/comercios")
	public ResponseEntity<Object> listarComercios(@PathVariable("rucEmpresa") String rucEmpresa) {
		BeanLog beanLog = new BeanLog();
		long fechaInicio = UtilDate.getCurrentDateTime();
		String idTransaccion = UtilString.obtenerIdentificadorUnico();
		String metodo = new Object(){}.getClass().getEnclosingMethod().getName();
		beanLog = utilAudit.initLog(idTransaccion, request.getRequestURI(), metodo, true, "Listar Comercios");
		List<ComercioDomain> listaComercios = null;
		
		try {

			listaComercios = empresaService.listarComercios(idTransaccion, rucEmpresa);

			if (!listaComercios.isEmpty()) {
				return new ResponseEntity<>(
						new BodyResponse<List<ComercioDomain>>(listaComercios, Globales.RESPUESTA_EXITO),
						HttpStatus.OK);
			} else {
				return new ResponseEntity<>(new BodyResponse<String>("No se encontraron comercios",
						Globales.ModuloEmpresa.COMERCIOS_NO_ENCONTRADOS), HttpStatus.BAD_REQUEST);
			}
		} catch (Exception e) {
			return new ResponseEntity<>(
					new BodyResponse<String>("Ocurrió un error en el proceso: " + e.getMessage(),
							Globales.RESPUESTA_ERROR_GENERICO),
					HttpStatus.EXPECTATION_FAILED);
		}finally {
			utilAudit.endLog(beanLog, fechaInicio);
		}
	}
}
