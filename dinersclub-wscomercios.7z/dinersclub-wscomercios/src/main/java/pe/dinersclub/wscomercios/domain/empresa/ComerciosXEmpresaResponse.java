package pe.dinersclub.wscomercios.domain.empresa;

public class ComerciosXEmpresaResponse {

	private EmpresaDomain datosEmp;

	public EmpresaDomain getDatosEmp() {
		return datosEmp;
	}

	public void setDatosEmp(EmpresaDomain datosEmp) {
		this.datosEmp = datosEmp;
	}
	
}
