package pe.dinersclub.wscomercios.domain;

import org.springframework.lang.Nullable;

public class BodyResponse<T> {

	private final String codigoRespuesta;
	@Nullable
	private final T detalle;

	public BodyResponse(@Nullable T detalle, String codigoRespuesta) {

		this.codigoRespuesta = codigoRespuesta;
		this.detalle = detalle;
	}

	public String getCodigoRespuesta() {
		return codigoRespuesta;
	}

	public T getDetalle() {
		return detalle;
	}

}
