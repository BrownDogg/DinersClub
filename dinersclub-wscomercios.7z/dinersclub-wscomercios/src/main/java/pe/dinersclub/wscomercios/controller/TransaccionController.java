package pe.dinersclub.wscomercios.controller;

import java.util.LinkedHashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import io.swagger.annotations.Api;
import pe.dinersclub.wscomercios.domain.BodyResponse;
import pe.dinersclub.wscomercios.domain.ConsumoResp;
import pe.dinersclub.wscomercios.domain.ConsumosRequest;
import pe.dinersclub.wscomercios.domain.EvolucionVentaRequest;
import pe.dinersclub.wscomercios.domain.EvolucionVentaResponse;
import pe.dinersclub.wscomercios.domain.transaccion.DevolucionDetalle;
import pe.dinersclub.wscomercios.domain.transaccion.DevolucionDomRequest;
import pe.dinersclub.wscomercios.domain.transaccion.DevolucionMasivaResponse;
import pe.dinersclub.wscomercios.domain.transaccion.VentaRequest;
import pe.dinersclub.wscomercios.domain.transaccion.VentaResponse;
import pe.dinersclub.wscomercios.dto.transacciones.DevolucionRespDTO;
import pe.dinersclub.wscomercios.exception.ModeloNotFountException;
import pe.dinersclub.wscomercios.log.BeanLog;
import pe.dinersclub.wscomercios.log.UtilLog;
import pe.dinersclub.wscomercios.security.bean.UsuarioAuthorization;
import pe.dinersclub.wscomercios.service.TransaccionService;
import pe.dinersclub.wscomercios.util.Globales;
import pe.dinersclub.wscomercios.util.UtilAuditoria;
import pe.dinersclub.wscomercios.util.UtilDate;
import pe.dinersclub.wscomercios.util.UtilString;

@RestController
@RequestMapping("/transacciones")
@Api(tags = { "Módulo de Transacciones" })
public class TransaccionController {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private TransaccionService transaccionService;
	@Autowired
	private HttpServletRequest request;
	@Autowired
	private UtilAuditoria utilAudit;

	@GetMapping(path = "/listar-ventas", produces = "application/json")
	public ResponseEntity<VentaResponse> listarVentas(@Valid @ModelAttribute VentaRequest ventaRequest,
			Authentication auth) {

		UsuarioAuthorization usuario = (UsuarioAuthorization) auth.getPrincipal();

		BeanLog beanLog = new BeanLog();
		beanLog.setIdEmpresa(usuario.getEmpresa());
		long fechaInicio = UtilDate.getCurrentDateTime();
		String idTransaccion = UtilString.obtenerIdentificadorUnico();
		String metodo = new Object() {
		}.getClass().getEnclosingMethod().getName();
		beanLog = utilAudit.initLog(idTransaccion, request.getRequestURI(), metodo, true,
				"Listar Liquidaciones Detalle");

		Long rucEmpresa = Long.valueOf(usuario.getEmpresa());

		/**
		 * Se validan las fechas ingresadas
		 */
		String fechaInicioTope = UtilDate.adicionarMesesFechaActualYYYYMMDD(Globales.CANTIDAD_DE_MESES_RANGO_INICIO);

		// Se valida la fecha de inicio
		if (ventaRequest.getFechaInicio() == null) {
			ventaRequest.setFechaInicio(fechaInicioTope);
		} else if (UtilDate.convertStringToDate(ventaRequest.getFechaInicio(), UtilDate.formatDateYYYYMMDD)
				.before(UtilDate.convertStringToDate(fechaInicioTope, UtilDate.formatDateYYYYMMDD))) {
			throw new ModeloNotFountException("Fecha de inicio menor al establecido: " + fechaInicioTope,
					beanLog.getIdentificador());
		}
		// Se valida la fecha de fin
		if (ventaRequest.getFechaFin() == null) {
			ventaRequest.setFechaFin(UtilDate.fechaHoyYYYYMMDD());
		} else if (UtilDate.convertStringToDate(ventaRequest.getFechaFin(), UtilDate.formatDateYYYYMMDD)
				.before(UtilDate.convertStringToDate(ventaRequest.getFechaInicio(), UtilDate.formatDateYYYYMMDD))) {
			throw new ModeloNotFountException("Fecha de fin no puede ser menor a la fecha de inicio.",
					beanLog.getIdentificador());
		}

		/**
		 * Se validan la moneda
		 */
		if (ventaRequest.getMoneda() != null) {
			switch (ventaRequest.getMoneda()) {
			case "604":
				ventaRequest.setMoneda("S");
				break;
			case "840":
				ventaRequest.setMoneda("D");
				break;
			default:
				throw new ModeloNotFountException("Moneda incorrecta.", beanLog.getIdentificador());
			}
		}

		try {

			VentaResponse ventaResponse = transaccionService.listarVentas(idTransaccion, rucEmpresa, ventaRequest);

			if (ventaResponse != null) {
				beanLog.setIdComercio(ventaRequest.getCodigoComercio().toString());
				beanLog.setDescripcionMensaje("Solicitud procesada correctamente");

				return new ResponseEntity<>(ventaResponse, HttpStatus.OK);
			} else {
				beanLog.setDescripcionMensaje("Error al procesar la solicitud");
				throw new ModeloNotFountException("Error al procesar la solicitud", beanLog.getIdentificador());
			}

		} finally {
			utilAudit.endLog(beanLog, fechaInicio);
		}
	}

	@GetMapping(path = "/listar-evolucion-ventas", produces = "application/json")
	public ResponseEntity<Object> listarVentasReporte(EvolucionVentaRequest evolucionRequest) {

		BeanLog beanLog = new BeanLog();
		long fechaInicio = UtilDate.getCurrentDateTime();
		String idTransaccion = UtilString.obtenerIdentificadorUnico();
		String metodo = new Object() {
		}.getClass().getEnclosingMethod().getName();
		beanLog = utilAudit.initLog(idTransaccion, request.getRequestURI(), metodo, true, "Listar Evolucion de Ventas");

		try {

			EvolucionVentaResponse evolucionVentaResponse = transaccionService.listarEvolucionVentas(idTransaccion,
					evolucionRequest);

			if (evolucionVentaResponse == null) {
				return new ResponseEntity<>(new BodyResponse<String>("No se encontraron ventas",
						Globales.ModuloTransacciones.VENTAS_NO_ENCONTRADAS), HttpStatus.BAD_REQUEST);
			} else {
				return new ResponseEntity<>(new BodyResponse<>(evolucionVentaResponse, Globales.RESPUESTA_EXITO),
						HttpStatus.OK);
			}
		} catch (Exception e) {
			return new ResponseEntity<>(
					new BodyResponse<String>("Ocurrió un error genérico: " + e.getMessage(), Globales.RESPUESTA_EXITO),
					HttpStatus.BAD_REQUEST);
		} finally {
			utilAudit.endLog(beanLog, fechaInicio);
		}

	}

	@GetMapping(path = "/listar-consumos", produces = "application/json")
	public ResponseEntity<Object> listarConsumos(ConsumosRequest consumoRequest) {
		
		BeanLog beanLog = new BeanLog();
		long fechaInicio = UtilDate.getCurrentDateTime();
		String idTransaccion = UtilString.obtenerIdentificadorUnico();
		String metodo = new Object() {
		}.getClass().getEnclosingMethod().getName();
		beanLog = utilAudit.initLog(idTransaccion, request.getRequestURI(), metodo, true, "Listar Evolucion de Ventas");
		
		try {
			List<ConsumoResp> response = transaccionService.listarConsumos(idTransaccion, consumoRequest);

		if (response != null) {
			return new ResponseEntity<>(new BodyResponse<List<ConsumoResp>>(response, Globales.RESPUESTA_EXITO),
					HttpStatus.OK);
		} else {
			return new ResponseEntity<>(new BodyResponse<String>("No se encontraron consumos",
					Globales.ModuloTransacciones.CONSUMOS_NO_ENCONTRADOS), HttpStatus.BAD_REQUEST);
		}
		
		} catch (Exception e) {
			return new ResponseEntity<>(
					new BodyResponse<String>("Ocurrió un error genérico: " + e.getMessage(), Globales.RESPUESTA_EXITO),
					HttpStatus.BAD_REQUEST);
		} finally {
			utilAudit.endLog(beanLog, fechaInicio);
		}
		
	}

	@GetMapping(path = "/devoluciones", produces = "application/json")
	public ResponseEntity<Object> listarDevoluciones(DevolucionDomRequest devolucionRequest) {

		BeanLog beanLog = new BeanLog();
		long fechaInicio = UtilDate.getCurrentDateTime();
		String idTransaccion = UtilString.obtenerIdentificadorUnico();
		String metodo = new Object() {
		}.getClass().getEnclosingMethod().getName();
		beanLog = utilAudit.initLog(idTransaccion, request.getRequestURI(), metodo, true, "Listar Evolucion de Ventas");
		
		try {
			List<DevolucionRespDTO> response = transaccionService.listarDevolucion(idTransaccion, devolucionRequest);

			if (response != null) {
				return new ResponseEntity<>(
						new BodyResponse<List<DevolucionRespDTO>>(response, Globales.RESPUESTA_EXITO), HttpStatus.OK);
			} else {
				return new ResponseEntity<>(new BodyResponse<String>("No se encontraron devoluciones",
						Globales.ModuloTransacciones.DEVOLUCIONES_NO_ENCONTRADAS), HttpStatus.BAD_REQUEST);
			} 
		} catch (Exception e) {
			return new ResponseEntity<>(
					new BodyResponse<String>("Ocurrió un error genérico: " + e.getMessage(), Globales.RESPUESTA_EXITO),
					HttpStatus.BAD_REQUEST);
		} finally {
			utilAudit.endLog(beanLog, fechaInicio);
		}
	}

	@PostMapping(value = "/devolucion-individual", produces = "application/json")
	public ResponseEntity<Object> cargaDevolucionIndividual(@RequestBody DevolucionDetalle devolucionDetalle) {
		
		BeanLog beanLog = new BeanLog();
		long fechaInicio = UtilDate.getCurrentDateTime();
		String idTransaccion = UtilString.obtenerIdentificadorUnico();
		String metodo = new Object() {
		}.getClass().getEnclosingMethod().getName();
		beanLog = utilAudit.initLog(idTransaccion, request.getRequestURI(), metodo, true, "Cargar Devolucion Individual");
		
		try {
			LinkedHashMap<String, String> response = transaccionService.cargarDevolucionIndividual(idTransaccion,
					devolucionDetalle);

			if (response != null) {
				return new ResponseEntity<>(
						new BodyResponse<LinkedHashMap<String, String>>(response, Globales.RESPUESTA_EXITO),
						HttpStatus.OK);
			} else {
				return new ResponseEntity<>(new BodyResponse<String>("Error al cargar la devolución",
						Globales.ModuloTransacciones.REGISTRAR_DEVOLUCION_ERROR), HttpStatus.BAD_REQUEST);
			} 
		} catch (Exception e) {
			return new ResponseEntity<>(
					new BodyResponse<String>("Ocurrió un error genérico: " + e.getMessage(), Globales.RESPUESTA_EXITO),
					HttpStatus.BAD_REQUEST);
		} finally {
			utilAudit.endLog(beanLog, fechaInicio);
		}
	}

	@PostMapping(value = "/devolucion-masiva", produces = "application/json")
	public ResponseEntity<Object> cargaDevolucionMasiva(@RequestParam("codigoComercio") Long codigoComercio,
			@RequestParam("file") MultipartFile file) {
		
		BeanLog beanLog = new BeanLog();
		long fechaInicio = UtilDate.getCurrentDateTime();
		String idTransaccion = UtilString.obtenerIdentificadorUnico();
		String metodo = new Object() {
		}.getClass().getEnclosingMethod().getName();
		beanLog = utilAudit.initLog(idTransaccion, request.getRequestURI(), metodo, true, "Cargar Devolucion Masiva");

		try {
			DevolucionMasivaResponse response = transaccionService.cargarDevolucionMasiva(idTransaccion, codigoComercio,
					file);

			if (response != null) {
				return new ResponseEntity<>(
						new BodyResponse<DevolucionMasivaResponse>(response, Globales.RESPUESTA_EXITO), HttpStatus.OK);
			} else {
				return new ResponseEntity<>(new BodyResponse<String>("Error al cargar las devoluciones",
						Globales.ModuloTransacciones.REGISTRAR_DEVOLUCION_ERROR), HttpStatus.BAD_REQUEST);
			} 
		} catch (Exception e) {
			return new ResponseEntity<>(
					new BodyResponse<String>("Ocurrió un error genérico: " + e.getMessage(), Globales.RESPUESTA_EXITO),
					HttpStatus.BAD_REQUEST);
		} finally {
			utilAudit.endLog(beanLog, fechaInicio);
		}
	}
}
