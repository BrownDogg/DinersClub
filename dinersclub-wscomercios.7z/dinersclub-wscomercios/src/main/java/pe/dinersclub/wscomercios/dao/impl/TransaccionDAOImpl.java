package pe.dinersclub.wscomercios.dao.impl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import org.springframework.stereotype.Repository;

import pe.dinersclub.wscomercios.dao.TransaccionDAO;
import pe.dinersclub.wscomercios.domain.transaccion.DevolucionDomRequest;
import pe.dinersclub.wscomercios.domain.transaccion.DevolucionCabecera;
import pe.dinersclub.wscomercios.domain.transaccion.DevolucionDetalle;
import pe.dinersclub.wscomercios.domain.transaccion.VentaRequest;
import pe.dinersclub.wscomercios.domain.transaccion.VentaResponse;
import pe.dinersclub.wscomercios.dto.transacciones.ConsumoDTO;
import pe.dinersclub.wscomercios.dto.transacciones.ConsumoRespDTO;
import pe.dinersclub.wscomercios.dto.transacciones.DevolucionRespDTO;
import pe.dinersclub.wscomercios.dto.transacciones.EvolucionVentaDTO;
import pe.dinersclub.wscomercios.dto.transacciones.EvolucionVentaRespDTO;
import pe.dinersclub.wscomercios.dto.transacciones.Venta;
import pe.dinersclub.wscomercios.util.ConnectionDB;
import pe.dinersclub.wscomercios.util.Globales;
import pe.dinersclub.wscomercios.util.UtilDate;
import pe.dinersclub.wscomercios.util.UtilString;

@Repository
public class TransaccionDAOImpl implements TransaccionDAO {

	public VentaResponse listarVentasxComercio(String idTransaccion, VentaRequest ventaRequest) {

		VentaResponse ventaResponse = null;
		List<Venta> ventas = new ArrayList<Venta>();
		Connection conn = null;
		CallableStatement cs = null;
		ResultSet rs = null;
		StringBuilder sbSQLConsulta = new StringBuilder();
		StringBuilder sbSQLCantidad = new StringBuilder();

		try {
			sbSQLConsulta.append(Globales.CALL_SP).append(Globales.ESQUEMA_PROC);
			sbSQLConsulta.append(".").append(Globales.SP_WSC_LISTARVENTASXCOMERCIO).append("(?,?,?,?,?,?)}");

			conn = ConnectionDB.getConnectionServerAS400();
			cs = conn.prepareCall(sbSQLConsulta.toString());

			cs.setLong(1, ventaRequest.getCodigoComercio());
			cs.setString(2, ventaRequest.getMoneda());
			cs.setString(3, ventaRequest.getFechaInicio());
			cs.setString(4, ventaRequest.getFechaFin());
			cs.setInt(5, ventaRequest.getXpage());
			cs.setInt(6, ventaRequest.getPage());

			cs.execute();

			rs = cs.getResultSet();

			while (rs.next()) {

				ventaResponse = new VentaResponse();
				Venta venta = new Venta();
				venta.setCodigoComercio(rs.getLong(1));
				venta.setFechaTicket(rs.getString(2).trim());
				venta.setMoneda(rs.getString(3).trim());
				venta.setImporte(rs.getBigDecimal(4));
				ventas.add(venta);
			}

			ventaResponse.setVentas(ventas);

		} catch (Exception ex) {
			ex.printStackTrace();

		} finally {
			try {
				if (rs != null)
					rs.close();
				if (cs != null)
					cs.close();
				if (conn != null)
					conn.close();
			} catch (SQLException ex) {
			}
		}

		if (!ventas.isEmpty()) {

			try {
				sbSQLCantidad.append(Globales.CALL_SP).append(Globales.ESQUEMA_PROC);
				sbSQLCantidad.append(".").append(Globales.SP_WSC_CANTIDADVENTASXCOMERCIO).append("(?,?,?,?)}");

				conn = ConnectionDB.getConnectionServerAS400();
				cs = conn.prepareCall(sbSQLCantidad.toString());

				cs.setLong(1, ventaRequest.getCodigoComercio());
				cs.setString(2, ventaRequest.getMoneda());
				cs.setString(3, ventaRequest.getFechaInicio());
				cs.setString(4, ventaRequest.getFechaFin());
				cs.execute();
				rs = cs.getResultSet();
				if (rs.next()) {
					ventaResponse.setCantidadRegistros(rs.getInt(1));
				}

			} catch (Exception ex) {
				ex.printStackTrace();

			} finally {
				try {
					if (rs != null)
						rs.close();
					if (cs != null)
						cs.close();
					if (conn != null)
						conn.close();
				} catch (SQLException ex) {
				}
			}
		} else {
			try {
				if (conn != null)
					conn.close();
			} catch (SQLException ex) {
			}
		}

		return ventaResponse;
	}

	@Override
	public VentaResponse listarVentasxEmpresa(String idTransaccion, Long rucEmpresa, VentaRequest ventaRequest) {

		VentaResponse ventaResponse = null;
		List<Venta> ventas = new ArrayList<Venta>();
		Connection conn = null;
		CallableStatement cs = null;
		ResultSet rs = null;
		StringBuilder sbSQLConsulta = new StringBuilder();
		StringBuilder sbSQLCantidad = new StringBuilder();

		try {
			sbSQLConsulta.append(Globales.CALL_SP).append(Globales.ESQUEMA_PROC);
			sbSQLConsulta.append(".").append(Globales.SP_WSC_LISTARVENTASXEMPRESA).append("(?,?,?,?,?,?)}");

			conn = ConnectionDB.getConnectionServerAS400();
			cs = conn.prepareCall(sbSQLConsulta.toString());

			cs.setLong(1, rucEmpresa);
			cs.setString(2, ventaRequest.getMoneda());
			cs.setString(3, ventaRequest.getFechaInicio());
			cs.setString(4, ventaRequest.getFechaFin());
			cs.setInt(5, ventaRequest.getXpage());
			cs.setInt(6, ventaRequest.getPage());
			cs.execute();
			rs = cs.getResultSet();
			while (rs.next()) {
				ventaResponse = new VentaResponse();
				Venta venta = new Venta();
				venta.setCodigoComercio(rs.getLong(1));
				venta.setFechaTicket(rs.getString(2).trim());
				venta.setMoneda(rs.getString(3).trim());
				venta.setImporte(rs.getBigDecimal(4));
				ventas.add(venta);
			}
			ventaResponse.setVentas(ventas);

		} catch (Exception ex) {
			ex.printStackTrace();

		} finally {
			try {
				if (rs != null)
					rs.close();
				if (cs != null)
					cs.close();
			} catch (SQLException ex) {
			}
		}

		if (!ventas.isEmpty()) {

			try {

				sbSQLCantidad.append(Globales.CALL_SP).append(Globales.ESQUEMA_PROC);
				sbSQLCantidad.append(".").append(Globales.SP_WSC_CANTIDADVENTASXEMPRESA).append("(?,?,?,?)}");

				// conn = ConnectionDB.getConnectionServerAS400();
				cs = conn.prepareCall(sbSQLCantidad.toString());

				cs.setLong(1, rucEmpresa);
				cs.setString(2, ventaRequest.getMoneda());
				cs.setString(3, ventaRequest.getFechaInicio());
				cs.setString(4, ventaRequest.getFechaFin());
				cs.execute();
				rs = cs.getResultSet();

				if (rs.next()) {
					ventaResponse.setCantidadRegistros(rs.getInt(1));
				}

			} catch (Exception ex) {
				ex.printStackTrace();

			} finally {
				try {
					if (rs != null)
						rs.close();
					if (cs != null)
						cs.close();
					if (conn != null)
						conn.close();
				} catch (SQLException ex) {
				}
			}
		} else {
			try {
				if (conn != null)
					conn.close();
			} catch (SQLException ex) {
			}
		}

		return ventaResponse;
	}

	@Override
	public List<EvolucionVentaRespDTO> listarEvolucionVentas(String idTransaccion, EvolucionVentaDTO evolVentaComercio) {

		EvolucionVentaRespDTO resp = null;
		Connection conn = null;
		CallableStatement cs = null;
		ResultSet rs = null;
		StringBuilder sbSQLConsulta = new StringBuilder();

		try {

			sbSQLConsulta.append(Globales.CALL_SP).append(Globales.ESQUEMA_PROC);
			sbSQLConsulta.append(".").append("SP_WSC_LISTAREVOL_VENTAS").append("(?,?,?,?,?)}");

			conn = ConnectionDB.getConnectionServerAS400();
			cs = conn.prepareCall(sbSQLConsulta.toString());

			cs.setString(1, evolVentaComercio.getIdEmpresa());
			cs.setString(2, evolVentaComercio.getIdComercio());
			cs.setString(3, evolVentaComercio.getMoneda());
			cs.setString(4, evolVentaComercio.getFechaInicio());
			cs.setString(5, evolVentaComercio.getFechaFin());
			cs.execute();

			rs = cs.getResultSet();
			List<EvolucionVentaRespDTO> listResp = new LinkedList<>();
			while (rs.next()) {
				resp = new EvolucionVentaRespDTO();
				resp.setFechaTicket(rs.getString("FECHA_TICKET"));
//				resp.setHoraTicket(rs.getString("HORA_TICKET"));
				resp.setCantRegistros(rs.getInt("REGISTROS"));
				resp.setImporteTicket(rs.getDouble("IMPORTE"));
				listResp.add(resp);
			}
			return listResp;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public List<ConsumoRespDTO> litarConsumos(String idTransaccion, ConsumoDTO consumo) {

		ConsumoRespDTO resp = null;
		Connection conn = null;
		CallableStatement cs = null;
		ResultSet rs = null;
		StringBuilder sbSQLConsulta = new StringBuilder();

		try {

			sbSQLConsulta.append(Globales.CALL_SP).append(Globales.ESQUEMA_PROC);
			sbSQLConsulta.append(".").append("SP_WSC_LISTAR_CONSUMOS").append("(?,?,?,?,?,?,?,?)}");

			conn = ConnectionDB.getConnectionServerAS400();
			cs = conn.prepareCall(sbSQLConsulta.toString());

			cs.setString(1, consumo.getIdEmpresa());
			cs.setString(2, consumo.getIdComercio());
			cs.setString(3, consumo.getIdMoneda());
			cs.setString(4, consumo.getIdEstadoConsumo());
			cs.setString(5, consumo.getFechaInicio());
			cs.setString(6, consumo.getFechaFin());
			cs.setInt(7, consumo.getPage());
			cs.setInt(8, consumo.getXpage());
			cs.execute();

			rs = cs.getResultSet();
			List<ConsumoRespDTO> listResp = new LinkedList<>();
			while (rs.next()) {
				resp = new ConsumoRespDTO();
				resp.setCodigoComercio(rs.getString("ID_COMERCIO"));
				resp.setNombreComercio(rs.getString("NOM_COMERCIO"));
				resp.setOrigenTransaccion(rs.getString("ORIGEN"));
				resp.setFechaProceso(rs.getString("FEC_PROC"));
				resp.setTarjeta(rs.getString("NUM_TARJETA"));
				resp.setTipoTarjeta(rs.getString("TIP_TARJETA"));
				resp.setCodAutorizacion(rs.getString("ID_AUT"));
				resp.setFechaTicket(rs.getString("FEC_TICKET"));
				resp.setNumeroTicket(rs.getString("NUM_TICKET"));
				resp.setMoneda(rs.getString("ID_MONEDA"));
				resp.setImporte(rs.getString("IMPORTE"));
				resp.setNumeroCuotas(rs.getString("NUM_CUOTAS"));
				resp.setEstadoTicket(rs.getString("ESTADO"));
				resp.setPlazoPago(rs.getString("PLZ_PAGO"));
				resp.setFechaPago(rs.getString("FECHA_PLAZO"));
				resp.setComision(null);
				resp.setIgv(rs.getString("IGV"));

				listResp.add(resp);
			}

			return listResp;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

	}

	@Override
	public int registrarDevolucionCabecera(String idTransaccion, DevolucionCabecera cabecera) {
		
		Connection conn = null;
		CallableStatement cs = null;
		StringBuilder sbSQLConsulta = new StringBuilder();
		int a = 0;
		try {

			sbSQLConsulta.append(Globales.CALL_SP).append(Globales.ESQUEMA_PROC);
			sbSQLConsulta.append(".").append("SP_WSC_I_DEVOLUCION").append("(?,?,?,?,?,?)}");
			conn = ConnectionDB.getConnectionServerAS400();
			cs = conn.prepareCall(sbSQLConsulta.toString());
			cs.setString(1, cabecera.getCodigoComercio());
			cs.setString(2, cabecera.getOrigenTranx());
			cs.setString(3, cabecera.getNroRegistros());
			cs.setString(4, cabecera.getFechaReg());
			cs.setString(5, cabecera.getHoraReg());	
			cs.registerOutParameter(6, java.sql.Types.NUMERIC);
			cs.execute();
			a = cs.getInt(6);
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (cs != null)
					cs.close();
				if (conn != null)
					conn.close();
			} catch (SQLException ex) {
			}
		}
		return a;
	}
	
	@Override
	public boolean registrarDevolucionDetalle(String idTransaccion, int codigoDevolucion, int correlativo, DevolucionDetalle detalle) {
		
		Connection conn = null;
		CallableStatement cs = null;
		ResultSet rs = null;
		StringBuilder sbSQLConsulta = new StringBuilder();

		try {

			sbSQLConsulta.append(Globales.CALL_SP).append(Globales.ESQUEMA_PROC);
			sbSQLConsulta.append(".").append("SP_WSC_I_DEVOLUCION_DET").append("(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
			conn = ConnectionDB.getConnectionServerAS400();
			cs = conn.prepareCall(sbSQLConsulta.toString());
			cs.setString(1, String.valueOf(codigoDevolucion));
			cs.setString(2, String.valueOf(correlativo));
			cs.setString(3, detalle.getCodigoAutorizacion());
			cs.setString(4, detalle.getNroTicket());
			cs.setString(5, detalle.getFechaConsumo());
			cs.setString(6, Globales.ModuloTransacciones.ESTADO_DEVOLUCION_REGISTRADO);
			cs.setString(7, detalle.getNumeroTarjeta());
			cs.setString(8, UtilString.valorMoneda(detalle.getIdMoneda()));
			cs.setString(9, detalle.getImporteConsumo());
			cs.setString(10, detalle.getImporteDevolucion());
			cs.setString(11, detalle.getTipoDevolucion());
			cs.setString(12, detalle.getReferencia());
			cs.setString(13, detalle.getObservaciones());
			cs.setString(14, UtilDate.fechaHoyYYYYMMDD());
			cs.setString(15, UtilDate.horaActualHHMMSS());
			cs.setString(16, "MALVARE");
			
			cs.execute();
			rs = cs.getResultSet();
			
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (cs != null)
					cs.close();
				if (conn != null)
					conn.close();
			} catch (SQLException ex) {
			}
		}
	}

	@Override
	public void rollBackRegistroDevolucion(String idTransaccion, int codigoDevolucion) {

		Connection conn = null;
		CallableStatement cs = null;
		StringBuilder sbSQLConsulta = new StringBuilder();
		try {

			sbSQLConsulta.append(Globales.CALL_SP).append(Globales.ESQUEMA_PROC);
			sbSQLConsulta.append(".").append("SP_WSC_RB_DEVOLUCION").append("(?)}");
			conn = ConnectionDB.getConnectionServerAS400();
			cs = conn.prepareCall(sbSQLConsulta.toString());
			cs.setString(1, String.valueOf(codigoDevolucion));
			cs.execute();
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (cs != null)
					cs.close();
				if (conn != null)
					conn.close();
			} catch (SQLException ex) {
			}
		}
	}
	
	@Override
	public List<DevolucionRespDTO> listarDevolucion(String idTransaccion, DevolucionDomRequest devolucion) {

		DevolucionRespDTO devolucionResp = null;
		List<DevolucionRespDTO> listaDevolucion = null;

		Connection conn = null;
		CallableStatement cs = null;
		ResultSet rs = null;
		StringBuilder sbSQLConsulta = new StringBuilder();

		try {

			sbSQLConsulta.append(Globales.CALL_SP).append(Globales.ESQUEMA_PROC);
			sbSQLConsulta.append(".").append("SP_WSC_LISTAR_DEVOLUCIONES").append("(?,?,?,?,?,?,?,?,?,?)}");
			conn = ConnectionDB.getConnectionServerAS400();
			cs = conn.prepareCall(sbSQLConsulta.toString());
			cs.setString(1, devolucion.getRucEmpresa());
			cs.setString(2, devolucion.getCodigoComercio());
			cs.setString(3, devolucion.getIdMoneda());
			cs.setString(4, devolucion.getIdEstadoDevolucion());
			cs.setString(5, devolucion.getIdTipoTransaccion());
			cs.setString(6, devolucion.getIdTipoDocumento());
			cs.setString(7, devolucion.getFechaInicio());
			cs.setString(8, devolucion.getFechaFin());
			cs.setInt(9, devolucion.getPage());
			cs.setInt(10, devolucion.getXpage());

			cs.execute();
			rs = cs.getResultSet();

			if (rs != null) {
				listaDevolucion = new LinkedList<>();

				while (rs.next()) {
					devolucionResp = new DevolucionRespDTO();
					devolucionResp.setCodigoDevolucion(rs.getString("CODDEVOLUCION"));
					devolucionResp.setCodigoComercio(rs.getString("CODCOMERCIO").trim());
					devolucionResp.setNombreComercio(rs.getString("NOMCOMERCIO").trim());
					devolucionResp.setEstadoDevolucion(rs.getString("ESTADODEVOLUCION"));
					devolucionResp.setFechaTicket(rs.getString("FECHATICKET").trim());
					devolucionResp.setCodigoAutorizacion(rs.getString("CODAUTORIZA").trim());
					devolucionResp.setNumeroTarjeta(rs.getString("NROTARJETA").trim());
					devolucionResp.setImporteConsumo(rs.getDouble("IMPOCONSUMO"));
					devolucionResp.setMoneda(rs.getString("MONEDA").trim());
					devolucionResp.setImporteDevolucion(rs.getString("IMPDEVOLUCION"));
					devolucionResp.setReferencia(rs.getString("REFTRANSACCION").trim());
					devolucionResp.setObservaciones(rs.getString("OBSTRANSACCION").trim());
					devolucionResp.setFechaRegistro(rs.getString("FECHAREGISTRO"));
					devolucionResp.setUsuarioRegistro(rs.getString("USUREGISTRO").trim());
					devolucionResp.setSaldoPendiente(rs.getDouble("SALDOPDT"));
					devolucionResp.setTipoTransaccion(rs.getString("TIPOTRANS"));
					devolucionResp.setOrigenTransaccion(rs.getString("ORIGENTRANS"));
					devolucionResp.setTipoDocumentoContable(rs.getString("TIPDOCCONTA"));
					devolucionResp.setNumeroDocumentoContable(rs.getString("NRODOCCONTA").trim());
					devolucionResp.setMotivo(rs.getString("MOTIVO").trim());
					listaDevolucion.add(devolucionResp);
				}
			}
			return listaDevolucion;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (cs != null)
					cs.close();
				if (conn != null)
					conn.close();
			} catch (SQLException ex) {
			}
		}
	}



}
