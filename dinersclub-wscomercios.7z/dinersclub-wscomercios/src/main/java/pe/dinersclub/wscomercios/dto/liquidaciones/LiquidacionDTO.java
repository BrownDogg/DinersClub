package pe.dinersclub.wscomercios.dto.liquidaciones;

public class LiquidacionDTO {

	private String idEmpresa;
	private String codComercio;
	private String idMoneda;
	private String idFormaPago;
	private String idEstadoPago;
	private String fechaInicio;
	private String fechaFin;
	private String documentoAutorizado;
	private int page;
	private int xpage;

	public String getIdEmpresa() {
		if (idEmpresa.isEmpty()) {
			return null;
		} else {
			return idEmpresa;
		}
	}

	public void setIdEmpresa(String idEmpresa) {
		this.idEmpresa = idEmpresa;
	}

	public String getCodComercio() {
		if (codComercio.isEmpty()) {
			return null;
		} else {
			return codComercio;
		}
	}

	public void setCodComercio(String codComercio) {
		this.codComercio = codComercio;
	}

	public String getIdMoneda() {
		if (idMoneda.isEmpty()) {
			return null;
		} else {
			return idMoneda;
		}
	}

	public void setIdMoneda(String idMoneda) {
		this.idMoneda = idMoneda;
	}

	public String getIdFormaPago() {
		if (idFormaPago.isEmpty()) {
			return null;
		} else {
			return idFormaPago;
		}
	}

	public void setIdFormaPago(String idFormaPago) {
		this.idFormaPago = idFormaPago;
	}

	public String getIdEstadoPago() {

		if (idEstadoPago.isEmpty()) {
			return null;
		} else {
			return idEstadoPago;
		}
	}

	public void setIdEstadoPago(String idEstadoPago) {
		this.idEstadoPago = idEstadoPago;
	}

	public String getFechaInicio() {
		if (fechaInicio.isEmpty()) {
			return null;
		} else {
			return fechaInicio;
		}
	}

	public void setFechaInicio(String fechaInicio) {
		this.fechaInicio = fechaInicio;
	}

	public String getFechaFin() {
		if (fechaFin.isEmpty()) {
			return null;
		} else {
			return fechaFin;
		}
	}

	public void setFechaFin(String fechaFin) {
		this.fechaFin = fechaFin;
	}

	public String getDocumentoAutorizado() {
		if (documentoAutorizado.isEmpty()) {
			return null;
		} else {
			return documentoAutorizado;
		}
	}

	public void setDocumentoAutorizado(String documentoAutorizado) {
		this.documentoAutorizado = documentoAutorizado;
	}

	public int getPage() {
		return page;
	}

	public void setPage(int page) {
		this.page = page;
	}

	public int getXpage() {
		return xpage;
	}

	public void setXpage(int xpage) {
		this.xpage = xpage;
	}

	public LiquidacionDTO(String idEmpresa, String codComercio, String idMoneda, String idFormaPago,
			String idEstadoPago, String fechaInicio, String fechaFin, String documentoAutorizado, int page, int xpage) {
		super();
		this.idEmpresa = idEmpresa;
		this.codComercio = codComercio;
		this.idMoneda = idMoneda;
		this.idFormaPago = idFormaPago;
		this.idEstadoPago = idEstadoPago;
		this.fechaInicio = fechaInicio;
		this.fechaFin = fechaFin;
		this.documentoAutorizado = documentoAutorizado;
		this.page = page;
		this.xpage = xpage;
	}

	public LiquidacionDTO() {
		super();
	}

}
