package pe.dinersclub.wscomercios.dto.cad;

import java.math.BigDecimal;

public class CadServicio {

	private Long numeroCuenta;
	private Long codigoComercio;
	private String codigoServicio;
	private Integer item;
	private Long numeroTarjeta;
	private String anioVencimientoTarjeta;
	private String mesVencimientoTarjeta;
	private String fechaAfiliacion;
	private String fechaDesafiliacion;
	private String origenAfiliacion;
	private String estadoAfiliacion;
	private String moneda;
	private BigDecimal montoTope;
	private String telefono;
	private String email;

	// usuario del servicio;
	private String nombreUsuarioServicio;
	private String tipoDocumentoIdentidadUsuarioServicio;
	private String numeroDocumentoIdentidadUsuarioServicio;

	// Cargo Automático
	private String flagCargoAutomatico;
	private String fechaPrimerCargo;
	private String fechaProximoCargo;
	private String fechaFinCargo;
	private BigDecimal importeCargoAutomatico;

	public Long getNumeroCuenta() {
		return numeroCuenta;
	}

	public void setNumeroCuenta(Long numeroCuenta) {
		this.numeroCuenta = numeroCuenta;
	}

	public Long getCodigoComercio() {
		return codigoComercio;
	}

	public void setCodigoComercio(Long codigoComercio) {
		this.codigoComercio = codigoComercio;
	}

	public String getCodigoServicio() {
		return codigoServicio;
	}

	public void setCodigoServicio(String codigoServicio) {
		this.codigoServicio = codigoServicio;
	}

	public Integer getItem() {
		return item;
	}

	public void setItem(Integer item) {
		this.item = item;
	}

	public Long getNumeroTarjeta() {
		return numeroTarjeta;
	}

	public void setNumeroTarjeta(Long numeroTarjeta) {
		this.numeroTarjeta = numeroTarjeta;
	}

	public String getAnioVencimientoTarjeta() {
		return anioVencimientoTarjeta;
	}

	public void setAnioVencimientoTarjeta(String anioVencimientoTarjeta) {
		this.anioVencimientoTarjeta = anioVencimientoTarjeta;
	}

	public String getMesVencimientoTarjeta() {
		return mesVencimientoTarjeta;
	}

	public void setMesVencimientoTarjeta(String mesVencimientoTarjeta) {
		this.mesVencimientoTarjeta = mesVencimientoTarjeta;
	}

	public String getFechaAfiliacion() {
		return fechaAfiliacion;
	}

	public void setFechaAfiliacion(String fechaAfiliacion) {
		this.fechaAfiliacion = fechaAfiliacion;
	}

	public String getFechaDesafiliacion() {
		return fechaDesafiliacion;
	}

	public void setFechaDesafiliacion(String fechaDesafiliacion) {
		this.fechaDesafiliacion = fechaDesafiliacion;
	}

	public String getOrigenAfiliacion() {
		return origenAfiliacion;
	}

	public void setOrigenAfiliacion(String origenAfiliacion) {
		this.origenAfiliacion = origenAfiliacion;
	}

	public String getEstadoAfiliacion() {
		return estadoAfiliacion;
	}

	public void setEstadoAfiliacion(String estadoAfiliacion) {
		this.estadoAfiliacion = estadoAfiliacion;
	}

	public String getMoneda() {
		return moneda;
	}

	public void setMoneda(String moneda) {
		this.moneda = moneda;
	}

	public BigDecimal getMontoTope() {
		return montoTope;
	}

	public void setMontoTope(BigDecimal montoTope) {
		this.montoTope = montoTope;
	}

	public String getTelefono() {
		return telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getNombreUsuarioServicio() {
		return nombreUsuarioServicio;
	}

	public void setNombreUsuarioServicio(String nombreUsuarioServicio) {
		this.nombreUsuarioServicio = nombreUsuarioServicio;
	}

	public String getTipoDocumentoIdentidadUsuarioServicio() {
		return tipoDocumentoIdentidadUsuarioServicio;
	}

	public void setTipoDocumentoIdentidadUsuarioServicio(String tipoDocumentoIdentidadUsuarioServicio) {
		this.tipoDocumentoIdentidadUsuarioServicio = tipoDocumentoIdentidadUsuarioServicio;
	}

	public String getNumeroDocumentoIdentidadUsuarioServicio() {
		return numeroDocumentoIdentidadUsuarioServicio;
	}

	public void setNumeroDocumentoIdentidadUsuarioServicio(String numeroDocumentoIdentidadUsuarioServicio) {
		this.numeroDocumentoIdentidadUsuarioServicio = numeroDocumentoIdentidadUsuarioServicio;
	}

	public String getFlagCargoAutomatico() {
		return flagCargoAutomatico;
	}

	public void setFlagCargoAutomatico(String flagCargoAutomatico) {
		this.flagCargoAutomatico = flagCargoAutomatico;
	}

	public String getFechaPrimerCargo() {
		return fechaPrimerCargo;
	}

	public void setFechaPrimerCargo(String fechaPrimerCargo) {
		this.fechaPrimerCargo = fechaPrimerCargo;
	}

	public String getFechaProximoCargo() {
		return fechaProximoCargo;
	}

	public void setFechaProximoCargo(String fechaProximoCargo) {
		this.fechaProximoCargo = fechaProximoCargo;
	}

	public String getFechaFinCargo() {
		return fechaFinCargo;
	}

	public void setFechaFinCargo(String fechaFinCargo) {
		this.fechaFinCargo = fechaFinCargo;
	}

	public BigDecimal getImporteCargoAutomatico() {
		return importeCargoAutomatico;
	}

	public void setImporteCargoAutomatico(BigDecimal importeCargoAutomatico) {
		this.importeCargoAutomatico = importeCargoAutomatico;
	}

}
