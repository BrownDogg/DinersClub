package pe.dinersclub.wscomercios.util;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;


import pe.dinersclub.wscomercios.domain.VentaXRango;
import pe.dinersclub.wscomercios.dto.transacciones.EvolucionVentaRespDTO;

public class GeneradorRangoFechas {

	public static List<VentaXRango> evolXDia(String fechaRequest, List<EvolucionVentaRespDTO> lista) {

		List<VentaXRango> listaVentaRango = new LinkedList<>();
		VentaXRango ventaRango = null;

		Date fDesde = UtilDate.convertStringToDate(fechaRequest + " 00:00", "yyyyMMdd hh:mm");
		Date fHasta = null;
		Date fFinal = UtilDate.convertStringToDate(fechaRequest + " 23:59", "yyyyMMdd hh:mm");
		Calendar c = Calendar.getInstance();
		double rangoH = 4;
		int k = 0;

		Date d1 = null;
		Date d2 = null;

		BigDecimal importe = null;

		try {

			k = (int) Math.round(24 / rangoH);

			if (rangoH == 10 || rangoH == 11)
				k = 3;
			else if (rangoH > 12 && rangoH < 24)
				k = 2;
			else if (rangoH >= 24)
				k = 1;

			for (int i = 0; i < k; i++) {

				c.setTime(fDesde);
				fDesde = c.getTime();
				d1 = fDesde;
				c.add(Calendar.HOUR, (int) rangoH);
				c.add(Calendar.MINUTE, -1);
				fHasta = c.getTime();
				c.setTime(fHasta);

				if (fDesde.getDate() < fHasta.getDate()) {
					Date date = fFinal;
					c.setTime(date);
					fHasta = c.getTime();
				} else {
					c.add(Calendar.MINUTE, 1);
					fDesde = c.getTime();
				}

				d2 = fHasta;
				ventaRango = new VentaXRango();
				importe = new BigDecimal(0);

				String descRango = UtilDate.convertDateToString(d1, "HH:mm aa") + " - "
						+ UtilDate.convertDateToString(d2, "HH:mm aa");
				ventaRango.setDescripcionRango(descRango);
				ventaRango.setImporteRango(importe);
				for (EvolucionVentaRespDTO aux : lista) {
					Date fec = UtilDate.convertStringToDate(aux.getFechaTicket() + " " + aux.getHoraTicket(),
							"yyyyMMdd HHmmss");
					if (fec.after(d1) && fec.before(d2)) {
						importe = importe.add(BigDecimal.valueOf(aux.getImporteTicket()));
						ventaRango.setImporteRango(importe);
					}
				}

				listaVentaRango.add(ventaRango);

			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return listaVentaRango;
	}

	public static List<VentaXRango> evolXSemana(Date fechaIni, Date fechaFin, List<EvolucionVentaRespDTO> lista) {

		List<VentaXRango> listaVentaRango = new LinkedList<>();
		VentaXRango ventaRango = null;
		BigDecimal importe = new BigDecimal(0);

		Date startWeek = null;
		Date endWeek = null;

		int dayCal = 0;

		Calendar c = Calendar.getInstance();
		c.setTime(fechaIni);

		do {
			startWeek = c.getTime();
			dayCal = c.getTime().getDay();

			if (dayCal > 0) {
				for (int j = 0; j < (7 - dayCal); j++) {
					c.add(Calendar.DATE, 1);
				}
			}

			endWeek = c.getTime();
			c.add(Calendar.DATE, 1);

			if (endWeek.compareTo(fechaFin) == 1) {
				c.setTime(fechaFin);
				endWeek = c.getTime();
			}

			ventaRango = new VentaXRango();
			importe = new BigDecimal(0);

			String descRango = UtilDate.convertDateToString(startWeek, "dd/MM") + " - "
					+ UtilDate.convertDateToString(endWeek, "dd/MM");

			ventaRango.setDescripcionRango(descRango);
			ventaRango.setImporteRango(importe);

			for (EvolucionVentaRespDTO aux : lista) {
				Date fec = UtilDate.convertStringToDate(aux.getFechaTicket(), "yyyyMMdd");
				if ((fec.equals(startWeek) || fec.equals(endWeek)) || (fec.after(startWeek) && fec.before(endWeek))) {
					importe = importe.add(BigDecimal.valueOf(aux.getImporteTicket()));
					ventaRango.setImporteRango(importe);
				}
			}

			listaVentaRango.add(ventaRango);

		} while (endWeek.compareTo(fechaFin) == -1);

		return listaVentaRango;
	}

	public static List<VentaXRango> evolXMeses(Date fechaIni, Date fechaFin, List<EvolucionVentaRespDTO> lista,
			Boolean monthQuery) {

		List<VentaXRango> listaVentaRango = new LinkedList<>();
		VentaXRango ventaRango = null;
		BigDecimal importe = new BigDecimal(0);

		Date startDate = null;
		Date endDate = null;

		int maxDayMonth = 0;
		int fecAct = 0;
		int diff = 0;
		String mesActual = null;

		Calendar c = Calendar.getInstance();
		c.setTime(fechaIni);

		do {
			startDate = c.getTime();

			// Calculamos la diferencia de dias Input con el total de días del Mes, para
			// sumarle a la fecha tope
			maxDayMonth = c.getActualMaximum(Calendar.DATE);
			fecAct = c.getTime().getDate();
			diff = maxDayMonth - fecAct;

			c.add(Calendar.DATE, diff);
			endDate = c.getTime();

			if (endDate.compareTo(fechaFin) == 1) {
				c.setTime(fechaFin);
				endDate = c.getTime();
			}

			ventaRango = new VentaXRango();
			importe = new BigDecimal(0);

			if (monthQuery) {
				mesActual = UtilDate.convertDateToString(startDate, "MMMM").toUpperCase();
			} else {
				mesActual = UtilDate.convertDateToString(startDate, "MMMM (dd/MM").toUpperCase() + " - "
						+ UtilDate.convertDateToString(endDate, "dd/MM)").toUpperCase();
			}

			ventaRango.setDescripcionRango(mesActual);
			ventaRango.setImporteRango(importe);

			for (EvolucionVentaRespDTO aux : lista) {
				Date fec = UtilDate.convertStringToDate(aux.getFechaTicket(), "yyyyMMdd");
				if ((fec.equals(startDate) || fec.equals(endDate)) || (fec.after(startDate) && fec.before(endDate))) {
					importe = importe.add(BigDecimal.valueOf(aux.getImporteTicket()));
					ventaRango.setImporteRango(importe);
				}
			}

			listaVentaRango.add(ventaRango);

			// Sumamos 1 día al calendario para establer el día 1 del siguiente mes
			c.add(Calendar.DATE, 1);

		} while (endDate.compareTo(fechaFin) == -1);

		return listaVentaRango;

	}

}
