package pe.dinersclub.wscomercios.dto.comercio;

public class ComercioDTO {
	
	private String codigoComercio;
	private String nombreComercio;
	private String rucComercio;
	private String razonSocial;
	private String representanteLegal;
	private String paginaWeb;
	private String correoCorporativo;
	private String correoComercial;
	private String ejecutivoComercio;
	
	public String getCodigoComercio() {
		return codigoComercio;
	}

	public void setCodigoComercio(String codigoComercio) {
		this.codigoComercio = codigoComercio;
	}

	public String getNombreComercio() {
		return nombreComercio;
	}

	public void setNombreComercio(String nombreComercio) {
		this.nombreComercio = nombreComercio;
	}

	public String getRucComercio() {
		return rucComercio;
	}

	public void setRucComercio(String rucComercio) {
		this.rucComercio = rucComercio;
	}

	public String getRazonSocial() {
		return razonSocial;
	}

	public void setRazonSocial(String razonSocial) {
		this.razonSocial = razonSocial;
	}

	public String getRepresentanteLegal() {
		return representanteLegal;
	}

	public void setRepresentanteLegal(String representanteLegal) {
		this.representanteLegal = representanteLegal;
	}

	public String getPaginaWeb() {
		return paginaWeb;
	}

	public void setPaginaWeb(String paginaWeb) {
		this.paginaWeb = paginaWeb;
	}

	public String getCorreoCorporativo() {
		return correoCorporativo;
	}

	public void setCorreoCorporativo(String correoCorporativo) {
		this.correoCorporativo = correoCorporativo;
	}

	public String getCorreoComercial() {
		return correoComercial;
	}

	public void setCorreoComercial(String correoComercial) {
		this.correoComercial = correoComercial;
	}

	public String getEjecutivoComercio() {
		return ejecutivoComercio;
	}

	public void setEjecutivoComercio(String ejecutivoComercio) {
		this.ejecutivoComercio = ejecutivoComercio;
	}

	public ComercioDTO(String codigoComercio, String nombreComercio, String paginaWeb, String correoCorporativo,
			String correoComercial, String ejecutivoComercio) {
		super();
		this.codigoComercio = codigoComercio;
		this.nombreComercio = nombreComercio;
		this.paginaWeb = paginaWeb;
		this.correoCorporativo = correoCorporativo;
		this.correoComercial = correoComercial;
		this.ejecutivoComercio = ejecutivoComercio;
	}
	
	public ComercioDTO() {
		super();
	}
	
}
