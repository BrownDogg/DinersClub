package pe.dinersclub.wscomercios.dao.impl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import pe.dinersclub.wscomercios.dao.ComercioDAO;
import pe.dinersclub.wscomercios.dto.comercio.ComercioDTO;
import pe.dinersclub.wscomercios.dto.comercio.DatosCuentasDTO;
import pe.dinersclub.wscomercios.dto.comercio.DatosDireccionDTO;
import pe.dinersclub.wscomercios.dto.comercio.DatosTelefonoDTO;
import pe.dinersclub.wscomercios.log.BeanLog;
import pe.dinersclub.wscomercios.util.ConnectionDB;
import pe.dinersclub.wscomercios.util.Globales;
import pe.dinersclub.wscomercios.util.UtilAuditoria;
import pe.dinersclub.wscomercios.util.UtilDate;

@Repository
public class ComercioDAOImpl implements ComercioDAO {

	@Autowired
	private UtilAuditoria utilAudit;

	@Override
	public boolean actualizarDatosComercio(String idTransaccion, ComercioDTO comercio) {

		BeanLog beanLog = new BeanLog();
		long fechaInicio = UtilDate.getCurrentDateTime();
		String metodo = new Object() {}.getClass().getEnclosingMethod().getName();
		beanLog = utilAudit.initLog(idTransaccion, null, metodo, false, "Actualizar Datos del Comercio DAO");
		Connection conn = null;
		CallableStatement cs = null;
		ResultSet rs = null;
		StringBuilder sbSQLConsulta = new StringBuilder();

		try {

			sbSQLConsulta.append(Globales.CALL_SP).append(Globales.ESQUEMA_PROC);
			sbSQLConsulta.append(".").append("SP_WSC_U_COMERCIO").append("(?,?,?)}");
			conn = ConnectionDB.getConnectionServerAS400();
			cs = conn.prepareCall(sbSQLConsulta.toString());
			cs.setString(1, comercio.getCodigoComercio());
			cs.setString(2, comercio.getPaginaWeb());
			cs.setString(3, comercio.getCorreoComercial());
			cs.execute();
			rs = cs.getResultSet();

			return true;
		} catch (Exception e) {
			utilAudit.errorExceptionLog(beanLog, e.getMessage(), e.getCause().getMessage());
			return false;
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (cs != null)
					cs.close();
				if (conn != null)
					conn.close();
			} catch (SQLException ex) {
			}
			utilAudit.endLog(beanLog, fechaInicio);
		}
	}

	@Override
	public boolean actualizarTelefonoComercio(String idTransaccion, DatosTelefonoDTO telefono) {

		BeanLog beanLog = new BeanLog();
		long fechaInicio = UtilDate.getCurrentDateTime();
		String metodo = new Object() {
		}.getClass().getEnclosingMethod().getName();
		beanLog = utilAudit.initLog(idTransaccion, null, metodo, false, "Actualiza Telefonos Comercio DAO");
		Connection conn = null;
		CallableStatement cs = null;
		ResultSet rs = null;
		StringBuilder sbSQLConsulta = new StringBuilder();

		try {

			sbSQLConsulta.append(Globales.CALL_SP).append(Globales.ESQUEMA_PROC);
			sbSQLConsulta.append(".").append("SP_WSC_U_TELF_COMERCIO").append("(?,?,?,?)}");
			conn = ConnectionDB.getConnectionServerAS400();
			cs = conn.prepareCall(sbSQLConsulta.toString());
			cs.setString(1, telefono.getCodComercio());
			cs.setString(2, telefono.getNroTelefono());
			cs.setString(3, telefono.getNroItem());
			cs.setString(4, telefono.getTipoTelefono());
			cs.execute();
			rs = cs.getResultSet();

			return true;
		} catch (Exception e) {
			utilAudit.errorExceptionLog(beanLog, e.getMessage(), e.getCause().getMessage());
			return false;
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (cs != null)
					cs.close();
				if (conn != null)
					conn.close();
			} catch (SQLException ex) {
			}
			utilAudit.endLog(beanLog, fechaInicio);
		}
	}

	@Override
	public boolean actualizarDireccionComercio(String idTransaccion, DatosDireccionDTO direccion) {

		BeanLog beanLog = new BeanLog();
		long fechaInicio = UtilDate.getCurrentDateTime();
		String metodo = new Object() {
		}.getClass().getEnclosingMethod().getName();
		beanLog = utilAudit.initLog(idTransaccion, null, metodo, false, "Actualizar Direccion del Comercio DAO");
		Connection conn = null;
		CallableStatement cs = null;
		ResultSet rs = null;
		StringBuilder sbSQLConsulta = new StringBuilder();
		try {
			sbSQLConsulta.append(Globales.CALL_SP).append(Globales.ESQUEMA_PROC);
			sbSQLConsulta.append(".").append("SP_WSC_U_DIR_COMERCIO").append("(?,?,?,?,?,?,?,?,?)}");
			conn = ConnectionDB.getConnectionServerAS400();
			cs = conn.prepareCall(sbSQLConsulta.toString());
			cs.setString(1, direccion.getCodComercio());
			cs.setString(2, direccion.getTipoDireccion());
			cs.setString(3, direccion.getVia());
			cs.setString(4, direccion.getDireccionComercio());
			cs.setString(5, direccion.getNroDireccion());
			cs.setString(6, direccion.getCodigoPostal());
			cs.setString(7, direccion.getDistrito());
			cs.setString(8, direccion.getProvincia());
			cs.setString(9, direccion.getDepartamento());
			cs.execute();
			rs = cs.getResultSet();
			return true;
		} catch (Exception e) {
			utilAudit.errorExceptionLog(beanLog, e.getMessage(), e.getCause().getMessage());
			return false;
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (cs != null)
					cs.close();
				if (conn != null)
					conn.close();
			} catch (SQLException ex) {
			}
			utilAudit.endLog(beanLog, fechaInicio);
		}
	}

	@Override
	public List<DatosCuentasDTO> listarCuentas(String idTransaccion, String idEmpresa, String codigoComercio) {

		BeanLog beanLog = new BeanLog();
		long fechaInicio = UtilDate.getCurrentDateTime();
		String metodo = new Object() {
		}.getClass().getEnclosingMethod().getName();
		beanLog = utilAudit.initLog(idTransaccion, null, metodo, false, "Listar Cuentas del Comercio DAO");
		List<DatosCuentasDTO> listaCuentas = null;
		DatosCuentasDTO cuenta = null;
		Connection conn = null;
		CallableStatement cs = null;
		ResultSet rs = null;
		StringBuilder sbSQLConsulta = new StringBuilder();

		try {

			sbSQLConsulta.append(Globales.CALL_SP).append(Globales.ESQUEMA_PROC);
			sbSQLConsulta.append(".").append("SP_WSC_COMERCIO_CUENTAS").append("(?,?)}");
			conn = ConnectionDB.getConnectionServerAS400();
			cs = conn.prepareCall(sbSQLConsulta.toString());
			cs.setString(1, idEmpresa);
			cs.setString(2, codigoComercio);
			cs.execute();
			rs = cs.getResultSet();
			if (rs != null) {
				listaCuentas = new LinkedList<>();
				while (rs.next()) {
					cuenta = new DatosCuentasDTO();
					cuenta.setCodComercio(rs.getString("CODCOMERCIO"));
					cuenta.setBanco(rs.getString("BANCOPAGO").trim());
					cuenta.setNroCuenta(rs.getString("NROCUENTA").trim());
					cuenta.setSistemaPago(rs.getString("SISTEMAPAGO").trim());
					listaCuentas.add(cuenta);
				}
			}
		} catch (Exception e) {
			utilAudit.errorExceptionLog(beanLog, e.getMessage(), e.getCause().getMessage());
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (cs != null)
					cs.close();
				if (conn != null)
					conn.close();
			} catch (SQLException ex) {
			}
			utilAudit.endLog(beanLog, fechaInicio);
		}
		return listaCuentas;
	}

	@Override
	public List<DatosTelefonoDTO> listarTelefonos(String idTransaccion, String idEmpresa, String codigoComercio) {

		BeanLog beanLog = new BeanLog();
		long fechaInicio = UtilDate.getCurrentDateTime();
		String metodo = new Object() {
		}.getClass().getEnclosingMethod().getName();
		beanLog = utilAudit.initLog(idTransaccion, null, metodo, false, "Listar Telefonos del Comercio DAO");
		List<DatosTelefonoDTO> listaTelefonos = null;
		DatosTelefonoDTO telefono = null;
		Connection conn = null;
		CallableStatement cs = null;
		ResultSet rs = null;
		StringBuilder sbSQLConsulta = new StringBuilder();

		try {

			sbSQLConsulta.append(Globales.CALL_SP).append(Globales.ESQUEMA_PROC);
			sbSQLConsulta.append(".").append("SP_WSC_COMERCIO_DATOSTELF").append("(?,?)}");

			conn = ConnectionDB.getConnectionServerAS400();
			cs = conn.prepareCall(sbSQLConsulta.toString());
			cs.setString(1, idEmpresa);
			cs.setString(2, codigoComercio);
			cs.execute();
			rs = cs.getResultSet();
			if (rs != null) {
				listaTelefonos = new LinkedList<>();
				while (rs.next()) {
					telefono = new DatosTelefonoDTO();
					telefono.setCodComercio(rs.getString("CODCOMERCIO"));
					telefono.setNroTelefono(rs.getString("NROTELEFONO").trim());
					telefono.setTipoTelefono(rs.getString("TIPOTELF").trim());
					listaTelefonos.add(telefono);
				}
			}
		} catch (Exception e) {
			utilAudit.errorExceptionLog(beanLog, e.getMessage(), e.getCause().getMessage());
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (cs != null)
					cs.close();
				if (conn != null)
					conn.close();
			} catch (SQLException ex) {
			}
			utilAudit.endLog(beanLog, fechaInicio);
		}
		return listaTelefonos;
	}

	@Override
	public List<DatosDireccionDTO> listarDirecciones(String idTransaccion, String idEmpresa, String codigoComercio) {

		BeanLog beanLog = new BeanLog();
		long fechaInicio = UtilDate.getCurrentDateTime();
		String metodo = new Object() {
		}.getClass().getEnclosingMethod().getName();
		beanLog = utilAudit.initLog(idTransaccion, null, metodo, false, "Listar Direcciones del Comercio DAO");
		List<DatosDireccionDTO> listaDirecciones = null;
		DatosDireccionDTO direccion = null;
		Connection conn = null;
		CallableStatement cs = null;
		ResultSet rs = null;
		StringBuilder sbSQLConsulta = new StringBuilder();

		try {

			sbSQLConsulta.append(Globales.CALL_SP).append(Globales.ESQUEMA_PROC);
			sbSQLConsulta.append(".").append("SP_WSC_COMERCIO_DATOSDIRECCION").append("(?,?)}");
			conn = ConnectionDB.getConnectionServerAS400();
			cs = conn.prepareCall(sbSQLConsulta.toString());
			cs.setString(1, idEmpresa);
			cs.setString(2, codigoComercio);
			cs.execute();
			rs = cs.getResultSet();

			if (rs != null) {
				listaDirecciones = new LinkedList<>();
				while (rs.next()) {
					direccion = new DatosDireccionDTO();
					direccion.setCodComercio(rs.getString("CODCOMERCIO"));
					direccion.setVia(rs.getString("VIA"));
					direccion.setTipoDireccion(rs.getString("TIPODIR").trim());
					direccion.setDireccionComercio(rs.getString("DIRECC").trim());
					direccion.setNroDireccion(rs.getString("NRODIR"));
					direccion.setCodigoPostal(rs.getString("CODPOSTAL"));
					direccion.setDepartamento(rs.getString("DEPADESC"));
					direccion.setProvincia(rs.getString("PROVDESC"));
					direccion.setDistrito(rs.getString("DISTDESC"));
					listaDirecciones.add(direccion);
				}
			}

		} catch (Exception e) {
			utilAudit.errorExceptionLog(beanLog, e.getMessage(), e.getCause().getMessage());
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (cs != null)
					cs.close();
				if (conn != null)
					conn.close();
			} catch (SQLException ex) {
			}
			utilAudit.endLog(beanLog, fechaInicio);
		}

		return listaDirecciones;
	}

	@Override
	public ComercioDTO obtenerComercio(String idTransaccion, String codigoComercio) {

		BeanLog beanLog = new BeanLog();
		long fechaInicio = UtilDate.getCurrentDateTime();
		String metodo = new Object() {
		}.getClass().getEnclosingMethod().getName();
		beanLog = utilAudit.initLog(idTransaccion, null, metodo, false, "Obtener Comercio DAO");
		ComercioDTO comercio = null;
		Connection conn = null;
		CallableStatement cs = null;
		ResultSet rs = null;
		StringBuilder sbSQLConsulta = new StringBuilder();

		try {

			sbSQLConsulta.append(Globales.CALL_SP).append(Globales.ESQUEMA_PROC);
			sbSQLConsulta.append(".").append("SP_WSC_OBTENER_COMERCIO").append("(?)}");
			conn = ConnectionDB.getConnectionServerAS400();
			cs = conn.prepareCall(sbSQLConsulta.toString());
			cs.setString(1, codigoComercio);
			cs.execute();
			rs = cs.getResultSet();

			if (rs != null) {
				while (rs.next()) {
					comercio = new ComercioDTO();
					comercio.setCodigoComercio(rs.getString("CODCOMERCIO").trim());
					comercio.setNombreComercio(rs.getString("NOMCOMERCIO").trim());
					comercio.setRucComercio(rs.getString("RUC").trim());
					comercio.setRazonSocial(rs.getString("RZNSOC").trim());
					comercio.setRepresentanteLegal(rs.getString("REPLEGAL").trim());
					comercio.setCorreoCorporativo(rs.getString("CORREOOPERATIVO").trim());
					comercio.setCorreoComercial(rs.getString("CORREOCOMERCIAL").trim());
					comercio.setEjecutivoComercio(rs.getString("EJECUTIVO").trim());
				}
			}
		} catch (Exception e) {
			utilAudit.errorExceptionLog(beanLog, e.getMessage(), e.getCause().getMessage());
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (cs != null)
					cs.close();
				if (conn != null)
					conn.close();
			} catch (SQLException ex) {
			}
			utilAudit.endLog(beanLog, fechaInicio);
		}
		return comercio;
	}
}
