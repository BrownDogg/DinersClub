package pe.dinersclub.wscomercios.redis.service;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.stereotype.Service;

import pe.dinersclub.wscomercios.domain.usuario.UsuarioOpcionResponse;
import pe.dinersclub.wscomercios.dto.usuario.RedisUsuarioOpcionesRequest;
import pe.dinersclub.wscomercios.log.BeanLog;
import pe.dinersclub.wscomercios.log.UtilLog;
import pe.dinersclub.wscomercios.log.UtilLogLevel;
import pe.dinersclub.wscomercios.util.UtilDate;
import pe.dinersclub.wscomercios.util.UtilObjectMapper;

import com.fasterxml.jackson.core.type.TypeReference;

@EnableAsync
@Service
public class UsuarioOpcionesLocalService {

	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private UtilLog utilLog;
	
	@Autowired
	private UsuarioOpcionesCacheService usuarioOpcionesCacheService;
	
	@Async
	public void deleteAll(String identificador) {
		usuarioOpcionesCacheService.deleteAllRedis(identificador);
	}
	
	
	public List<UsuarioOpcionResponse> findById(String identificador, String idUsuario) {
		BeanLog beanLog = new BeanLog();
		beanLog.setIdentificador(identificador);
		beanLog.setMetodo(new Object() {
		}.getClass().getEnclosingMethod().getName());
		try {
			RedisUsuarioOpcionesRequest redisUsuarioOpcionesRequest= UtilObjectMapper.getObjectMapper().readValue(
					usuarioOpcionesCacheService.findByIdRedis(identificador, idUsuario), new TypeReference<RedisUsuarioOpcionesRequest>() {
					});
			if (redisUsuarioOpcionesRequest == null) {
				// ENTRA AQUI CUANDO NO HAY CONEXION A REDIS
				// EXTRAEMOS LA DATA DE LA BD
				return usuarioOpcionesCacheService.findByIdLocal(identificador, idUsuario).getRespuesta();
			} else {
				if (redisUsuarioOpcionesRequest.getFechaConsulta() == null) {
					// SI LA FECHA CONSULTA ES NULA ES PORQUE TRAJO LA DATA DE LA BD
					return redisUsuarioOpcionesRequest.getRespuesta();
				} else {
					if (UtilDate.vencioFechaAlmacenamientoCache(redisUsuarioOpcionesRequest.getFechaConsulta())) {
						// REQUIERE VOLVER A CONSULTAR LA INFORMACION DE LA BD
						redisUsuarioOpcionesRequest = UtilObjectMapper.getObjectMapper().readValue(
								usuarioOpcionesCacheService.addRedis(identificador, idUsuario),
								new TypeReference<RedisUsuarioOpcionesRequest>() {
								});
						return redisUsuarioOpcionesRequest.getRespuesta();
					} else {
						// RETORNA LA INFORMACION DEL SERVIDOR DE CACHE
						return redisUsuarioOpcionesRequest.getRespuesta();
					}
				}
			}
		} catch(InternalError ex) {
			// SI NO RETORNO DATOS LA CONSULTA
			return new ArrayList<>();
		} catch (Exception ex) {
			beanLog.setDescripcionMensaje(ex.getMessage());
			beanLog.setCausa(ex.getCause() != null ? ex.getCause().getMessage() : "");
			beanLog.setTipoMensaje(UtilLogLevel.ERROR.name());
			utilLog.printInfo(logger, beanLog);
			return usuarioOpcionesCacheService.findByIdLocal(identificador, idUsuario).getRespuesta();
		}
	}
	
}
