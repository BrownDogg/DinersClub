package pe.dinersclub.wscomercios.service;

import pe.dinersclub.wscomercios.dto.usuario.ActualizarPasswordDTO;

public interface SeguridadService {

	public Boolean recuperarPassword(String username, String identificador, String urlBase);

	public Boolean realizaCambioPassword(ActualizarPasswordDTO cambiarPasswordRequest, String identificador);

	public Boolean procesarAccesosFallidos(String username, String uriRequest);

	public boolean logout(String identificador, String idUsuario);

}
