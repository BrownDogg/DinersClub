package pe.dinersclub.wscomercios.mensajeria.formatos;

import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.stereotype.Service;

import pe.dinersclub.wscomercios.dto.usuario.UsuarioRecPassEmail;

@EnableAsync
@Service
public class EnviarMensajeriaFormatos {

	//private Logger logger = LoggerFactory.getLogger(this.getClass());

	/*@Autowired
	private UtilMensajeria utilMensajeria;*/

	
	@Async
	public void enviarRecuperaPassword(UsuarioRecPassEmail usuarioRecPassEmail) {
		String mensaje = CrearMensajeriaFormatos.enviarRecuperaPassword(usuarioRecPassEmail);
		// utilMensajeria.sendMessage(logger, mensaje);
		CrearMensajeriaFormatos.enviarSolicitud(mensaje);
	}

}
