package pe.dinersclub.wscomercios.service;

import pe.dinersclub.wscomercios.domain.comercio.ActualizaDatosComercioRequest;
import pe.dinersclub.wscomercios.domain.comercio.ComercioDomain;

public interface ComercioService {
	
	public String actualizarDatosComercio(String idTransaccion, ActualizaDatosComercioRequest request);
	public ComercioDomain obtenerComercio(String idTransaccion, String codigoComercio);

}
