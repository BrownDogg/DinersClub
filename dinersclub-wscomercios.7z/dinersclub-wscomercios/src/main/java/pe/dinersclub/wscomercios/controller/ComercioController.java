package pe.dinersclub.wscomercios.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.annotations.Api;
import pe.dinersclub.wscomercios.domain.BodyResponse;
import pe.dinersclub.wscomercios.domain.comercio.ActualizaDatosComercioRequest;
import pe.dinersclub.wscomercios.domain.comercio.ComercioDomain;
import pe.dinersclub.wscomercios.log.BeanLog;
import pe.dinersclub.wscomercios.service.ComercioService;
import pe.dinersclub.wscomercios.util.Globales;
import pe.dinersclub.wscomercios.util.UtilAuditoria;
import pe.dinersclub.wscomercios.util.UtilDate;
import pe.dinersclub.wscomercios.util.UtilString;

@RestController
@Api(tags = { "Módulo Comercios" })
@RequestMapping("/comercios")
public class ComercioController {

	@Autowired
	private HttpServletRequest request;
	@Autowired
	private UtilAuditoria utilAudit;
	@Autowired
	ComercioService comercioService;

	@PostMapping(path = "/actualizarComercio", produces = "application/json")
	public ResponseEntity<Object> actualizarComercio(@RequestBody ActualizaDatosComercioRequest actualizaDatosComercioRequest) {

		BeanLog beanLog = new BeanLog();
		long fechaInicio = UtilDate.getCurrentDateTime();
		String idTransaccion = UtilString.obtenerIdentificadorUnico();
		String metodo = new Object(){}.getClass().getEnclosingMethod().getName();
		beanLog = utilAudit.initLog(idTransaccion, request.getRequestURI(), metodo, true, "Actualizar datos del Comercio");

		try {

			String result = comercioService.actualizarDatosComercio(idTransaccion, actualizaDatosComercioRequest);

			if (result.equals(Globales.RESPUESTA_EXITO)) {
				return new ResponseEntity<>(new BodyResponse<String>(result, Globales.RESPUESTA_EXITO), HttpStatus.OK);
			} else {
				return new ResponseEntity<>(
						new BodyResponse<String>("Ocurrió un error al actualizar los datos del Comercio",
								Globales.ModuloComercio.COMERCIO_ACTUALIZA_ERROR),
						HttpStatus.BAD_REQUEST);
			}
		} catch (Exception e) {
			return new ResponseEntity<>(
					new BodyResponse<String>("Ocurrió un error genérico: " + e.getMessage(), Globales.RESPUESTA_EXITO),
					HttpStatus.BAD_REQUEST);
		}finally {
			utilAudit.endLog(beanLog, fechaInicio);
		}

	}

	@GetMapping(path = "/{codigoComercio}", produces = "application/json")
	public ResponseEntity<Object> obtenerComercio(@PathVariable("codigoComercio") String codigoComercio,
			Authentication auth) {

		BeanLog beanLog = new BeanLog();
		long fechaInicio = UtilDate.getCurrentDateTime();
		String idTransaccion = UtilString.obtenerIdentificadorUnico();
		String metodo = new Object(){}.getClass().getEnclosingMethod().getName();
		beanLog = utilAudit.initLog(idTransaccion, request.getRequestURI(), metodo, true, "Obtener datos del Comercio");
		ComercioDomain comercio = null;

		try {

			comercio = comercioService.obtenerComercio(idTransaccion, codigoComercio);

			if (comercio != null) {
				return new ResponseEntity<>(new BodyResponse<ComercioDomain>(comercio, Globales.RESPUESTA_EXITO),
						HttpStatus.OK);
			} else {
				return new ResponseEntity<>(
						new BodyResponse<ComercioDomain>(comercio, Globales.ModuloComercio.COMERCIO_NO_ENCONTRADO),
						HttpStatus.BAD_REQUEST);
			}
		} catch (Exception e) {
			return new ResponseEntity<>(new BodyResponse<String>("Ocurrió un error genérico: " + e.getMessage(),
					Globales.RESPUESTA_ERROR_GENERICO), HttpStatus.BAD_REQUEST);
		}finally {
			utilAudit.endLog(beanLog, fechaInicio);
		}
	}

}
