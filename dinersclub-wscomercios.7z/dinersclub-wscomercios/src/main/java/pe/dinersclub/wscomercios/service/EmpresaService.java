package pe.dinersclub.wscomercios.service;

import java.util.List;

import pe.dinersclub.wscomercios.domain.comercio.ComercioDomain;
import pe.dinersclub.wscomercios.domain.empresa.EmpresaDomain;

public interface EmpresaService {

	
	public EmpresaDomain obtenerEmpresa (String idTransaccion, String rucEmpresa);
	public EmpresaDomain listarDatosComercios (String idTransaccion, String idEmpresa);
	public List<ComercioDomain> listarComercios(String idTransaccion, String rucEmpresa);
	
}
