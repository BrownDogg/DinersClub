package pe.dinersclub.wscomercios.util;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import pe.dinersclub.wscomercios.exception.ModeloNotFountException;

@Service
public class UtilFile {

	private final Path fileStorageLocation;

	@Autowired
	public UtilFile() {
		this.fileStorageLocation = Paths.get(Globales.uploadDirDevolucion).toAbsolutePath().normalize();
		try {
			Files.createDirectories(this.fileStorageLocation);
		} catch (Exception ex) {
			throw new ModeloNotFountException("Could not create the directory where the uploaded files will be stored.",
					"1");
		}
	}

	public String storeFile(MultipartFile file, String nombreArchivo, String identificador) {

		String fileName = StringUtils.cleanPath(nombreArchivo);

		try {
			// Check if the file's name contains invalid characters
			if (fileName.contains("..")) {
				throw new ModeloNotFountException("Sorry! Filename contains invalid path sequence " + fileName,
						identificador);
			}

			// Copy file to the target location (Replacing existing file with the same name)
			Path targetLocation = this.fileStorageLocation.resolve(fileName);
			Files.copy(file.getInputStream(), targetLocation, StandardCopyOption.REPLACE_EXISTING);

			return fileName;
		} catch (IOException ex) {
			throw new ModeloNotFountException("Could not store file " + fileName + ". Please try again!", "1");
		}
	}

	public Resource loadFileAsResource(String fileName, String identificador) {
		try {
			Path filePath = this.fileStorageLocation.resolve(fileName).normalize();
			Resource resource = new UrlResource(filePath.toUri());
			if (resource.exists()) {
				return resource;
			} else {
				throw new ModeloNotFountException("File not found " + fileName, identificador);
			}
		} catch (MalformedURLException ex) {
			throw new ModeloNotFountException("File not found " + fileName, identificador);
		}
	}

	public Path loadFileAsPath(String fileName, String identificador) {
		try {
			Path filePath = this.fileStorageLocation.resolve(fileName).normalize();

			if (Files.exists(filePath, new LinkOption[] { LinkOption.NOFOLLOW_LINKS })) {
				return filePath;
			} else {
				throw new ModeloNotFountException("File not found " + fileName, identificador);
			}
		} catch (Exception ex) {
			throw new ModeloNotFountException("File not found " + fileName, identificador);
		}
	}

	public String obtenerExtension(MultipartFile file) {

		String extension = "";
		int i = file.getOriginalFilename().lastIndexOf('.');
		if (i >= 0) {
			extension = file.getOriginalFilename().substring(i + 1);
		}

		return extension;
	}

	public boolean validaExtension(String extension) {

		if (extension == null || extension.isEmpty()) {
			return false;
		}

		if (!(extension.equals("xlsx") || extension.equals("txt"))) {
			return false;
		}

		return true;
	}

	public void eliminarArchivo(String fileName) {
		try {
			Path targetLocation = this.fileStorageLocation.resolve(fileName);
			String ruta = String.valueOf(targetLocation);
			File file = new File(ruta);
			file.delete();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
