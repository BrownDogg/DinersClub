package pe.dinersclub.wscomercios.domain.comercio;

public class TelefonoComercio {
	
	private String nroItem;
	private String tipoTelefono;
	private String nroTelefono;
	
	public TelefonoComercio() {
		super();
	}
	public TelefonoComercio(String tipoTelefono, String nroTelefono) {
		super();
		this.tipoTelefono = tipoTelefono;
		this.nroTelefono = nroTelefono;
	}
	
	public String getNroItem() {
		return nroItem;
	}
	public void setNroItem(String nroItem) {
		this.nroItem = nroItem;
	}
	public String getTipoTelefono() {
		return tipoTelefono;
	}
	public void setTipoTelefono(String tipoTelefono) {
		this.tipoTelefono = tipoTelefono;
	}
	public String getNroTelefono() {
		return nroTelefono;
	}
	public void setNroTelefono(String nroTelefono) {
		this.nroTelefono = nroTelefono;
	}
	@Override
	public String toString() {
		return "TelefonoComercio [nroItem=" + nroItem + ", tipoTelefono=" + tipoTelefono + ", nroTelefono="
				+ nroTelefono + "]";
	}
	
}
