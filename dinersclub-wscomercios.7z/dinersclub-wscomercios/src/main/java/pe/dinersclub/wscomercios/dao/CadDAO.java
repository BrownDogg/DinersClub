package pe.dinersclub.wscomercios.dao;

import pe.dinersclub.wscomercios.domain.CadDescargaSolicitudesDinersRequest;
import pe.dinersclub.wscomercios.domain.CadListarAfiliacionesRequest;
import pe.dinersclub.wscomercios.domain.CadListarAfiliacionesResponse;
import pe.dinersclub.wscomercios.domain.CadSolicitudesDinersRequest;
import pe.dinersclub.wscomercios.domain.CadSolicitudesDinersResponse;
import pe.dinersclub.wscomercios.dto.cad.CadDatosTarjeta;
import pe.dinersclub.wscomercios.dto.cad.CadServicio;
import pe.dinersclub.wscomercios.dto.cad.CadSolicitudesDinersDescarga;
import pe.dinersclub.wscomercios.dto.cad.GrabaBolsaMantenimientoAS;

public interface CadDAO {

	public CadSolicitudesDinersResponse listarCadSolicitudesDiners(String identificador,
			CadSolicitudesDinersRequest cadSolicitudesDinersRequest) ;

	public CadSolicitudesDinersDescarga listarCadSolicitudesDinersDescarga(String identificador,
			CadDescargaSolicitudesDinersRequest cadDescargaSolicitudesDinersRequest);

	public CadDatosTarjeta obtenerDatosTarjeta(String identificador, Long numeroTarjeta);

	public CadServicio obtenerServicioCad(String identificador, Long codigoComercio, String codigoServicio,
			Long numeroTarjeta);

	public String guardarAfiliacionIndividual(String identificador, String pData1, String pData2);
	
	public CadListarAfiliacionesResponse listarCadAfiliaciones (String identificador,
			CadListarAfiliacionesRequest cadListarAfiliacionesRequest);

	public String obtenerCorrelativoBolsa(String identificador, String tipoBolsa);
	
	public GrabaBolsaMantenimientoAS grabarBolsaMantemiento(String identificador, String tramaBolsaMantenimiento);
	
	public String grabarDetalleBolsaMantenimiento(String identificador, String tramaDetalleBolsaMantenimiento);
}
