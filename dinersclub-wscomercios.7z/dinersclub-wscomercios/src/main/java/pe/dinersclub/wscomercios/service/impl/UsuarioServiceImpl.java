package pe.dinersclub.wscomercios.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pe.dinersclub.wscomercios.domain.usuario.UsuarioDatosResponse;
import pe.dinersclub.wscomercios.domain.usuario.UsuarioOpcionResponse;
import pe.dinersclub.wscomercios.log.BeanLog;
import pe.dinersclub.wscomercios.log.UtilLog;
import pe.dinersclub.wscomercios.log.UtilLogLevel;
import pe.dinersclub.wscomercios.redis.service.UsuarioDatosLocalService;
import pe.dinersclub.wscomercios.redis.service.UsuarioOpcionesLocalService;
import pe.dinersclub.wscomercios.service.UsuarioService;

@Service
public class UsuarioServiceImpl implements UsuarioService{

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private UtilLog utilLog;
	
	@Autowired
	private UsuarioOpcionesLocalService usuarioOpcionesLocalService;
	
	@Autowired
	private UsuarioDatosLocalService usuarioDatosLocalService;

	@Override
	public List<UsuarioOpcionResponse> obtenerOpcionesDeUsuario(String identificador, String idUsuario) {

		BeanLog beanLog = new BeanLog();
		beanLog.setMetodo(new Object() {
		}.getClass().getEnclosingMethod().getName());
		
		List<UsuarioOpcionResponse> opcionesDeMenu = new ArrayList<UsuarioOpcionResponse>();
		
		try {

			opcionesDeMenu = usuarioOpcionesLocalService.findById(identificador, idUsuario);
			
		} catch (Exception ex) {
			ex.printStackTrace();
			beanLog.setDescripcionMensaje(ex.getMessage());
			beanLog.setCausa(ex.getCause() != null ? ex.getCause().getMessage() : "");
			beanLog.setTipoMensaje(UtilLogLevel.ERROR.name());
			utilLog.printInfo(logger, beanLog);
		}

		return opcionesDeMenu;
		
	}

	@Override
	public UsuarioDatosResponse obtenerDatosIniciales(String identificador, String idUsuario) {

		BeanLog beanLog = new BeanLog();
		beanLog.setMetodo(new Object() {
		}.getClass().getEnclosingMethod().getName());
		
		UsuarioDatosResponse datosIniciales = null;
		
		try {
		
			datosIniciales = usuarioDatosLocalService.findById(identificador, idUsuario);
			
		} catch (Exception ex) {
			ex.printStackTrace();
			beanLog.setDescripcionMensaje(ex.getMessage());
			beanLog.setCausa(ex.getCause() != null ? ex.getCause().getMessage() : "");
			beanLog.setTipoMensaje(UtilLogLevel.ERROR.name());
			utilLog.printInfo(logger, beanLog);
		}

		return datosIniciales;
		
	}
	
	
	
}
