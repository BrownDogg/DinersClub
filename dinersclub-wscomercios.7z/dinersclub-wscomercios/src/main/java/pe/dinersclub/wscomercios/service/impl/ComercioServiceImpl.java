package pe.dinersclub.wscomercios.service.impl;

import java.util.LinkedList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pe.dinersclub.wscomercios.dao.ComercioDAO;
import pe.dinersclub.wscomercios.domain.comercio.ActualizaDatosComercioRequest;
import pe.dinersclub.wscomercios.domain.comercio.ComercioDomain;
import pe.dinersclub.wscomercios.domain.comercio.DireccionComercio;
import pe.dinersclub.wscomercios.domain.comercio.TelefonoComercio;
import pe.dinersclub.wscomercios.domain.empresa.DatosCuentaDomain;
import pe.dinersclub.wscomercios.domain.empresa.DatosDireccionDomain;
import pe.dinersclub.wscomercios.domain.empresa.DatosTelefonoDomain;
import pe.dinersclub.wscomercios.dto.comercio.ComercioDTO;
import pe.dinersclub.wscomercios.dto.comercio.DatosCuentasDTO;
import pe.dinersclub.wscomercios.dto.comercio.DatosDireccionDTO;
import pe.dinersclub.wscomercios.dto.comercio.DatosTelefonoDTO;
import pe.dinersclub.wscomercios.log.BeanLog;
import pe.dinersclub.wscomercios.service.ComercioService;
import pe.dinersclub.wscomercios.util.Globales;
import pe.dinersclub.wscomercios.util.UtilAuditoria;
import pe.dinersclub.wscomercios.util.UtilDate;
import pe.dinersclub.wscomercios.util.UtilString;

@Service
public class ComercioServiceImpl implements ComercioService {

	@Autowired
	ComercioDAO comercioDAO;
	@Autowired
	private UtilAuditoria utilAudit;
	
	@Override
	public String actualizarDatosComercio(String idTransaccion, ActualizaDatosComercioRequest request) {
		
		BeanLog beanLog = new BeanLog();
		long fechaInicio = UtilDate.getCurrentDateTime();
		String metodo = new Object(){}.getClass().getEnclosingMethod().getName();
		beanLog = utilAudit.initLog(idTransaccion, null, metodo, true, "Actualizar datos del Comercio");
		boolean resultado = false;
		
		try {

			String codComercio = request.getCodigoComercio();

			ComercioDTO comercioDTO = new ComercioDTO();
			comercioDTO.setCodigoComercio(codComercio);
			comercioDTO.setCorreoComercial(request.getCorreoComercial());
			comercioDTO.setPaginaWeb(request.getSitioWeb());

			// 1.1 actualiza Comercio
			comercioDAO.actualizarDatosComercio(idTransaccion, comercioDTO);

			if (!request.getListaTelefonos().isEmpty()) {
				// 1.2 actualiza Telefono
				for (TelefonoComercio auxTelf : request.getListaTelefonos()) {

					DatosTelefonoDTO telefDTO = new DatosTelefonoDTO(codComercio, auxTelf.getNroItem(),
							auxTelf.getTipoTelefono(), auxTelf.getNroTelefono());
					comercioDAO.actualizarTelefonoComercio(idTransaccion, telefDTO);
				}
			}

			if (!request.getListaDirecciones().isEmpty()) {
				// 1.3 actualiza Direccion
				for (DireccionComercio auxDir : request.getListaDirecciones()) {

					DatosDireccionDTO direcDTO = new DatosDireccionDTO(codComercio, auxDir.getTipoDireccion(),
							auxDir.getVia(), auxDir.getDireccionComercio(), auxDir.getNroDireccion(),
							auxDir.getCodigoPostal(), auxDir.getDepartamento(), auxDir.getProvincia(),
							auxDir.getDistrito());

					comercioDAO.actualizarDireccionComercio(idTransaccion, direcDTO);
				}
			}

			if(resultado) {
				return Globales.RESPUESTA_EXITO;
			}else {
				return Globales.RESPUESTA_ERROR_BD;
			}
			
		} catch (Exception e) {
			return Globales.RESPUESTA_ERROR_GENERICO;
		}finally {
			utilAudit.endLog(beanLog, fechaInicio);
		}
	}

	@Override
	public ComercioDomain obtenerComercio(String idTransaccion, String codigoComercio) {
		
		BeanLog beanLog = new BeanLog();
		long fechaInicio = UtilDate.getCurrentDateTime();
		String metodo = new Object(){}.getClass().getEnclosingMethod().getName();
		beanLog = utilAudit.initLog(idTransaccion, null, metodo, true, "Obtener datos del Comercio Service");
		
		ComercioDomain comercioDom = null;
		ComercioDTO comDto = null;

		DatosCuentaDomain datosCuenta = null;
		DatosTelefonoDomain datosTelf = null;
		DatosDireccionDomain datosDir = null;

		List<DatosCuentaDomain> listaCuentasDom = null;
		List<DatosTelefonoDomain> listaTelefonosDom = null;
		List<DatosDireccionDomain> listaDireccionesDom = null;

		String direccionConcat = "";

		try {
			comDto = comercioDAO.obtenerComercio(idTransaccion, codigoComercio);

			if (comDto != null) {

				comercioDom = new ComercioDomain();
				comercioDom.setCodigoComercio(comDto.getCodigoComercio());
				comercioDom.setNombreComercio(comDto.getNombreComercio());
				comercioDom.setRucComercio(comDto.getRucComercio());
				comercioDom.setRazonSocial(comDto.getRazonSocial());
				comercioDom.setRepresentanteLegal(comDto.getRepresentanteLegal());
				comercioDom.setCorreoCorporativo(comDto.getCorreoCorporativo());
				comercioDom.setCorreoComercial(comDto.getCorreoComercial());
				comercioDom.setEjecutivoComercio(comDto.getEjecutivoComercio());

				List<DatosCuentasDTO> listaCuentasDto = comercioDAO.listarCuentas(idTransaccion, null, codigoComercio);
				if (listaCuentasDto != null) {
					listaCuentasDom = new LinkedList<>();
					for (DatosCuentasDTO auxCuenta : listaCuentasDto) {
						datosCuenta = new DatosCuentaDomain();
						datosCuenta.setBanco(auxCuenta.getBanco());
						datosCuenta.setNroCuenta(auxCuenta.getNroCuenta());
						datosCuenta.setSistemaPago(auxCuenta.getSistemaPago());
						listaCuentasDom.add(datosCuenta);
					}
					comercioDom.setListaCuentas(listaCuentasDom);
				}

				List<DatosTelefonoDTO> listaTelefonosDto = comercioDAO.listarTelefonos(idTransaccion, null, codigoComercio);
				if (listaTelefonosDto != null) {
					listaTelefonosDom = new LinkedList<>();
					for (DatosTelefonoDTO auxTelf : listaTelefonosDto) {
						datosTelf = new DatosTelefonoDomain();
						datosTelf.setNroTelefono(auxTelf.getNroTelefono());
						datosTelf.setTipoTelefono(auxTelf.getTipoTelefono());
						listaTelefonosDom.add(datosTelf);
					}
					comercioDom.setListaTelefonos(listaTelefonosDom);
				}

				List<DatosDireccionDTO> listaDireccionesDto = comercioDAO.listarDirecciones(idTransaccion, null, codigoComercio);
				if (listaDireccionesDto != null) {
					listaDireccionesDom = new LinkedList<>();
					for (DatosDireccionDTO auxDir : listaDireccionesDto) {
						datosDir = new DatosDireccionDomain();
						direccionConcat = UtilString.getDireccionComercio(auxDir.getVia(),
								auxDir.getDireccionComercio(), auxDir.getNroDireccion(), auxDir.getCodigoPostal(),
								auxDir.getDepartamento(), auxDir.getProvincia(), auxDir.getDistrito());
						datosDir.setDireccionComercio(direccionConcat);
						datosDir.setTipoDireccion(auxDir.getTipoDireccion());
						listaDireccionesDom.add(datosDir);
					}
					comercioDom.setListaDirecciones(listaDireccionesDom);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			utilAudit.endLog(beanLog, fechaInicio);
		}

		return comercioDom;
	}

}
