package pe.dinersclub.wscomercios.dto.cad;

import java.math.BigDecimal;

public class CadSolicitudDiners {

	private Long secuencia;
	private Long numeroTarjeta;
	private String socio;
	private String tipoSolicitud;
	private String fechaRegistro;
	private String codigoServicio;
	private String anioVencimiento;
	private String mesVencimiento;
	private BigDecimal montoTope;
	private String tipoDocumentoIdentidad;
	private String numeroDocumentoIdentidad;

	public BigDecimal getMontoTope() {
		return montoTope;
	}

	public Long getSecuencia() {
		return secuencia;
	}

	public void setSecuencia(Long secuencia) {
		this.secuencia = secuencia;
	}

	public Long getNumeroTarjeta() {
		return numeroTarjeta;
	}

	public void setNumeroTarjeta(Long numeroTarjeta) {
		this.numeroTarjeta = numeroTarjeta;
	}

	public void setMontoTope(BigDecimal montoTope) {
		this.montoTope = montoTope;
	}

	public String getSocio() {
		return socio;
	}

	public void setSocio(String socio) {
		this.socio = socio;
	}

	public String getTipoSolicitud() {
		return tipoSolicitud;
	}

	public void setTipoSolicitud(String tipoSolicitud) {
		this.tipoSolicitud = tipoSolicitud;
	}

	public String getFechaRegistro() {
		return fechaRegistro;
	}

	public void setFechaRegistro(String fechaRegistro) {
		this.fechaRegistro = fechaRegistro;
	}

	public String getCodigoServicio() {
		return codigoServicio;
	}

	public void setCodigoServicio(String codigoServicio) {
		this.codigoServicio = codigoServicio;
	}

	public String getAnioVencimiento() {
		return anioVencimiento;
	}

	public void setAnioVencimiento(String anioVencimiento) {
		this.anioVencimiento = anioVencimiento;
	}

	public String getMesVencimiento() {
		return mesVencimiento;
	}

	public void setMesVencimiento(String mesVencimiento) {
		this.mesVencimiento = mesVencimiento;
	}

	public String getTipoDocumentoIdentidad() {
		return tipoDocumentoIdentidad;
	}

	public void setTipoDocumentoIdentidad(String tipoDocumentoIdentidad) {
		this.tipoDocumentoIdentidad = tipoDocumentoIdentidad;
	}

	public String getNumeroDocumentoIdentidad() {
		return numeroDocumentoIdentidad;
	}

	public void setNumeroDocumentoIdentidad(String numeroDocumentoIdentidad) {
		this.numeroDocumentoIdentidad = numeroDocumentoIdentidad;
	}

	@Override
	public String toString() {
		return "CadSolicitudDiners [secuencia=" + secuencia + ", numeroTarjeta=" + numeroTarjeta + ", socio=" + socio
				+ ", tipoSolicitud=" + tipoSolicitud + ", fechaRegistro=" + fechaRegistro + ", codigoServicio="
				+ codigoServicio + ", anioVencimiento=" + anioVencimiento + ", mesVencimiento=" + mesVencimiento
				+ ", montoTope=" + montoTope + ", tipoDocumentoIdentidad=" + tipoDocumentoIdentidad
				+ ", numeroDocumentoIdentidad=" + numeroDocumentoIdentidad + "]";
	}

}
