package pe.dinersclub.wscomercios.security.filter;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;

import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.SignatureException;
import pe.dinersclub.wscomercios.dto.usuario.TokenDTO;
import pe.dinersclub.wscomercios.log.BeanLog;
import pe.dinersclub.wscomercios.log.UtilLog;
import pe.dinersclub.wscomercios.security.bean.UsuarioAuthorization;
import pe.dinersclub.wscomercios.security.config.JwtConfig;
import pe.dinersclub.wscomercios.security.service.JWTService;
import pe.dinersclub.wscomercios.util.UtilDate;
import pe.dinersclub.wscomercios.util.UtilString;

public class JWTAuthorizationFilter extends BasicAuthenticationFilter {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	private final JwtConfig jwtConfig;
	private UtilLog utilLog;

	@Autowired
	private JWTService jwtService;

	public JWTAuthorizationFilter(AuthenticationManager authenticationManager, JwtConfig jwtConfig,
			JWTService jwtService, UtilLog utilLog) {
		super(authenticationManager);
		this.jwtConfig = jwtConfig;
		this.jwtService = jwtService;
		this.utilLog = utilLog;
	}

	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
			throws IOException, ServletException {

		long fechaInicio = UtilDate.getCurrentDateTime();
		BeanLog beanLog = new BeanLog();
		beanLog.setIdentificador(UtilString.obtenerIdentificadorUnico());
		beanLog.setSolicitud(request.getRequestURI());
		beanLog.setMetodo(new Object() {
		}.getClass().getEnclosingMethod().getName());
		beanLog.setDescripcionMensaje("");

		boolean validaToken = false;

		try {
			String header = request.getHeader(jwtConfig.getHeader());

			if (!requiresAuthentication(header)) {
				chain.doFilter(request, response);
				return;
			}

			UsuarioAuthorization usuarioAuthorization = jwtService.getPrincipal(header);
			UsernamePasswordAuthenticationToken authentication = null;

			/*
			 * Valida usuario logueado y si el token es el útlimo asignado
			 */
			TokenDTO tokenDTO = jwtService.findTokenById(beanLog.getIdentificador(),
					usuarioAuthorization.getIdUsuario().toString());
			validaToken = !(tokenDTO == null || tokenDTO.getTokenAcceso().compareTo(jwtService.resolve(header)) != 0);

			if (validaToken && jwtService.validate(header)) {

				authentication = new UsernamePasswordAuthenticationToken(usuarioAuthorization, null,
						jwtService.getRoles(header));

				SecurityContextHolder.getContext().setAuthentication(authentication);

			}

		} catch (ExpiredJwtException ex) {
			SecurityContextHolder.clearContext();
			beanLog.setDescripcionMensaje("EL TOKEN RECIBIDO ESTÁ EXPIRADO");
		} catch (SignatureException ex) {
			SecurityContextHolder.clearContext();
			beanLog.setDescripcionMensaje("EL TOKEN RECIBIDO EN LA CABECERA NO SE ENCUENTRA REGISTRADO");
		} catch (Exception ex) {
			ex.printStackTrace();
			SecurityContextHolder.clearContext();
			beanLog.setDescripcionMensaje(ex.getMessage());
			beanLog.setCausa(ex.getCause() != null ? ex.getCause().getMessage() : "");
		} finally {
			if (!beanLog.getDescripcionMensaje().isEmpty()) {
				long fechafinal = UtilDate.getCurrentDateTime();
				beanLog.setDuracion(fechafinal - fechaInicio);
				utilLog.printInfo(logger, beanLog);
			}
		}

		chain.doFilter(request, response);

	}

	protected boolean requiresAuthentication(String header) {

		if (header == null || !header.startsWith(jwtConfig.getPrefix())) {
			return false;
		}
		return true;
	}

}
