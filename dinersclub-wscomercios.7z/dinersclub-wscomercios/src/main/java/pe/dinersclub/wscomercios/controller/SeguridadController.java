package pe.dinersclub.wscomercios.controller;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.annotations.Api;
import pe.dinersclub.wscomercios.domain.BodyResponse;
import pe.dinersclub.wscomercios.dto.usuario.ActualizarPasswordDTO;
import pe.dinersclub.wscomercios.exception.ModeloNotFountException;
import pe.dinersclub.wscomercios.log.BeanLog;
import pe.dinersclub.wscomercios.log.UtilLog;
import pe.dinersclub.wscomercios.log.UtilLogLevel;
import pe.dinersclub.wscomercios.security.bean.UsuarioAuthorization;
import pe.dinersclub.wscomercios.service.SeguridadService;
import pe.dinersclub.wscomercios.util.Globales;
import pe.dinersclub.wscomercios.util.UtilString;

@RestController
@Api(tags = { "Módulo de Seguridad" })
@RequestMapping(path = "/seguridad")
public class SeguridadController {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private UtilLog utilLog;

	@Autowired
	private HttpServletRequest request;

	@Autowired
	private SeguridadService seguridadService;

	@PostMapping(value = "/recuperar-password", produces = "application/json")
	public ResponseEntity<Object> recuperarPassword(@RequestParam("username") String username) {

		BeanLog beanLog = new BeanLog();
		beanLog.setIdentificador(UtilString.obtenerIdentificadorUnico());
		beanLog.setSolicitud(request.getRequestURI());
		beanLog.setMetodo(new Object(){}.getClass().getEnclosingMethod().getName());
		beanLog.setEsPadre(true);
		beanLog.setNombreOperacion("Recuperar contraseña");

		String urlBase = request.getRequestURL().toString();

		boolean resultado = false;
		resultado = seguridadService.recuperarPassword(username, beanLog.getIdentificador(), urlBase);

		if (!resultado) {
			beanLog.setCodigoMensaje(Globales.ERROR_AL_RECUPERAR_PASSWORD);
			beanLog.setDescripcionMensaje("ERROR_AL_RECUPERAR_PASSWORD. ");
			beanLog.setTipoMensaje(UtilLogLevel.INFO.name());
			utilLog.printInfo(logger, beanLog);
			throw new ModeloNotFountException(beanLog.getCodigoMensaje(), beanLog.getIdentificador());
		} else {
			beanLog.setCodigoMensaje(Globales.RESPUESTA_EXITO);
			beanLog.setDescripcionMensaje("SE PROCESÓ LA RECUPERACIÓN DE CONTRASEÑA CON ÉXITO");
			beanLog.setTipoMensaje(UtilLogLevel.INFO.name());
			utilLog.printInfo(logger, beanLog);
			return new ResponseEntity<>(new BodyResponse<String>(null, Globales.RESPUESTA_EXITO),
					HttpStatus.ACCEPTED);
		}
	}

	@PostMapping("/cambiar-password")
	@PreAuthorize("hasAuthority('CHANGE_PASSWORD') or !authentication.principal.acceso")
	public ResponseEntity<Object> realizarCambioDePassword(@RequestParam("password") String password,
			Authentication auth) {

		UsuarioAuthorization usuario = (UsuarioAuthorization) auth.getPrincipal();
		BeanLog beanLog = new BeanLog();
		beanLog.setIdentificador(UtilString.obtenerIdentificadorUnico());
		beanLog.setSolicitud(request.getRequestURI());
		beanLog.setMetodo(new Object(){}.getClass().getEnclosingMethod().getName());
		beanLog.setIdUsuario(usuario.getIdUsuario());
		beanLog.setEsPadre(true);
		beanLog.setNombreOperacion("Cambio de Clave");

		ActualizarPasswordDTO actualizarPasswordDTO = new ActualizarPasswordDTO();
		actualizarPasswordDTO.setIdUsuario(usuario.getIdUsuario());
		actualizarPasswordDTO.setPassword(password);

		boolean resultado = false;
		resultado = seguridadService.realizaCambioPassword(actualizarPasswordDTO, beanLog.getIdentificador());

		if (!resultado) {
			beanLog.setCodigoMensaje(Globales.OCURRIO_UN_PROBLEMA_AL_ACTUALIZAR_PASSWORD);
			beanLog.setDescripcionMensaje("OCURRIO_UN_PROBLEMA_AL_ACTUALIZAR_PASSWORD. ");
			beanLog.setTipoMensaje(UtilLogLevel.INFO.name());
			utilLog.printInfo(logger, beanLog);
			throw new ModeloNotFountException(beanLog.getCodigoMensaje(), beanLog.getIdentificador());
		} else {
			beanLog.setCodigoMensaje(Globales.RESPUESTA_EXITO);
			beanLog.setDescripcionMensaje("CONTRASEÑA ACTUALIZADA CON ÉXITO");
			beanLog.setTipoMensaje(UtilLogLevel.INFO.name());
			utilLog.printInfo(logger, beanLog);
			return new ResponseEntity<>(new BodyResponse<String>(null, Globales.RESPUESTA_EXITO), HttpStatus.OK);
		}

	}

	@GetMapping("/logout")
	public ResponseEntity<Boolean> logout(Authentication auth) {

		BeanLog beanLog = new BeanLog();
		beanLog.setIdentificador(UtilString.obtenerIdentificadorUnico());
		beanLog.setSolicitud(request.getRequestURI());
		beanLog.setMetodo(new Object(){}.getClass().getEnclosingMethod().getName());
		beanLog.setEsPadre(true);
		beanLog.setNombreOperacion("Logout");
		UsuarioAuthorization usuario = (UsuarioAuthorization) auth.getPrincipal();

		Boolean logout = seguridadService.logout(beanLog.getIdentificador(), usuario.getIdUsuario());

		beanLog.setDescripcionMensaje("FIN DE SESION DE USUARIO " + usuario.getIdUsuario());
		beanLog.setTipoMensaje(UtilLogLevel.INFO.name());
		utilLog.printInfo(logger, beanLog);

		return new ResponseEntity<>(logout, HttpStatus.OK);
	}

	@PostMapping("/logout")
	public void post(Authentication auth) {

		BeanLog beanLog = new BeanLog();
		beanLog.setIdentificador(UtilString.obtenerIdentificadorUnico());
		beanLog.setSolicitud(request.getRequestURI());
		beanLog.setMetodo(new Object(){}.getClass().getEnclosingMethod().getName());
		beanLog.setEsPadre(true);
		beanLog.setNombreOperacion("Logout");

		UsuarioAuthorization usuario = (UsuarioAuthorization) auth.getPrincipal();
		seguridadService.logout(beanLog.getIdentificador(), usuario.getIdUsuario());

		beanLog.setDescripcionMensaje("FIN DE SESION DE USUARIO " + usuario.getIdUsuario());
		beanLog.setTipoMensaje(UtilLogLevel.INFO.name());
		utilLog.printInfo(logger, beanLog);

	}

}
