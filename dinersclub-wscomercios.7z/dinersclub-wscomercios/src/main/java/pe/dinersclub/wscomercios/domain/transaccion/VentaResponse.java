package pe.dinersclub.wscomercios.domain.transaccion;

import java.util.List;

import pe.dinersclub.wscomercios.dto.transacciones.Venta;

public class VentaResponse {

	private Integer cantidadRegistros;
	private List<Venta> ventas;

	public Integer getCantidadRegistros() {
		return cantidadRegistros;
	}

	public void setCantidadRegistros(Integer cantidadRegistros) {
		this.cantidadRegistros = cantidadRegistros;
	}

	public List<Venta> getVentas() {
		return ventas;
	}

	public void setVentas(List<Venta> ventas) {
		this.ventas = ventas;
	}

}
