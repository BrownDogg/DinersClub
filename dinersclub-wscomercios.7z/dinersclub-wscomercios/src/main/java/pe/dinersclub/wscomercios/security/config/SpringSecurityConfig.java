package pe.dinersclub.wscomercios.security.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import pe.dinersclub.wscomercios.log.UtilLog;
import pe.dinersclub.wscomercios.security.filter.JWTAuthenticationFilter;
import pe.dinersclub.wscomercios.security.filter.JWTAuthorizationFilter;
import pe.dinersclub.wscomercios.security.service.JWTService;
import pe.dinersclub.wscomercios.security.service.JpaUserDetailService;

@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true)
public class SpringSecurityConfig extends WebSecurityConfigurerAdapter {

	@Autowired
	private JpaUserDetailService userDetailsService;

	@Autowired
	private JwtConfig jwtConfig;

	@Autowired
	private JWTService jwtService;

	@Autowired
	private UtilLog utilLog;

	@Override
	protected void configure(HttpSecurity http) throws Exception {

		http.authorizeRequests().antMatchers(HttpMethod.GET, "/**").permitAll()
				.antMatchers(HttpMethod.POST, jwtConfig.getUri()).permitAll()
				// .antMatchers(HttpMethod.GET, jwtConfig.getUriConsultaEmail()).permitAll()
				.antMatchers(HttpMethod.POST, jwtConfig.getUriRecuperarPassword()).permitAll().anyRequest()
				.authenticated().and()
				.addFilter(new JWTAuthenticationFilter(authenticationManager(), jwtConfig, jwtService, utilLog))
				.addFilter(new JWTAuthorizationFilter(authenticationManager(), jwtConfig, jwtService, utilLog))
				.csrf().disable()
				// usamos peticiones por request sin sesiÃƒÆ’Ã‚Â³n
				.sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS);
		// gestiona aurorizacion
		// .exceptionHandling()
		// .authenticationEntryPoint((req, rsp, e) ->
		// rsp.sendError(HttpServletResponse.SC_UNAUTHORIZED))
		// .and()
		// filter valida usuario y credenciales
	}

	@Autowired
	public void configure(AuthenticationManagerBuilder build) throws Exception {
		build.userDetailsService(userDetailsService).passwordEncoder(passwordEncoder());
	}

	@Bean
	public JwtConfig jwtConfig() {
		return new JwtConfig();
	}

	@Bean
	public BCryptPasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}
}
