package pe.dinersclub.wscomercios.service;

import java.util.List;

import pe.dinersclub.wscomercios.domain.liquidaciones.LiquidacionDetalleResponse;
import pe.dinersclub.wscomercios.domain.liquidaciones.LiquidacionesRequest;
import pe.dinersclub.wscomercios.dto.liquidaciones.DatosLiquidacion;

public interface LiquidacionesService {
	
	
	public List<DatosLiquidacion> listarLiquidaciones(String idTransaccion, LiquidacionesRequest request);
	public List<LiquidacionDetalleResponse> listarLiquidacionesDetalle(String idTransaccion, String codPago);
	

}
