package pe.dinersclub.wscomercios.mensajeria.formatos;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import pe.dinersclub.wscomercios.dto.usuario.UsuarioRecPassEmail;
import pe.dinersclub.wscomercios.mensajeria.BeanCorreo;
import pe.dinersclub.wscomercios.mensajeria.BeanMensajeCorreo;
import pe.dinersclub.wscomercios.mensajeria.EnumFormatoCorreo;
import pe.dinersclub.wscomercios.util.Globales;
import pe.dinersclub.wscomercios.util.UtilObjectMapper;


public class CrearMensajeriaFormatos {

	
	public static String enviarRecuperaPassword(UsuarioRecPassEmail usuarioRecPassEmail) {

		String mensaje = null;
		
		BeanMensajeCorreo beanMensajeEmail = new BeanMensajeCorreo();
		try {
			Map<String, Object> parametros = new HashMap<String, Object>();
			parametros.put("nombresCompletos", usuarioRecPassEmail.getNombreCompleto());
			parametros.put("urlRecuperaPassword", usuarioRecPassEmail.getUrlRecuperaPassword());
			
			List<BeanCorreo> correos = new ArrayList<>();
			BeanCorreo beanCorreo = new BeanCorreo();
			
			String asunto="SOLICITUD DE RECUPERACIÓN DE CLAVE DINERS COMERCIOS";
			beanCorreo.setAsunto(asunto);
			beanCorreo.setCorreo(usuarioRecPassEmail.getEmail());
			beanCorreo.setFormato(EnumFormatoCorreo.FormatoDiners.getFormatoCorreo());
			beanCorreo.setEnviarMensaje(true);
			correos.add(beanCorreo);
			
			beanMensajeEmail.setCodigoMensaje(Globales.PLANTILLA_RECUPERA_CLAVE);
			beanMensajeEmail.setCorreos(correos);
			beanMensajeEmail.setParametros(parametros);
			
			mensaje = UtilObjectMapper.getObjectMapper().writerWithDefaultPrettyPrinter()
					.writeValueAsString(beanMensajeEmail);
			
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		
		return mensaje;
	}
	
	
	public static ResponseEntity<Boolean> enviarSolicitud(String contenidoCuerpo) {
		ResponseEntity<Boolean> result;
		try {
			/*** INICIO DE PETICION POR WS ***/
			RestTemplate restTemplate = new RestTemplate();

			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<String> request = new HttpEntity<String>(contenidoCuerpo, headers);

			result = restTemplate.exchange(Globales.urlEnviarSolicitud, HttpMethod.POST, request, Boolean.class);

		} catch (Exception ex) {
			ex.printStackTrace();
			result = new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
		return result;
	}

}
